
#ifndef _VIDEOFORMATDESC_H_
#define _VIDEOFORMATDESC_H_

#include "dstring.h"

#include "VideoFormatItem.h"

#include "int_interface_pre.h"

namespace _DSHOWLIB_NAMESPACE
{
	class Grabber;

	class VideoFormatDesc
	{
		friend class Grabber;
	public:
		_UDSHL_EXP_API ~VideoFormatDesc();
	public:
		_UDSHL_EXP_API VideoFormatItem	createVideoFormat( SIZE size ) const;
		_UDSHL_EXP_API VideoFormatItem	createVideoFormat( int width, int height ) const;
	public:
		_UDSHL_EXP_API GUID			getSubtype() const;
		_UDSHL_EXP_API SIZE			getMinSize() const;
		_UDSHL_EXP_API SIZE			getMaxSize() const;
		_UDSHL_EXP_API SIZE			getStepSize() const;
		_UDSHL_EXP_API int			getBinningFactor() const;
		_UDSHL_EXP_API bool			isROIFormat() const;

		_UDSHL_EXP_API bool			isValidSize( const SIZE& sz ) const;

		/** get string representing this format desc
		 **/
		std::string		toString() const
		{
			return wstoas( toString_() );
		}
		std::wstring	toStringW() const
		{
			return toString_();
		}

		/** get string representing the color format of this format
		 * @return string representing the color format of this format
		 **/
		std::string		getColorformatString() const
		{
			return wstoas( getColorformatString_() );
		}
		std::wstring	getColorformatStringW() const
		{
			return getColorformatString_();
		}

	private:
		_UDSHL_EXP_API	dstringw		toString_() const;
		_UDSHL_EXP_API	dstringw		getColorformatString_() const;

		VideoFormatDesc( const VideoFormatDesc& op2 );
		VideoFormatDesc&	operator=( const VideoFormatDesc& op2 );

		VideoFormatDesc( const win32_utils::CVideoFormatDesc& desc, int binningFactor, bool isROIFormat );

		smart_ptr<win32_utils::CVideoFormatDesc> m_pDesc;

		int		m_binningFactor;
		bool	m_isROIFormat;
	};

}

#endif // _VIDEOFORMATDESC_H_
