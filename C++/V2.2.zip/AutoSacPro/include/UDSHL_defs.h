#ifndef UDSHL_DEFS_H_INC
#define UDSHL_DEFS_H_INC

#include "libbasedefs.h"

#pragma warning( disable : 4786 ) // too long debug info // may be ignored

#ifdef UDSHL_GENERATE_DLL_EXPORTS
	#define _UDSHL_EXP_API	__declspec(dllexport)
#else
	#define _UDSHL_EXP_API	__declspec(dllimport)
#endif

#define UDSHL_LIB_VERSION_MAJOR	3
#define UDSHL_LIB_VERSION_MINOR	3

//#define UDSHL_DEPRECATE_FUNCION_ENABLE_

#if _MSC_VER > 1500 && defined UDSHL_DEPRECATE_FUNCION_ENABLE_
#define UDSHL_DEPRECATE_FUNCTION_	__declspec(deprecated)
#else
#define UDSHL_DEPRECATE_FUNCTION_
#endif

#endif // UDSHL_DEFS_H_INC