
// AutoSacProDlg.h : ͷ�ļ�
//

#pragma once
#include "afxwin.h"
#include "listener.h"
#include "afxwin.h"
#include "DMC2410.h"
#include "MotionTestDlg.h"
#include "SacResourceManageDlg.h"
#include "LampLocationDlg.h"
#include "LampFinishedStatusDlg.h"
#include "Vision.h"
#include "SkinH.h"


#pragma comment(lib, "SkinHu.lib")
#pragma comment(lib,"DMC2410.lib")

extern DWORD iOut[20];


// CAutoSacProDlg �Ի���
class CAutoSacProDlg : public CDialogEx
{
// ����
public:
	CAutoSacProDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_AUTOSACPRO_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
/*�������*/
private:
	DShowLib::Grabber		m_cGrabber; // The instance of the Grabber class.
    DShowLib::FrameHandlerSink::tFHSPtr           m_pSink;
	CListener m_cListener;		// Image processing will be done by this object.
public:
	CStatic m_VideoShow;
	CButton m_cButtonLive;
	CButton m_cButtonSettings;
	
	/* SAC������Ϣ*/
	int m_nSACSum;
	int m_nSACUsed;
	int m_nSACRemain;

	/*������Ϣ*/
	int m_nCurLamp;
	int m_nCosSum;
	int m_nFinished;
	int m_nCosRemain;

	CVision CVis;
	int nSelCos;
	CComboBox m_com_LamSel;
	int nCurLampSel;

	CIsiLcdDisplay m_CMsgShow;

public:
	void SetButtonStatus();
	virtual void OnCancel();
	afx_msg void OnBnClickedBtnDevice();
	afx_msg void OnBnClickedSeting();
	afx_msg void OnBnClickedBtnStart();

/*�˶����Ʋ���*/
public:
	BOOL m_bLogic;
	BOOL m_bSymmetry;
	double m_fAccel;
	double m_fDecel;
	long m_nPulse;
	long m_nSacc;
	long m_nSdec;
	long m_nSpeed;
	long m_nStart;
	int m_nActionst;
	int m_nAxis;
	int m_nSpeedst;

public:
	//CriticalSection m_ioLock;



public:
	CMotionTestDlg *PMotionDlg;
	CSacResourceManageDlg *PSacResourceDlg;
	CLampLocationDlg *PLampLocatio;
	CLampFinishedStatusDlg *PFinishedDlg;
	CWinThread  *pThreadOpr;  //�����߳�
	CWinThread  *pAutoThread; //�Զ��߳�

	static UINT ReSetAllThread(LPVOID lpParam);
	static UINT OPera(LPVOID lpParam);
	static UINT AutoThread(LPVOID lpParam);

	void SaveImages();
	void Emgstop();


	//��Ϣ����,�߳�ͬ������
	HANDLE m_EventMaster; //��������
	HANDLE m_EventTast;   //����ִ����

public:	
	afx_msg void OnDestroy();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnBnClickedPicturenap();
	afx_msg void OnMenuMotionsin();
	afx_msg void OnBnClickedEmgstop();
	afx_msg void OnBnClickedAllreset();
	afx_msg void OnBnClickedStart();
	afx_msg void OnMenuSac();
	afx_msg void OnMenuLocateset();
	afx_msg void OnMenuLampstatus();
	
	afx_msg void OnBnClickedBtnCos1();
	afx_msg void OnBnClickedBtnCo2();
	afx_msg void OnBnClickedBtnCos3();
	afx_msg void OnBnClickedBtnCos4();
	afx_msg void OnBnClickedBtnCos5();
	afx_msg void OnBnClickedBtnCos6();
	afx_msg void OnBnClickedBtnCos7();
	afx_msg void OnBnClickedBtnCos8();
	afx_msg void OnBnClickedBtnCos9();
	afx_msg void OnBnClickedBtnCos10();
	afx_msg void OnBnClickedBtnCos11();
	afx_msg void OnBnClickedBtnCos12();
	afx_msg void OnBnClickedBtnCos13();
	afx_msg void OnBnClickedBtnCos14();
	afx_msg void OnBnClickedBtnCos15();
	afx_msg void OnBnClickedBtnCos16();
	afx_msg void OnBnClickedBtnCos17();
	afx_msg void OnBnClickedBtnCos18();
	afx_msg void OnBnClickedBtnCos19();
	
	afx_msg void OnCbnSelchangeComLampsel();
	afx_msg void OnBnClickedCheckSingle();
	afx_msg void OnBnClickedPustres();
	afx_msg LRESULT OnErrMsgShow(WPARAM wParam,LPARAM lParam);
	
};
