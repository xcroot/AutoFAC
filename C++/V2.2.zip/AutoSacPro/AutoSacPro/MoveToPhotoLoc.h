#ifndef _H_CMOVETOPHOTOLOC_
#define _H_CMOVETOPHOTOLOC_
#pragma once
#include "IniClient.h"
#include "ControlCard.h"
class CMoveToPhotoLoc
{
public:
	CMoveToPhotoLoc(void);
	~CMoveToPhotoLoc(void);

	static void MovetoSACLoc(int nRows, int nCols);
	static void MovetoLampLoc(int nLam,int nCosPos);
};

#endif //_H_CMOVETOPHOTOLOC_