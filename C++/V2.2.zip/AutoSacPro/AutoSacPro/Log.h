//   Log.h:   interface   for   the   CLog   class.  
//  
//////////////////////////////////////////////////////////////////////  

#if   !defined(AFX_LOG_H__5299E2DD_33C0_4528_AE9B_F0C67B2927E7__INCLUDED_)  
#define   AFX_LOG_H__5299E2DD_33C0_4528_AE9B_F0C67B2927E7__INCLUDED_  

#if   _MSC_VER   >   1000  
#pragma   once  
#endif   //   _MSC_VER   >   1000  

#include <string>  
#include <queue>
#include "ResourceManage.h"

using namespace std;

class CLog      
{ 
private:
	void ReportError();
	void Write(const char* typeflag,const char* msg);
	static CString GetPath();
	void OpenLogFile(const char* szPath);
	int loginfolevel;
	char strTime[9];
	char strDate[9];
	std::string strFile;
	CLog(const char* str);
public:
	bool SetIogInfoLevel(int level);
	void LogWarning(const char* lpszFormat,...);
	void LogInfo(int Infolevel,const char* lpszFormat,...);
	void LogInfo(const char* Message);
	void LogInfon(const char *lpszFormat, ...);
	void LogErr(const char* lpszFormat,...);
	static CLog* Instance();
	virtual   ~CLog(); 

//����������������̨��־�����
private:
	typedef queue<CString> CStringQueue;
	CStringQueue m_iLogList;
	CCriticalSection m_iLogListCS;
	bool m_bUseLogList;
	void AddList(const CString &strLog){
		CLockManage iLockManage(&m_iLogListCS);
		m_iLogList.push(strLog);
	}
public:
	void OpenLogList(){m_bUseLogList = true;}
	void CloseLogList(){
		m_bUseLogList = false;
		CLockManage iLockManage(&m_iLogListCS);
		while (!m_iLogList.empty()) m_iLogList.pop();
	}
	bool PopFrontLog(CString &strLog)
	{
		bool bRet = false;
		CLockManage iLockManage(&m_iLogListCS);
		if (!m_iLogList.empty())
		{
			strLog = m_iLogList.front();
			m_iLogList.pop();
			bRet = true;
		}
		return bRet;
	}
};   
#endif   //   !defined(AFX_LOG_H__5299E2DD_33C0_4528_AE9B_F0C67B2927E7__INCLUDED_) 