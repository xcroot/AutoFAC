#include "StdAfx.h"
#include "MoveToPhotoLoc.h"

 static CString m_strIniName = _T("scanlocation.ini");

CMoveToPhotoLoc::CMoveToPhotoLoc(void)
{
}


CMoveToPhotoLoc::~CMoveToPhotoLoc(void)
{
}

void CMoveToPhotoLoc::MovetoSACLoc(int nRows, int nCols)
{

	int nCurPos = CControlCard::GetAxisPosition(X2);

	CControlCard::MoveRaxis(X2,33119 - nCurPos);
	CControlCard::WaitRaxisStop(X2);
	//CControlCard::MoveRaxis(X2,-200000);
	//CControlCard::WaitRaxisStop(X2);

	CHAR szSACX1[50] = { 0 };
	CHAR szSACX2[50] = { 0 };
    CHAR szSACX3[50] = { 0 };
	CHAR szSACX4[50] = { 0 };
	CHAR szSACX5[50] = { 0 };
	CHAR szSACX6[50] = { 0 };
	CHAR szWStep[50] = { 0 };
	CHAR szHStep[50] = { 0 };

	long m_nSACX1, m_nSACX2, m_nSACX3, m_nSACX4, m_nSACX5, m_nSACX6;
	long m_nCurX1, m_nCurX2, m_nCurX3, m_nCurX4, m_nCurX5, m_nCurX6;
	CIniClient::Instance(m_strIniName)->GetValue(_T("SACLOC"),_T("SacX1"),szSACX1,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("SACLOC"),_T("SacX2"),szSACX2,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("SACLOC"),_T("SacX3"),szSACX3,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("SACLOC"),_T("SacX4"),szSACX4,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("SACLOC"),_T("SacX5"),szSACX5,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("SACLOC"),_T("SacX6"),szSACX6,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("SACSTEP"),_T("WStep"),szWStep,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("SACSTEP"),_T("HStep"),szHStep,NULL);

    m_nSACX1 = atof(szSACX1);
	m_nSACX2 = atof(szSACX2);
	m_nSACX3 = atof(szSACX3);
	m_nSACX4 = atof(szSACX4);
	m_nSACX5 = atof(szSACX5);
	m_nSACX6 = atof(szSACX6);
	//���ﻹ�������ʵ��Ҫ�˶��Ǹ�SACλ����

	m_nSACX5 = m_nSACX5 + atof(szWStep) * nRows; //��ӦX5��
	m_nSACX6 = m_nSACX6 - atof(szHStep) * nCols; //��ӦX6��

	//��ȡ���λ��
	m_nCurX1 = CControlCard::GetAxisPosition(X0);
	m_nCurX2 = CControlCard::GetAxisPosition(X1);
	m_nCurX3 = CControlCard::GetAxisPosition(X2);
	m_nCurX4 = CControlCard::GetAxisPosition(X3);
	m_nCurX5 = CControlCard::GetAxisPosition(X4);
	m_nCurX6 = CControlCard::GetAxisPosition(X5);

	CControlCard::MoveRaxis(X4,m_nSACX5 - m_nCurX5);
	CControlCard::WaitRaxisStop(X4);
	CControlCard::MoveRaxis(X5,m_nSACX6 - m_nCurX6);
	CControlCard::WaitRaxisStop(X5);
	CControlCard::MoveRaxis(X0,m_nSACX1 - m_nCurX1);
	CControlCard::WaitRaxisStop(X0);
	CControlCard::MoveRaxis(X1,m_nSACX2 - m_nCurX2);
	CControlCard::WaitRaxisStop(X1);
	CControlCard::MoveRaxis(X2,m_nSACX3 - m_nCurX3);
	CControlCard::WaitRaxisStop(X2);
	CControlCard::MoveRaxis(X3,m_nSACX4 - m_nCurX4);
	CControlCard::WaitRaxisStop(X3);

}

void CMoveToPhotoLoc::MovetoLampLoc( int nLam ,int nCosPos)
{

	CHAR szLampX1[50] = { 0 };
	CHAR szLampX2[50] = { 0 };
	CHAR szLampX3[50] = { 0 };
	CHAR szLampX4[50] = { 0 };
	CHAR szLampX5[50] = { 0 };
	CHAR szLampX6[50] = { 0 };
	CHAR szDeltaCos[50] = { 0 };

	int nCurPos = CControlCard::GetAxisPosition(X2);

	CControlCard::MoveRaxis(X2,43119 - nCurPos);
	CControlCard::WaitRaxisStop(X2);

	long m_nLampX1, m_nLampX2, m_nLampX3, m_nLampX4, m_nLampX5, m_nLampX6;
	long m_nCurX1, m_nCurX2, m_nCurX3, m_nCurX4, m_nCurX5 = 0, m_nCurX6;

	switch(nLam)
	{
	case LAM1:
		{
			CIniClient::Instance(m_strIniName)->GetValue(_T("LAMPLOC1"), _T("LampX1"), szLampX1, NULL);
			CIniClient::Instance(m_strIniName)->GetValue(_T("LAMPLOC1"), _T("LampX2"), szLampX2, NULL);
			CIniClient::Instance(m_strIniName)->GetValue(_T("LAMPLOC1"), _T("LampX3"), szLampX3, NULL);
			CIniClient::Instance(m_strIniName)->GetValue(_T("LAMPLOC1"), _T("LampX4"), szLampX4, NULL);
			CIniClient::Instance(m_strIniName)->GetValue(_T("LAMPLOC1"), _T("LampX5"), szLampX5, NULL);
			CIniClient::Instance(m_strIniName)->GetValue(_T("LAMPLOC1"), _T("LampX6"), szLampX6, NULL);
			CIniClient::Instance(m_strIniName)->GetValue(_T("DELTACOS"), _T("DeltaCos"), szDeltaCos, NULL);
			
			m_nLampX1 = atof(szLampX1);
			m_nLampX2 = atof(szLampX2);
			m_nLampX3 = atof(szLampX3);
			m_nLampX4 = atof(szLampX4);
			m_nLampX5 = atof(szLampX5);
			m_nLampX6 = atof(szLampX6);

			//��ȡ���λ��
			m_nCurX1 = CControlCard::GetAxisPosition(X0);
			m_nCurX2 = CControlCard::GetAxisPosition(X1);
			m_nCurX3 = CControlCard::GetAxisPosition(X2);
			m_nCurX4 = CControlCard::GetAxisPosition(X3);
			//m_nCurX5 = CControlCard::GetAxisPosition(X4);
			m_nCurX6 = CControlCard::GetAxisPosition(X5);
			CString X5Pos;
			X5Pos.Format("%d",CControlCard::GetAxisPosition(X4));
			LONG64 A = _ttoi(X5Pos);
			//COS֮��ļ���ļ��
			
			m_nCurX5 = A - atof(szDeltaCos) * nCosPos;
			long test_location = m_nLampX5 - A;   

			CControlCard::MoveRaxis(X4,test_location);
			CControlCard::WaitRaxisStop(X4);
			CControlCard::MoveRaxis(X5,m_nLampX6 - m_nCurX6);
			CControlCard::WaitRaxisStop(X5);
			CControlCard::MoveRaxis(X0,m_nLampX1 - m_nCurX1);
			CControlCard::WaitRaxisStop(X0);
			CControlCard::MoveRaxis(X1,m_nLampX2 - m_nCurX2);
			CControlCard::WaitRaxisStop(X1);
			CControlCard::MoveRaxis(X2,m_nLampX3 - m_nCurX3);
			CControlCard::WaitRaxisStop(X2);
			CControlCard::MoveRaxis(X3,m_nLampX4 - m_nCurX4);
			CControlCard::WaitRaxisStop(X3);
	
		}
		break;
	case LAM2:
		{
			CIniClient::Instance(m_strIniName)->GetValue(_T("LAMPLOC2"),_T("LampX1"),szLampX1,NULL);
			CIniClient::Instance(m_strIniName)->GetValue(_T("LAMPLOC2"),_T("LampX2"),szLampX2,NULL);
			CIniClient::Instance(m_strIniName)->GetValue(_T("LAMPLOC2"),_T("LampX3"),szLampX3,NULL);
			CIniClient::Instance(m_strIniName)->GetValue(_T("LAMPLOC2"),_T("LampX4"),szLampX4,NULL);
			CIniClient::Instance(m_strIniName)->GetValue(_T("LAMPLOC2"),_T("LampX5"),szLampX5,NULL);
			CIniClient::Instance(m_strIniName)->GetValue(_T("LAMPLOC2"),_T("LampX6"),szLampX6,NULL);

			m_nLampX1 = atof(szLampX1);
			m_nLampX2 = atof(szLampX2);
			m_nLampX3 = atof(szLampX3);
			m_nLampX4 = atof(szLampX4);
			m_nLampX5 = atof(szLampX5);
			m_nLampX6 = atof(szLampX6);

			
			//��ȡ���λ��
			m_nCurX1 = CControlCard::GetAxisPosition(X0);
			m_nCurX2 = CControlCard::GetAxisPosition(X1);
			m_nCurX3 = CControlCard::GetAxisPosition(X2);
			m_nCurX4 = CControlCard::GetAxisPosition(X3);
			m_nCurX5 = CControlCard::GetAxisPosition(X4);
			m_nCurX6 = CControlCard::GetAxisPosition(X5);

			m_nCurX5 = m_nCurX5 - atof(szDeltaCos) * nCosPos;

			CControlCard::MoveRaxis(X4,m_nLampX5 - m_nCurX5);
			CControlCard::WaitRaxisStop(X4);
			CControlCard::MoveRaxis(X5,m_nLampX6 - m_nCurX6);
			CControlCard::WaitRaxisStop(X5);

			CControlCard::MoveRaxis(X0,m_nLampX1 - m_nCurX1);
			CControlCard::WaitRaxisStop(X0);
			CControlCard::MoveRaxis(X1,m_nLampX2 - m_nCurX2);
			CControlCard::WaitRaxisStop(X1);
			CControlCard::MoveRaxis(X2,m_nLampX3 - m_nCurX3);
			CControlCard::WaitRaxisStop(X2);
			CControlCard::MoveRaxis(X3,m_nLampX4 - m_nCurX4);
			CControlCard::WaitRaxisStop(X3);
	
		}
		break;
	case LAM3:
		{
			CIniClient::Instance(m_strIniName)->GetValue(_T("LAMPLOC3"),_T("LampX1"),szLampX1,NULL);
			CIniClient::Instance(m_strIniName)->GetValue(_T("LAMPLOC3"),_T("LampX2"),szLampX2,NULL);
			CIniClient::Instance(m_strIniName)->GetValue(_T("LAMPLOC3"),_T("LampX3"),szLampX3,NULL);
			CIniClient::Instance(m_strIniName)->GetValue(_T("LAMPLOC3"),_T("LampX4"),szLampX4,NULL);
			CIniClient::Instance(m_strIniName)->GetValue(_T("LAMPLOC3"),_T("LampX5"),szLampX5,NULL);
			CIniClient::Instance(m_strIniName)->GetValue(_T("LAMPLOC3"),_T("LampX6"),szLampX6,NULL);

			m_nLampX1 = atof(szLampX1);
			m_nLampX2 = atof(szLampX2);
			m_nLampX3 = atof(szLampX3);
			m_nLampX4 = atof(szLampX4);
			m_nLampX5 = atof(szLampX5);
			m_nLampX6 = atof(szLampX6);

			
			//��ȡ���λ��
			m_nCurX1 = CControlCard::GetAxisPosition(X0);
			m_nCurX2 = CControlCard::GetAxisPosition(X1);
			m_nCurX3 = CControlCard::GetAxisPosition(X2);
			m_nCurX4 = CControlCard::GetAxisPosition(X3);
			m_nCurX5 = CControlCard::GetAxisPosition(X4);
			m_nCurX6 = CControlCard::GetAxisPosition(X5);

			m_nCurX5 = m_nCurX5 - atof(szDeltaCos) * nCosPos;

			CControlCard::MoveRaxis(X4,m_nLampX5 - m_nCurX5);
			CControlCard::WaitRaxisStop(X4);
			CControlCard::MoveRaxis(X5,m_nLampX6 - m_nCurX6);
			CControlCard::WaitRaxisStop(X5);

			CControlCard::MoveRaxis(X0,m_nLampX1 - m_nCurX1);
			CControlCard::WaitRaxisStop(X0);
			CControlCard::MoveRaxis(X1,m_nLampX2 - m_nCurX2);
			CControlCard::WaitRaxisStop(X1);
			CControlCard::MoveRaxis(X2,m_nLampX3 - m_nCurX3);
			CControlCard::WaitRaxisStop(X2);
			CControlCard::MoveRaxis(X3,m_nLampX4 - m_nCurX4);
			CControlCard::WaitRaxisStop(X3);

		}
		break;
	case LAM4:
		{
			CIniClient::Instance(m_strIniName)->GetValue(_T("LAMPLOC4"),_T("LampX1"),szLampX1,NULL);
			CIniClient::Instance(m_strIniName)->GetValue(_T("LAMPLOC4"),_T("LampX2"),szLampX2,NULL);
			CIniClient::Instance(m_strIniName)->GetValue(_T("LAMPLOC4"),_T("LampX3"),szLampX3,NULL);
			CIniClient::Instance(m_strIniName)->GetValue(_T("LAMPLOC4"),_T("LampX4"),szLampX4,NULL);
			CIniClient::Instance(m_strIniName)->GetValue(_T("LAMPLOC4"),_T("LampX5"),szLampX5,NULL);
			CIniClient::Instance(m_strIniName)->GetValue(_T("LAMPLOC4"),_T("LampX6"),szLampX6,NULL);

			m_nLampX1 = atof(szLampX1);
			m_nLampX2 = atof(szLampX2);
			m_nLampX3 = atof(szLampX3);
			m_nLampX4 = atof(szLampX4);
			m_nLampX5 = atof(szLampX5);
			m_nLampX6 = atof(szLampX6);

			
			//��ȡ���λ��
			m_nCurX1 = CControlCard::GetAxisPosition(X0);
			m_nCurX2 = CControlCard::GetAxisPosition(X1);
			m_nCurX3 = CControlCard::GetAxisPosition(X2);
			m_nCurX4 = CControlCard::GetAxisPosition(X3);
			m_nCurX5 = CControlCard::GetAxisPosition(X4);
			m_nCurX6 = CControlCard::GetAxisPosition(X5);

			m_nCurX5 = m_nCurX5 - atof(szDeltaCos) * nCosPos;

			CControlCard::MoveRaxis(X4,m_nLampX5 - m_nCurX5);
			CControlCard::WaitRaxisStop(X4);
			CControlCard::MoveRaxis(X5,m_nLampX6 - m_nCurX6);
			CControlCard::WaitRaxisStop(X5);

			CControlCard::MoveRaxis(X0,m_nLampX1 - m_nCurX1);
			CControlCard::WaitRaxisStop(X0);
			CControlCard::MoveRaxis(X1,m_nLampX2 - m_nCurX2);
			CControlCard::WaitRaxisStop(X1);
			CControlCard::MoveRaxis(X2,m_nLampX3 - m_nCurX3);
			CControlCard::WaitRaxisStop(X2);
			CControlCard::MoveRaxis(X3,m_nLampX4 - m_nCurX4);
			CControlCard::WaitRaxisStop(X3);
	
		}
		break;
	case UPLOC:
		{
			CIniClient::Instance(m_strIniName)->GetValue(_T("UPLOC"),_T("UpLocX1"),szLampX1,NULL);
			CIniClient::Instance(m_strIniName)->GetValue(_T("UPLOC"),_T("UpLocX2"),szLampX2,NULL);
			CIniClient::Instance(m_strIniName)->GetValue(_T("UPLOC"),_T("UpLocX3"),szLampX3,NULL);
			CIniClient::Instance(m_strIniName)->GetValue(_T("UPLOC"),_T("UpLocX4"),szLampX4,NULL);
			CIniClient::Instance(m_strIniName)->GetValue(_T("UPLOC"),_T("UpLocX5"),szLampX5,NULL);
			CIniClient::Instance(m_strIniName)->GetValue(_T("UPLOC"),_T("UpLocX6"),szLampX6,NULL);

			m_nLampX1 = atof(szLampX1);
			m_nLampX2 = atof(szLampX2);
			m_nLampX3 = atof(szLampX3);
			m_nLampX4 = atof(szLampX4);
			m_nLampX5 = atof(szLampX5);
			m_nLampX6 = atof(szLampX6);

			//��ȡ���λ��
			m_nCurX1 = CControlCard::GetAxisPosition(X0);
			m_nCurX2 = CControlCard::GetAxisPosition(X1);
			m_nCurX3 = CControlCard::GetAxisPosition(X2);
			m_nCurX4 = CControlCard::GetAxisPosition(X3);
			m_nCurX5 = CControlCard::GetAxisPosition(X4);
			m_nCurX6 = CControlCard::GetAxisPosition(X5);

			CControlCard::MoveRaxis(X4,m_nLampX5 - m_nCurX5);
			CControlCard::WaitRaxisStop(X4);
			CControlCard::MoveRaxis(X5,m_nLampX6 - m_nCurX6);
			CControlCard::WaitRaxisStop(X5);

			CControlCard::MoveRaxis(X0,m_nLampX1 - m_nCurX1);
			CControlCard::WaitRaxisStop(X0);
			CControlCard::MoveRaxis(X1,m_nLampX2 - m_nCurX2);
			CControlCard::WaitRaxisStop(X1);
			CControlCard::MoveRaxis(X2,m_nLampX3 - m_nCurX3);
			CControlCard::WaitRaxisStop(X2);
			CControlCard::MoveRaxis(X3,m_nLampX4 - m_nCurX4);
			CControlCard::WaitRaxisStop(X3);

		}
		break;
	}
}