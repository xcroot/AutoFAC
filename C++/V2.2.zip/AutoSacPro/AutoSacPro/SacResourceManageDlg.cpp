// SacResourceManageDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "AutoSacPro.h"
#include "SacResourceManageDlg.h"
#include "afxdialogex.h"


// CSacResourceManageDlg �Ի���

IMPLEMENT_DYNAMIC(CSacResourceManageDlg, CDialogEx)

CSacResourceManageDlg::CSacResourceManageDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CSacResourceManageDlg::IDD, pParent)
	, m_nSacSumNum(0)
	, m_nUsedNum(0)
	, m_nRemainNum(0)
	, m_strCurPos(_T(""))
{

}

CSacResourceManageDlg::~CSacResourceManageDlg()
{
}

void CSacResourceManageDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_SACSUM, m_nSacSumNum);
	DDX_Text(pDX, IDC_EDIT_USED, m_nUsedNum);
	DDX_Text(pDX, IDC_EDIT_REMAIN, m_nRemainNum);
	DDX_Text(pDX, IDC_EDIT_CURPOSX, m_strCurPos);
	DDX_Control(pDX, IDC_COMBO_ROWS, m_com_Rows);
	DDX_Control(pDX, IDC_COMBO_COLS, m_com_rows);
}


BEGIN_MESSAGE_MAP(CSacResourceManageDlg, CDialogEx)
	ON_BN_CLICKED(IDOK, &CSacResourceManageDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDC_BUTTON_SUB, &CSacResourceManageDlg::OnBnClickedButtonSub)
	ON_BN_CLICKED(IDC_BUTTON_RESET, &CSacResourceManageDlg::OnBnClickedButtonReset)
END_MESSAGE_MAP()


// CSacResourceManageDlg ��Ϣ��������


void CSacResourceManageDlg::OnBnClickedOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CDialogEx::OnOK();
}


BOOL CSacResourceManageDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	for (int nIndex = 0; nIndex <= 100; nIndex++)
	{
		CString strIde ;
		strIde.Format(_T("%d"),nIndex);
		m_com_Rows.InsertString(nIndex,strIde);
		m_com_rows.InsertString(nIndex,strIde);
	}
	m_com_rows.SetCurSel(0);
	m_com_Rows.SetCurSel(0);

	CSacResourceManage::Instance()->InitSAC();
    UpdateSAC();
	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}


void CSacResourceManageDlg::OnBnClickedButtonSub()
{
	if(!CSacResourceManage::Instance()->SubOne())
		AfxMessageBox(_T("SAC��ʹ������������Ϻ���"));
	UpdateSAC();

}


void CSacResourceManageDlg::OnBnClickedButtonReset()
{
	CSacResourceManage::Instance()->ResetSac();
	UpdateSAC();
}

void CSacResourceManageDlg::UpdateSAC()
{
	m_nSacSumNum = CSacResourceManage::Instance()->GetAllSacNum();
	m_nUsedNum   = CSacResourceManage::Instance()->GetUsedNum();
	m_nRemainNum = CSacResourceManage::Instance()->GetRemainNum();
	int nRows,nCols;
	CSacResourceManage::Instance()->GetCurPos(nRows,nCols);
	m_strCurPos.Format(_T("(%d,%d)"),nRows,nCols);
	UpdateData(FALSE);
}