#include "StdAfx.h"
#include "LampstandManage.h"


CLampstandManage::CLampstandManage(int nPorType)
{
	m_nfinishNum = 0;
	m_nProType = nPorType;
	switch(nPorType)
	{
	case PRO_250W:
		m_nCosNum = 19;
		break;
	case PRO_120W:
		m_nCosNum = 9;
		break;
	}
}


CLampstandManage::~CLampstandManage(void)
{
}

int CLampstandManage::GetCosNum()
{
	return m_nCosNum;
}

int CLampstandManage::GetFinishNum()
{
	return m_nfinishNum;
}

void CLampstandManage::SubOne()
{
	if(m_nCosNum - m_nfinishNum <= 0)
		return;
	m_nfinishNum++;
}

void CLampstandManage::AddOne()
{
	if (m_nCosNum - m_nfinishNum == m_nCosNum)
	{
		return;
	}
	m_nfinishNum--;
}

void CLampstandManage::ReSetCos()
{
	m_nfinishNum = 0;
}

void CLampstandManage::SetCurPos( int nCur )
{
	m_nfinishNum = nCur;
}