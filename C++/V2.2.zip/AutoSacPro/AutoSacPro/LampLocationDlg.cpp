// LampLocationDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "AutoSacPro.h"
#include "LampLocationDlg.h"
#include "afxdialogex.h"
#include "IniClient.h"
#include "MoveToPhotoLoc.h"
#include "SacResourceManage.h"

extern DWORD iOut[20];
// CLampLocationDlg �Ի���

IMPLEMENT_DYNAMIC(CLampLocationDlg, CDialogEx)

CLampLocationDlg::CLampLocationDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CLampLocationDlg::IDD, pParent)
	, m_LlampX1(0)
	, m_LlampX2(0)
	, m_LlampX3(0)
	, m_LSacX1(0)
	, m_LSacX2(0)
	, m_LSacX3(0)
	, m_LlampX4(0)
	, m_LlampX5(0)
	, m_LlampX6(0)
	, m_LSacX4(0)
	, m_LSacX5(0)
	, m_LSacX6(0)
{
	nCurLam = 0;
	m_strIniName = _T("scanlocation.ini"); 
}

CLampLocationDlg::~CLampLocationDlg()
{
}

void CLampLocationDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO_LAMP, m_com_LampSel);
	DDX_Text(pDX, IDC_EDIT_AXIS1, m_LlampX1);
	DDX_Text(pDX, IDC_EDIT_AXIS2, m_LlampX2);
	DDX_Text(pDX, IDC_EDIT_AXIS3, m_LlampX3);
	DDX_Text(pDX, IDC_EDIT_SAC_AXIS1, m_LSacX1);
	DDX_Text(pDX, IDC_EDIT_SAC_AXIS2, m_LSacX2);
	DDX_Text(pDX, IDC_EDIT_SAC_AXIS3, m_LSacX3);
	DDX_Text(pDX, IDC_EDIT_AXIS4, m_LlampX4);
	DDX_Text(pDX, IDC_EDIT_AXIS5, m_LlampX5);
	DDX_Text(pDX, IDC_EDIT_AXIS6, m_LlampX6);
	DDX_Text(pDX, IDC_EDIT_SAC_AXIS4, m_LSacX4);
	DDX_Text(pDX, IDC_EDIT_SAC_AXIS5, m_LSacX5);
	DDX_Text(pDX, IDC_EDIT_SAC_AXIS6, m_LSacX6);
	DDX_Control(pDX, IDC_COM_COSSEL, m_cosSel);
}


BEGIN_MESSAGE_MAP(CLampLocationDlg, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON_AXIS_GET, &CLampLocationDlg::OnBnClickedButtonAxisGet)
	ON_BN_CLICKED(IDOK, &CLampLocationDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDC_BUTTON_AXIS_SET, &CLampLocationDlg::OnBnClickedButtonAxisSet)
	ON_BN_CLICKED(IDC_BUTTON_SAC_SAVE, &CLampLocationDlg::OnBnClickedButtonSacSave)
	ON_BN_CLICKED(IDC_BUTTON_SAC_GET, &CLampLocationDlg::OnBnClickedButtonSacGet)
	ON_BN_CLICKED(IDC_BUTTON_LAMP1, &CLampLocationDlg::OnBnClickedButtonLamp1)
	ON_BN_CLICKED(IDC_BUTTON_LAMP2, &CLampLocationDlg::OnBnClickedButtonLamp2)
	ON_BN_CLICKED(IDC_BUTTON_LAMP3, &CLampLocationDlg::OnBnClickedButtonLamp3)
	ON_BN_CLICKED(IDC_BUTTON_LANP4, &CLampLocationDlg::OnBnClickedButtonLanp4)
	ON_BN_CLICKED(IDC_BUTTON_SAC1, &CLampLocationDlg::OnBnClickedButtonSac1)
	ON_BN_CLICKED(IDC_INITMOTO, &CLampLocationDlg::OnBnClickedInitmoto)
	ON_BN_CLICKED(IDC_RADIO_IOGET_HIGH, &CLampLocationDlg::OnBnClickedRadioIogetHigh)
	ON_BN_CLICKED(IDC_RADIO_IOGET_LOW, &CLampLocationDlg::OnBnClickedRadioIogetLow)
	ON_BN_CLICKED(IDC_RADIO_GLUE_HIGH, &CLampLocationDlg::OnBnClickedRadioGlueHigh)
	ON_BN_CLICKED(IDC_RADIO_GLUE_LOW, &CLampLocationDlg::OnBnClickedRadioGlueLow)
	ON_BN_CLICKED(IDC_RADIO_UPAIR_HIGH, &CLampLocationDlg::OnBnClickedRadioUpairHigh)
	ON_BN_CLICKED(IDC_RADIO_UPAIR_LOW, &CLampLocationDlg::OnBnClickedRadioUpairLow)
	ON_BN_CLICKED(IDC_RADIO_GLUEAIR_HIGH, &CLampLocationDlg::OnBnClickedRadioGlueairHigh)
	ON_BN_CLICKED(IDC_RADIO_GLUEAIR_LOW, &CLampLocationDlg::OnBnClickedRadioGlueairLow)
	ON_BN_CLICKED(IDC_RADIO_VU_HIGH, &CLampLocationDlg::OnBnClickedRadioVuHigh)
	ON_BN_CLICKED(IDC_RADIO_VU_LOW, &CLampLocationDlg::OnBnClickedRadioVuLow)
	ON_BN_CLICKED(IDC_RADIO_PUSHRES_HIGH, &CLampLocationDlg::OnBnClickedRadioPushresHigh)
	ON_BN_CLICKED(IDC_RADIO_PUSHRES_LOW, &CLampLocationDlg::OnBnClickedRadioPushresLow)
	ON_BN_CLICKED(IDC_UPLOAD, &CLampLocationDlg::OnBnClickedUpload)
	ON_BN_CLICKED(IDC_LAYGLUE, &CLampLocationDlg::OnBnClickedLayglue)
	ON_BN_CLICKED(IDC_RADIO_GREEN_HIGH, &CLampLocationDlg::OnBnClickedRadioGreenHigh)
	ON_BN_CLICKED(IDC_RADIO_GREEN_LOW, &CLampLocationDlg::OnBnClickedRadioGreenLow)
	ON_BN_CLICKED(IDC_RADIO_YELLOW_HIGH, &CLampLocationDlg::OnBnClickedRadioYellowHigh)
	ON_BN_CLICKED(IDC_RADIO_YELLOW_LOW, &CLampLocationDlg::OnBnClickedRadioYellowLow)
	ON_BN_CLICKED(IDC_RADIO_RED_HIGH, &CLampLocationDlg::OnBnClickedRadioRedHigh)
	ON_BN_CLICKED(IDC_RADIO_RED_LOW, &CLampLocationDlg::OnBnClickedRadioRedLow)
	ON_BN_CLICKED(IDC_GETSAC, &CLampLocationDlg::OnBnClickedGetsac)
	ON_BN_CLICKED(IDC_PUTSAC, &CLampLocationDlg::OnBnClickedPutsac)
	ON_BN_CLICKED(IDC_PUTRUBBER, &CLampLocationDlg::OnBnClickedPutrubber)
	ON_BN_CLICKED(IDC_RADIO_LAMLight_HIGH, &CLampLocationDlg::OnBnClickedRadioLamlightHigh)
	ON_BN_CLICKED(IDC_RADIO_LAMLight_LOW, &CLampLocationDlg::OnBnClickedRadioLamlightLow)
END_MESSAGE_MAP()


// CLampLocationDlg ��Ϣ��������



BOOL CLampLocationDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	m_com_LampSel.InsertString(0,_T("����1"));
	m_com_LampSel.InsertString(1,_T("����2"));
	m_com_LampSel.InsertString(2,_T("����3"));
	m_com_LampSel.InsertString(3,_T("����4"));
	m_com_LampSel.InsertString(4,_T("����"));
	m_com_LampSel.InsertString(5,_T("�㽺"));
	m_com_LampSel.SetCurSel(0);

	for (int nPos =0 ; nPos < 20; nPos++)
	{
		CString str;
		str.Format(_T("COS%d"),nPos + 1);
		m_cosSel.InsertString(nPos, str);
	}
	m_cosSel.SetCurSel(0);
	

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}


void CLampLocationDlg::OnBnClickedOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CDialogEx::OnOK();
}


void CLampLocationDlg::OnBnClickedButtonAxisSet()
{
	UpdateData(TRUE);
	switch(m_com_LampSel.GetCurSel())
	{
	case 0:
		{
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAMPLOC1"),_T("LampX1"),m_LlampX1,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAMPLOC1"),_T("LampX2"),m_LlampX2,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAMPLOC1"),_T("LampX3"),m_LlampX3,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAMPLOC1"),_T("LampX4"),m_LlampX4,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAMPLOC1"),_T("LampX5"),m_LlampX5,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAMPLOC1"),_T("LampX6"),m_LlampX6,true);
		}
		break;
	case 1:
		{
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAMPLOC2"),_T("LampX1"),m_LlampX1,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAMPLOC2"),_T("LampX2"),m_LlampX2,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAMPLOC2"),_T("LampX3"),m_LlampX3,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAMPLOC2"),_T("LampX4"),m_LlampX4,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAMPLOC2"),_T("LampX5"),m_LlampX5,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAMPLOC2"),_T("LampX6"),m_LlampX6,true);
		}
		break;
	case 2:
		{
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAMPLOC3"),_T("LampX1"),m_LlampX1,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAMPLOC3"),_T("LampX2"),m_LlampX2,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAMPLOC3"),_T("LampX3"),m_LlampX3,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAMPLOC3"),_T("LampX4"),m_LlampX4,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAMPLOC3"),_T("LampX5"),m_LlampX5,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAMPLOC3"),_T("LampX6"),m_LlampX6,true);
		}
		break;
	case 3:
		{
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAMPLOC4"),_T("LampX1"),m_LlampX1,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAMPLOC4"),_T("LampX2"),m_LlampX2,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAMPLOC4"),_T("LampX3"),m_LlampX3,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAMPLOC4"),_T("LampX4"),m_LlampX4,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAMPLOC4"),_T("LampX5"),m_LlampX5,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAMPLOC4"),_T("LampX6"),m_LlampX6,true);
		}
		break;
	case 4:
		{
			CIniClient::Instance(m_strIniName)->SetValue(_T("UPLOC"),_T("UpLocX1"),m_LlampX1,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("UPLOC"),_T("UpLocX1"),m_LlampX2,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("UPLOC"),_T("UpLocX1"),m_LlampX3,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("UPLOC"),_T("UpLocX1"),m_LlampX4,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("UPLOC"),_T("UpLocX1"),m_LlampX5,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("UPLOC"),_T("UpLocX1"),m_LlampX6,true);
		}
		break;
	case 5:
		{
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAYGLUE"),_T("LayGlueX1"),m_LlampX1,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAYGLUE"),_T("LayGlueX2"),m_LlampX2,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAYGLUE"),_T("LayGlueX3"),m_LlampX3,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAYGLUE"),_T("LayGlueX4"),m_LlampX4,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAYGLUE"),_T("LayGlueX5"),m_LlampX5,true);
			CIniClient::Instance(m_strIniName)->SetValue(_T("LAYGLUE"),_T("LayGlueX6"),m_LlampX6,true);
		}
		break;
	}
	
}


void CLampLocationDlg::OnBnClickedButtonSacSave()
{
	UpdateData(TRUE);
	CIniClient::Instance(m_strIniName)->SetValue(_T("SACLOC"),_T("SacX1"),m_LSacX1);
	CIniClient::Instance(m_strIniName)->SetValue(_T("SACLOC"),_T("SacX2"),m_LSacX2);
	CIniClient::Instance(m_strIniName)->SetValue(_T("SACLOC"),_T("SacX3"),m_LSacX3);
	CIniClient::Instance(m_strIniName)->SetValue(_T("SACLOC"),_T("SacX4"),m_LSacX4);
	CIniClient::Instance(m_strIniName)->SetValue(_T("SACLOC"),_T("SacX5"),m_LSacX5);
	CIniClient::Instance(m_strIniName)->SetValue(_T("SACLOC"),_T("SacX6"),m_LSacX6);
}

void CLampLocationDlg::OnBnClickedButtonAxisGet()
{
	m_LlampX1 = CControlCard::GetAxisPosition(X0);
	m_LlampX2 = CControlCard::GetAxisPosition(X1);
	m_LlampX3 = CControlCard::GetAxisPosition(X2);
	m_LlampX4 = CControlCard::GetAxisPosition(X3);
	m_LlampX5 = CControlCard::GetAxisPosition(X4);
	m_LlampX6 = CControlCard::GetAxisPosition(X5);
	UpdateData(FALSE);
}

void CLampLocationDlg::OnBnClickedButtonSacGet()
{
	m_LSacX1 = CControlCard::GetAxisPosition(X0);
	m_LSacX2 = CControlCard::GetAxisPosition(X1);
	m_LSacX3 = CControlCard::GetAxisPosition(X2);
	m_LSacX4 = CControlCard::GetAxisPosition(X3);
	m_LSacX5 = CControlCard::GetAxisPosition(X4);
	m_LSacX6 = CControlCard::GetAxisPosition(X5);
	UpdateData(FALSE);
}


void CLampLocationDlg::OnBnClickedButtonLamp1()
{
	nCurLam = LAM1;
	AfxBeginThread(TheadMoveLoc,this);
}


void CLampLocationDlg::OnBnClickedButtonLamp2()
{
	nCurLam = LAM2;
	AfxBeginThread(TheadMoveLoc,this);
}


void CLampLocationDlg::OnBnClickedButtonLamp3()
{
	nCurLam = LAM3;
	AfxBeginThread(TheadMoveLoc,this);
}


void CLampLocationDlg::OnBnClickedButtonLanp4()
{
	nCurLam = LAM4;
	AfxBeginThread(TheadMoveLoc,this);
}

void CLampLocationDlg::OnBnClickedUpload()
{
	nCurLam = UPLOC;
	AfxBeginThread(TheadMoveLoc,this);
}

void CLampLocationDlg::OnBnClickedButtonSac1()
{
	AfxBeginThread(ThreadMoveSACLoc,this);
}


void CLampLocationDlg::OnBnClickedInitmoto()
{
	AfxBeginThread(TheadInitMoto,this);
}

void CLampLocationDlg::InitMoto()
{

	int nCurPos = CControlCard::GetAxisPosition(X2);

	CControlCard::WriteIO(Card2, iOut[5], HIGHT);
	CControlCard::WriteIO(Card2, iOut[8], LOW);
	CControlCard::WriteIO(Card2, iOut[9], LOW);
	//CControlCard::MoveRaxis(X2,33119 - nCurPos);
	//CControlCard::CardInit();
	int nCount = 0; //��ֹ����

	CControlCard::SartMove(X2,0);
	CControlCard::WaitRaxisStop(X2);
	nCount = 0;
	while(TRUE)
	{
		if(++nCount>100)
			break;
		if (CControlCard::CheckLimitM(X2) == FALSE)
		{
			CControlCard::SetAxisPosition(X2,0);
			break;
		} 
		else
		{
			CControlCard::MoveRaxis(X2,100);
			CControlCard::WaitRaxisStop(X2);
		}
	}

	CControlCard::SartMove(X5,1);
	CControlCard::WaitRaxisStop(X5);

	while(TRUE)
	{
		nCount++;
		if(nCount>100)
			break;

		if (CControlCard::CheckLimitP(X5) == FALSE)
		{
			CControlCard::SetAxisPosition(X5, 0);
			break;
		} 
		else
		{
			CControlCard::MoveRaxis(X5 ,-10);
			CControlCard::WaitRaxisStop(X5);
		}
	}

	CControlCard::SartMove(X4,1);
	CControlCard::WaitRaxisStop(X4);
	nCount = 0;
	while(TRUE)
	{
		if(++nCount>100)
			break;
		if (CControlCard::CheckLimitP(X4) == FALSE)
		{
			CControlCard::SetAxisPosition(X4, 0);
			break;
		} 
		else
		{
			CControlCard::MoveRaxis(X4 ,-10);
			CControlCard::WaitRaxisStop(X4);
		}
	}


	CControlCard::SartMove(X0,1);
	CControlCard::WaitRaxisStop(X0); //�˶�����
	while (TRUE)
	{
		if(++nCount>100)
			break;
		if (CControlCard::CheckLimitP(X0) == FALSE) //�˶�����
		{
			CControlCard::SetAxisPosition(X0,0);
			break;
		}
		else
		{
			CControlCard::MoveRaxis(X0,-10);
		}
	}

	CControlCard::SartMove(X1,1);
	CControlCard::WaitRaxisStop(X1); //�˶�����
	nCount = 0;
	while(TRUE)
	{
		if(++nCount>100)
			break;
		if (CControlCard::CheckLimitP(X1) == FALSE)
		{
			CControlCard::MoveRaxis(X1,-200);
			CControlCard::WaitRaxisStop(X1);
			CControlCard::SetAxisPosition(X1,0);
			break;
		} 
		else
		{
			CControlCard::MoveRaxis(X1,-10);
			CControlCard::WaitRaxisStop(X1);
		}
	}

#if 0
	CControlCard::SartMove(X3,1);
	CControlCard::WaitRaxisStop(X3);
	nCount = 0;
	while(TRUE)
	{
		if(++nCount>100)
			break;
		if (CControlCard::CheckLimitP(X3) == FALSE)
		{
			CControlCard::MoveRaxis(X3,-200);
			CControlCard::WaitRaxisStop(X3);
			CControlCard::SetAxisPosition(X3,0);
			break;
		} 
		else
		{
			CControlCard::MoveRaxis(X3,-10);
			CControlCard::WaitRaxisStop(X3);
			CControlCard::SetAxisPosition(X3,0);
		}
	}
#endif 0
	
	
}

UINT CLampLocationDlg::TheadInitMoto( LPVOID lpParam )
{
	CLampLocationDlg * pLamLoc = (CLampLocationDlg*)lpParam;
	pLamLoc->InitMoto();
	return 0;
}

void CLampLocationDlg::OnBnClickedRadioIogetHigh()
{
	CControlCard::WriteIO(Card2,iOut[2],HIGHT);
}


void CLampLocationDlg::OnBnClickedRadioIogetLow()
{
	CControlCard::WriteIO(Card2,iOut[2],LOW);
}


void CLampLocationDlg::OnBnClickedRadioGlueHigh()
{
	CControlCard::WriteIO(Card2,iOut[34],HIGHT);
}


void CLampLocationDlg::OnBnClickedRadioGlueLow()
{
	CControlCard::WriteIO(Card2,iOut[34],LOW);
}


void CLampLocationDlg::OnBnClickedRadioUpairHigh()
{
	CControlCard::WriteIO(Card2,iOut[9],HIGHT);
}


void CLampLocationDlg::OnBnClickedRadioUpairLow()
{
	CControlCard::WriteIO(Card2,iOut[9],LOW);
}


void CLampLocationDlg::OnBnClickedRadioGlueairHigh()
{
	CControlCard::WriteIO(Card2,iOut[5],HIGHT);
}


void CLampLocationDlg::OnBnClickedRadioGlueairLow()
{
	CControlCard::WriteIO(Card2,iOut[5],LOW);
}


void CLampLocationDlg::OnBnClickedRadioVuHigh()
{
	CControlCard::WriteIO(Card2,iOut[35],HIGHT);
}


void CLampLocationDlg::OnBnClickedRadioVuLow()
{
	CControlCard::WriteIO(Card2,iOut[35],LOW);
}


void CLampLocationDlg::OnBnClickedRadioPushresHigh()
{
	CControlCard::WriteIO(Card2,iOut[8],HIGHT);
}


void CLampLocationDlg::OnBnClickedRadioPushresLow()
{
	CControlCard::WriteIO(Card2,iOut[8],LOW);
}

UINT CLampLocationDlg::TheadMoveLoc( LPVOID lpParam )
{
	CLampLocationDlg *pLoc = (CLampLocationDlg*)lpParam;
    switch(pLoc->nCurLam)
	{
	case LAM1:
		CMoveToPhotoLoc::MovetoLampLoc(pLoc->nCurLam,COS1);
		break;
	case LAM2:
		CMoveToPhotoLoc::MovetoLampLoc(pLoc->nCurLam,COS1);
		break;
	case LAM3:
		CMoveToPhotoLoc::MovetoLampLoc(pLoc->nCurLam,COS1);
		break;
	case LAM4:
		CMoveToPhotoLoc::MovetoLampLoc(pLoc->nCurLam,COS1);
		break;
	case UPLOC:
		CMoveToPhotoLoc::MovetoLampLoc(pLoc->nCurLam,COS1);
		break;
	}
	return 0;
}

UINT CLampLocationDlg::ThreadMoveSACLoc( LPVOID lpParam )
{
	CMoveToPhotoLoc::MovetoSACLoc(0,0);
	return 0;
}


void CLampLocationDlg::OnBnClickedLayglue()
{
	
}


void CLampLocationDlg::OnBnClickedRadioGreenHigh()
{
	CControlCard::WriteIO(Card2, iOut[12], HIGHT);
}


void CLampLocationDlg::OnBnClickedRadioGreenLow()
{
	CControlCard::WriteIO(Card2, iOut[12], LOW);
}


void CLampLocationDlg::OnBnClickedRadioYellowHigh()
{
	CControlCard::WriteIO(Card2, iOut[13], HIGHT);
}


void CLampLocationDlg::OnBnClickedRadioYellowLow()
{
	CControlCard::WriteIO(Card2, iOut[13], LOW);
}


void CLampLocationDlg::OnBnClickedRadioRedHigh()
{
	CControlCard::WriteIO(Card2, iOut[13], HIGHT);
}


void CLampLocationDlg::OnBnClickedRadioRedLow()
{
	CControlCard::WriteIO(Card2, iOut[13], LOW);
}


void CLampLocationDlg::OnBnClickedGetsac()
{
	AfxBeginThread(ThreadStepMoveSACLoc,this);
}

UINT CLampLocationDlg::ThreadStepMoveSACLoc( LPVOID lpParam )
{
	if( 0 == CSacResourceManage::Instance()->GetRemainNum())
	{
		AfxMessageBox(_T("SAC������ʹ���꣬���������"));
		return 0;
	}
	int nX,nY;
	CSacResourceManage::Instance()->GetCurPos(nX, nY);
	CMoveToPhotoLoc::MovetoSACLoc(nX, nY);
	CSacResourceManage::Instance()->SubOne();
	return 0;
}


void CLampLocationDlg::OnBnClickedPutsac()
{
	AfxBeginThread(ThreadPutSac, this);
}

UINT CLampLocationDlg::ThreadPutSac( LPVOID lpParam )
{
	CLampLocationDlg *pCosLoc = (CLampLocationDlg *)lpParam;
	int nCosSel = pCosLoc->m_cosSel.GetCurSel();
	CMoveToPhotoLoc::MovetoLampLoc(0,nCosSel);
	return 0;
}


void CLampLocationDlg::OnBnClickedPutrubber()
{
	//AfxBeginThread(ThreadPutSac, this); //�˶���COSλ��
	AfxBeginThread(ThreadLayRubber, this);
}

UINT CLampLocationDlg::ThreadLayRubber( LPVOID lpParam )
{
#if 0
	CHAR szWStep[50] = { 0 };
	CHAR szHStep[50] = { 0 };
	CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("WStep"), szWStep, NULL);
	CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("HStep"), szHStep, NULL);
	long lWStep,lHStep;

	lWStep = static_cast<long>(atof(szWStep));
	lHStep = static_cast<long>(atof(szHStep));

	CControlCard::MoveRaxis(X0, lWStep);
	CControlCard::MoveRaxis(X1, lHStep);
#endif

	CControlCard::MoveRaxis(X0,-3000);
	CControlCard::WaitRaxisStop(X0);
	//�㽺�����½�
	//CControlCard::WriteIO(Card2, iOut[5], HIGHT);
	//while(TRUE)
	//{
	//	if( CControlCard::ReadIO(Card2, iOut[23]) == 1 ) //�㽺����ȷ��
	//	{
	//		break;
	//	}
	//	Sleep(500);
	//}

	//�㽺����
	//CControlCard::WriteIO(Card2, iOut[34], HIGHT);

	//��ʼ�㽺
	CControlCard::MoveRaxis(X0, 6000);

	//�㽺��Ϲرյ㽺
	//CControlCard::WriteIO(Card2, iOut[34], LOW);

	//̧��㽺����
	//CControlCard::WriteIO(Card2, iOut[4], LOW);
	//while(TRUE)
	//{
	//	if( CControlCard::ReadIO(Card2, iOut[22]) == 1 ) //�㽺����ȷ��
	//	{
	//		break;
	//	}
	//	Sleep(500);
	//}


	return 1;
}


void CLampLocationDlg::OnBnClickedRadioLamlightHigh()
{
	CControlCard::WriteIO(Card2, iOut[37], HIGHT);
}


void CLampLocationDlg::OnBnClickedRadioLamlightLow()
{
	CControlCard::WriteIO(Card2, iOut[37], LOW);
}
