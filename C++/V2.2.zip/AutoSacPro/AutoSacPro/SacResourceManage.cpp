#include "StdAfx.h"
#include "SacResourceManage.h"

static CSacResourceManage * pSac;

CSacResourceManage::CSacResourceManage(void)
{
	m_nCurPosX = m_nCurPosY = 0;
	m_SumSacNum = 0;
	m_UsedNum = 0;
}


CSacResourceManage::~CSacResourceManage(void)
{
}

BOOL CSacResourceManage::GetCurPos( int & dCurPosX,int & dCurPosY )
{
	dCurPosX = m_nCurPosX;
	dCurPosY = m_nCurPosY;
	return TRUE;
}

void CSacResourceManage::ResetSac()
{
	m_nCurPosX = 0;
	m_nCurPosY = 0;
	m_UsedNum  = 0;
}

void CSacResourceManage::InitSAC()
{
	nRows = 10;
	nCols = 10;
	m_SumSacNum = nRows * nCols;
}

BOOL CSacResourceManage::SubOne()
{
	if(!GetRemainNum())
		return FALSE;
	m_UsedNum++;
	m_nCurPosY++;

	ASSERT(m_UsedNum >=0 && m_nCurPosX >=0 && m_nCurPosX >=0);
	if ( m_nCurPosY % nRows == 0 )
	{
		m_nCurPosX ++;
		m_nCurPosY = 0;
	}
	return TRUE;
}

void CSacResourceManage::AddOne()
{
	return;
}

int CSacResourceManage::GetAllSacNum()
{
	return m_SumSacNum;
}

int CSacResourceManage::GetRemainNum()
{
	return m_SumSacNum - m_UsedNum;
}

int CSacResourceManage::GetUsedNum()
{
	return m_UsedNum;
}

void CSacResourceManage::SetRowAndCols( int nRow, int nCol )
{
	this->nRows = nRow;
	this->nCols = nCol;
}

CSacResourceManage * CSacResourceManage::Instance()
{
	if ( NULL == pSac)
	{
		pSac = new CSacResourceManage();
	}
	return pSac;
}