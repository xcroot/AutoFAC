#pragma once
class CLampstandManage
{
public:
	CLampstandManage(int nPorType);
	~CLampstandManage(void);

private:

	int m_nProType;    //��Ʒ����
	int m_nCosNum;     //��Ʒ·��
	int m_nfinishNum;  //��ɵ�·��


public:
	int GetCosNum();
	int GetFinishNum();
	void SubOne();
	void AddOne();
	void ReSetCos();
	void SetCurPos(int nCur);


};

