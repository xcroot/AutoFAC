#include "StdAfx.h"
#include "MySQLAPI.h"
//#include "../Log.h"

CMySQLAPI::CMySQLAPI()
{

}

CMySQLAPI::CMySQLAPI(const char *host, const char *user, const char *password, const char *db, unsigned int port/* =2015 */)
{
	strcpy_s(m_host, host);
	strcpy_s(m_user, user);
	strcpy_s(m_password, password);
	strcpy_s(m_db, db);
	m_port = port;

	InitializeCriticalSection(&m_csList);
}

CMySQLAPI::~CMySQLAPI()
{
	for (ITER_CONNECTION_HANDLE_LIST iter=m_lsBusyList.begin(); iter != m_lsBusyList.end(); iter++)
	{
		mysql_close((*iter));
	}

	for (ITER_CONNECTION_HANDLE_LIST iter=m_lsIdleList.begin(); iter != m_lsIdleList.end(); iter++)
	{
		mysql_close((*iter));
	}

	DeleteCriticalSection(&m_csList);
}

bool CMySQLAPI::ConnectDB(int nRetry)
{
	//ͬʱ��CONNECTION_NUM������(�������ӳ�)
	try
	{
		MYSQL *pMySql = mysql_init((MYSQL*)NULL);
		if (pMySql != NULL)
		{
			for (int j = 0; j < nRetry; ++j)
			{
				if (!mysql_real_connect(pMySql,m_host,m_user,m_password,m_db,m_port,NULL,0))
				{
					AfxMessageBox(_T("�������ݿ�ʧ��(%s),��������..."));
				}
				else
				{
					m_lsIdleList.push_back(pMySql);
					return true;
				}
			}
			return false;
		}
	}
	catch (...)
	{
		return false;
	}
	return true;
}

void CMySQLAPI::CheckConnPool(const char* szSelectSql)
{
	//ֻ�Կ��������б���������ˢ�£���æ�б���������Ϊ���ɵ��ò���ˢ�£�
	EnterCriticalSection(&m_csList);
	for (ITER_CONNECTION_HANDLE_LIST iter=m_lsIdleList.begin(); iter != m_lsIdleList.end(); ++iter)
	{
		MYSQL* pMySql = (MYSQL*)(*iter);
		if (mysql_query(pMySql,szSelectSql) == 0){ //������Ч
			MYSQL_RES * myquery = mysql_store_result(pMySql);
			mysql_free_result(myquery);
		}
		else{ //����ʧЧ
			AfxMessageBox(_T("MySql connection invalid, remove this connection and create new one"));
			mysql_close(pMySql);
			if (NULL != (pMySql = mysql_init((MYSQL*)NULL))){
				if (!mysql_real_connect(pMySql,m_host,m_user,m_password,m_db,m_port,NULL,0))
				{
					AfxMessageBox(_T("���ݿ�����ʧ�ܣ�"));
				}
					//CLog::Instance()->LogErr(OutErrors(pMySql));
			}
		}
	}
	LeaveCriticalSection(&m_csList);
}

MYSQL* CMySQLAPI::GetIdleMySql()
{
	MYSQL* pMySql = NULL;
	while (TRUE)
	{
		EnterCriticalSection(&m_csList);
		if (m_lsIdleList.size() > 0)
		{ //�ӿ����б���ȡ��,���빤���б�
			pMySql = m_lsIdleList.front();
			m_lsIdleList.pop_front();
			m_lsBusyList.push_back(pMySql);
		}
		else
		{
			pMySql = NULL;
		}
		LeaveCriticalSection(&m_csList);
		if (pMySql != NULL) break;
		Sleep(50);
	}
	return pMySql;
}

void CMySQLAPI::SetIdleMysql(MYSQL* pMySql)
{
	//�ӹ����б����Ƴ���������б�
	EnterCriticalSection(&m_csList);
	m_lsBusyList.remove(pMySql);
	m_lsIdleList.push_back(pMySql);
	LeaveCriticalSection(&m_csList);
}

CMySQLRecordset* CMySQLAPI::SelectRecord(const char *szSql)
{
	MYSQL *pMySql = GetIdleMySql();
	if (pMySql == NULL)
		return NULL;
	if(mysql_query(pMySql,szSql) != 0)
	{
		AfxMessageBox(_T("���ݿ��ѯʧ�ܣ�"));
		//CLog::Instance()->LogErr(OutErrors(pMySql));
		SetIdleMysql(pMySql);
		return NULL;
	}

	MYSQL_RES *myquery = NULL;
	myquery = mysql_store_result(pMySql);
	SetIdleMysql(pMySql);

	CMySQLRecordset * rs = new CMySQLRecordset(myquery);
	return rs;
}

bool CMySQLAPI::ExecuteSql(const char *szSql)
{
	bool bRet = true;
	MYSQL *pMySql = GetIdleMySql();
	if (pMySql == NULL)
		return false;

	if(mysql_query(pMySql,szSql) != 0) //ִ�г���
	{
		AfxMessageBox(_T("���ݿ��ѯʧ��!"));
		//CLog::Instance()->LogErr(OutErrors(pMySql));
		bRet = false;
	}
// 	mysql_query(pMySql,_T("COMMIT"));
// 	mysql_close(pMySql);
// 	mysql_library_end();
	SetIdleMysql(pMySql);

	return bRet;
}

bool CMySQLAPI::SelectDB(const char *szDB)
{
	bool bRet = false;
	MYSQL *pMySql = GetIdleMySql();
	if (pMySql == NULL)
	{
		return false;
	}
	if (mysql_select_db(pMySql,szDB))
		bRet = false; 
	else
		bRet = true;
	SetIdleMysql(pMySql);

	return bRet;
}

my_ulonglong CMySQLAPI::GetRowNum(MYSQL_RES *myquery)
{
	return mysql_num_rows(myquery);
}

MYSQL_ROW CMySQLAPI::GetRecord(MYSQL_RES *myquery)
{
	m_row = mysql_fetch_row(myquery);

	return m_row;
}

unsigned int CMySQLAPI::GetFieldNum(MYSQL_RES *myquery)
{
	return mysql_num_fields(myquery);
}

void CMySQLAPI::FreeRecord(MYSQL_RES *myquery)
{
	mysql_free_result(myquery);
}

//int CMySQLAPI::CreateDB(char *db)
//{
// return mysql_create_db(&m_mysql,db);
//}

void CMySQLAPI::SeekData(MYSQL_RES *myquery, int offset)
{
	mysql_data_seek(myquery,offset);
}


char * CMySQLAPI::OutErrors(MYSQL *pMySql)
{
	return const_cast<char *>(mysql_error(pMySql));
}

BOOL CMySQLAPI::IsEnd(MYSQL_RES *myquery)
{
	return mysql_eof(myquery);
}

char* CMySQLAPI::GetFieldName(MYSQL_RES *myquery, int FieldNum)
{
	m_field = mysql_fetch_field_direct(myquery, FieldNum);

	return m_field->name;
}

char * CMySQLAPI::GetClientInfo()
{
	return const_cast<char *>(mysql_get_client_info());
}

char* CMySQLAPI::GetHostInfo()
{
	MYSQL *pMySql = GetIdleMySql();
	if (pMySql == NULL)
	{
		return NULL;
	}
	return const_cast<char *>(mysql_get_host_info(pMySql));
}

int CMySQLAPI::GetProtocolInfo()
{
	int iRet = 0;
	MYSQL *pMySql = GetIdleMySql();
	if (pMySql == NULL)
	{
		return NULL;
	}
	iRet = mysql_get_proto_info(pMySql);
	SetIdleMysql(pMySql);

	return iRet;
}

char* CMySQLAPI::GetServerInfo()
{
	static char szRet[1024];
	MYSQL *pMySql = GetIdleMySql();
	if (pMySql == NULL)
	{
		return NULL;
	}
	_tcscpy_s(szRet, const_cast<char *>(mysql_get_server_info(pMySql)));
	SetIdleMysql(pMySql);

	return szRet;
}

char* CMySQLAPI::GetState()
{
	MYSQL *pMySql = GetIdleMySql();
	if (pMySql == NULL)
	{
		return NULL;
	}
	static char szRet[1024];
	_tcscpy_s(szRet,const_cast<char *>(mysql_stat(pMySql)));
	SetIdleMysql(pMySql);

	return szRet;
}

bool CMySQLAPI::SetCharset()
{
	bool bRet = false;
	char szSql[50];
	strcpy_s(szSql, "set names gb2312");
	MYSQL *pMySql = GetIdleMySql();
	if (pMySql == NULL)
	{
		return false;
	}
	if (mysql_query(pMySql, szSql))
		bRet = true;
	SetIdleMysql(pMySql);

	return bRet;
}

//LOCK TABLES tbl1 READ, tbl2 WRITE
bool CMySQLAPI::LockTable(const char *TableName, const char *Priority)
{
	bool bRet = false;
	char szSql[50];
	sprintf_s(szSql, "LOCK TABLES %s %s", TableName, Priority);
	MYSQL *pMySql = GetIdleMySql();
	if (pMySql == NULL)
	{
		return false;
	}
	if (mysql_query(pMySql, szSql))
		bRet = true;
	SetIdleMysql(pMySql);

	return bRet;
}

bool CMySQLAPI::UnlockTable()
{
	bool bRet = false;
	MYSQL *pMySql = GetIdleMySql();
	if (pMySql == NULL)
	{
		return false;
	}
	if(mysql_query(pMySql,"UNLOCK TABLES"))
		bRet = true;
	SetIdleMysql(pMySql);

	return bRet;

}
