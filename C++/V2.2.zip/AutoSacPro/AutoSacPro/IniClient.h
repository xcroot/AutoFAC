// Ini.h: interface for the CIni class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INI_H__F0B59C5F_AC92_4943_8A69_947B74FF4F14__INCLUDED_)
#define AFX_INI_H__F0B59C5F_AC92_4943_8A69_947B74FF4F14__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <afxTempl.h>

class CIniClient  
{
private:
	bool IsInvaild();
	bool CheckSection(CString Section, const char *Keys[],int keynumber);
	CString m_strFileName;
public:
	CIniClient();
	virtual ~CIniClient();
	static CIniClient * Instance(const CString &strFileName);
	bool test();
	CIniClient(const char * FileName):m_strFileName(FileName){};
	bool SetFileName(char * FileName);
	CString& GetFileName();
	bool SetValue(CHAR * Section, CHAR * Key, CHAR * Value,bool bCreate=true);
	bool SetValue(CHAR * Section, CHAR * Key, int Value,bool bCreate=true);
	bool SetValue(CHAR * Section, CHAR * Key, float Value,bool bCreate=true);
	bool SetValue(CHAR * Section, CHAR * Key, long Value,bool bCreate=true);
	bool GetValue(CHAR * Section, CHAR * Key,CHAR * Value,CHAR * Default=NULL);
	int GetSections(CStringArray& arrSection); 
	int GetKeyValues(CStringArray& arrKey,CStringArray& arrValue,char * Section); 

};

#endif // !defined(AFX_INI_H__F0B59C5F_AC92_4943_8A69_947B74FF4F14__INCLUDED_)
