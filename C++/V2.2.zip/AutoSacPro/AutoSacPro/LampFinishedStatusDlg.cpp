// LampFinishedStatusDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "AutoSacPro.h"
#include "LampFinishedStatusDlg.h"
#include "afxdialogex.h"
#include "LampStandBoxManage.h"


// CLampFinishedStatusDlg �Ի���

IMPLEMENT_DYNAMIC(CLampFinishedStatusDlg, CDialogEx)

CLampFinishedStatusDlg::CLampFinishedStatusDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CLampFinishedStatusDlg::IDD, pParent)
	, m_nSacCoutNum(0)
	, m_nFinishedNum(0)
	, m_nRemainNum(0)
	, m_nSel(0)
	, m_bLampOne(FALSE)
	, m_bLampTwo(FALSE)
	, m_bLampThree(FALSE)
	, m_bLampFour(FALSE)
{

}

CLampFinishedStatusDlg::~CLampFinishedStatusDlg()
{
}

void CLampFinishedStatusDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_COUNTSACNUM, m_nSacCoutNum);
	DDX_Text(pDX, IDC_EDIT_FINISHEDNUM, m_nFinishedNum);
	DDX_Text(pDX, IDC_EDIT_REMAINNUM, m_nRemainNum);
	DDX_Radio(pDX, IDC_RADIO_SEL1, m_nSel);
	DDX_Check(pDX, IDC_CHECK_LAMPONESTATUS, m_bLampOne);
	DDX_Check(pDX, IDC_CHECK_LAMPTWOSTATUS, m_bLampTwo);
	DDX_Check(pDX, IDC_CHECK_LAMPTHREESTATUS, m_bLampThree);
	DDX_Check(pDX, IDC_CHECK_LAMPFOYRSTATUS, m_bLampFour);
}


BEGIN_MESSAGE_MAP(CLampFinishedStatusDlg, CDialogEx)
	ON_BN_CLICKED(IDOK, &CLampFinishedStatusDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDC_RADIO_SEL1, &CLampFinishedStatusDlg::OnBnClickedRadioSel1)
	ON_BN_CLICKED(IDC_RADIO_SEL2, &CLampFinishedStatusDlg::OnBnClickedRadioSel2)
	ON_BN_CLICKED(IDC_RADIO_SEL3, &CLampFinishedStatusDlg::OnBnClickedRadioSel3)
	ON_BN_CLICKED(IDC_RADIO_SEL4, &CLampFinishedStatusDlg::OnBnClickedRadioSel4)
	ON_BN_CLICKED(IDC_BUTTON_SUBONE, &CLampFinishedStatusDlg::OnBnClickedButtonSubone)
	ON_BN_CLICKED(IDC_BUTTON_ADDONE, &CLampFinishedStatusDlg::OnBnClickedButtonAddone)
	ON_BN_CLICKED(IDC_BUTTON_RESET, &CLampFinishedStatusDlg::OnBnClickedButtonReset)
	ON_BN_CLICKED(IDC_BUTTON_NEXTLAMP, &CLampFinishedStatusDlg::OnBnClickedButtonNextlamp)
END_MESSAGE_MAP()


// CLampFinishedStatusDlg ��Ϣ��������


BOOL CLampFinishedStatusDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
    CLampStandBoxManage::instance()->SetCurSel(m_nSel);
	Update();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}


void CLampFinishedStatusDlg::OnBnClickedOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CDialogEx::OnOK();
}


void CLampFinishedStatusDlg::OnBnClickedRadioSel1()
{
	m_nSel = 0;
	Update();
}


void CLampFinishedStatusDlg::OnBnClickedRadioSel2()
{
	m_nSel = 1;
	Update();
}


void CLampFinishedStatusDlg::OnBnClickedRadioSel3()
{
	m_nSel = 2;
	Update();
}


void CLampFinishedStatusDlg::OnBnClickedRadioSel4()
{
	m_nSel = 3;
	Update();
}

void CLampFinishedStatusDlg::Update()
{
	CLampStandBoxManage::instance()->SetCurSel(m_nSel);
	m_nSacCoutNum   = CLampStandBoxManage::instance()->GetCosNum();
	m_nFinishedNum  = CLampStandBoxManage::instance()->GetFinisdNum();
	m_nRemainNum    = m_nSacCoutNum - m_nFinishedNum;
	if (m_nRemainNum == 0)
	{
		switch(m_nSel)
		{
		case 0:
			{
				CLampStandBoxManage::instance()->m_nFinished[0] = 1;
				m_bLampOne = TRUE;
			}
			break;
		case 1:
			{
                CLampStandBoxManage::instance()->m_nFinished[1] = 1;
				m_bLampTwo = TRUE;
			}
			break;
		case 2:
			{
				CLampStandBoxManage::instance()->m_nFinished[2] = 1;
				m_bLampThree = TRUE;
			}
			break;
		case 3:
			{
				CLampStandBoxManage::instance()->m_nFinished[3] = 1;
				m_bLampFour = TRUE;
			}
			break;
		}
	}


	if(CLampStandBoxManage::instance()->m_nFinished[0] == 1)
		m_bLampOne = TRUE;
	else
		m_bLampOne = FALSE;
	if(CLampStandBoxManage::instance()->m_nFinished[1] == 1)
		m_bLampTwo = TRUE;
	else
		m_bLampTwo = FALSE;
	if(CLampStandBoxManage::instance()->m_nFinished[2] == 1)
		m_bLampThree = TRUE;
	else
		m_bLampThree = FALSE;
	if(CLampStandBoxManage::instance()->m_nFinished[3] == 1)
		m_bLampFour = TRUE;
	else
		m_bLampFour = FALSE;

	if (m_bLampOne && m_bLampTwo && m_bLampThree && m_bLampFour)
	{
		AfxMessageBox(_T("������ȫ����װSAC��ɣ����������"));
	}

	
	UpdateData(FALSE);
}

void CLampFinishedStatusDlg::OnBnClickedButtonSubone()
{
	CLampStandBoxManage::instance()->SubOne();
	Update();
}


void CLampFinishedStatusDlg::OnBnClickedButtonAddone()
{
	CLampStandBoxManage::instance()->AddOne();
	Update();
}


void CLampFinishedStatusDlg::OnBnClickedButtonReset()
{
	CLampStandBoxManage::instance()->ReSetCos();
	Update();
}


void CLampFinishedStatusDlg::OnBnClickedButtonNextlamp()
{
	CLampStandBoxManage::instance()->ReSetLam();
	CLampStandBoxManage::instance()->ReSetAllCos();
	Update();
}
