#pragma once
#include "afxwin.h"


// CLampLocationDlg �Ի���

class CLampLocationDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CLampLocationDlg)

public:
	CLampLocationDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CLampLocationDlg();

// �Ի�������
	enum { IDD = IDD_DIALOG_LAMPLOCATEDLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	DECLARE_MESSAGE_MAP()

public:
   void InitMoto();
   static UINT TheadInitMoto( LPVOID lpParam);
   static UINT TheadMoveLoc( LPVOID lpParam);
   static UINT ThreadMoveSACLoc( LPVOID lpParam);
   static UINT ThreadStepMoveSACLoc( LPVOID lpParam );
   static UINT ThreadPutSac(LPVOID lpParam);
   static UINT ThreadLayRubber(LPVOID lpParam);
public:
	CComboBox m_com_LampSel;
	long m_LlampX1;
	long m_LlampX2;
	long m_LlampX3;
	long m_LSacX1;
	long m_LSacX2;
	long m_LSacX3;

	long m_LlampX4;
	long m_LlampX5;
	long m_LlampX6;
	long m_LSacX4;
	long m_LSacX5;
	long m_LSacX6;

	CString m_strIniName;

	int nCurLam;

public:
	afx_msg void OnBnClickedButtonAxisGet();
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedButtonAxisSet();
	afx_msg void OnBnClickedButtonSacSave();
	afx_msg void OnBnClickedButtonSacGet();

	afx_msg void OnBnClickedButtonLamp1();
	afx_msg void OnBnClickedButtonLamp2();
	afx_msg void OnBnClickedButtonLamp3();
	afx_msg void OnBnClickedButtonLanp4();
	afx_msg void OnBnClickedButtonSac1();
	afx_msg void OnBnClickedInitmoto();
	afx_msg void OnBnClickedRadioIogetHigh();
	afx_msg void OnBnClickedRadioIogetLow();
	afx_msg void OnBnClickedRadioGlueHigh();
	afx_msg void OnBnClickedRadioGlueLow();
	afx_msg void OnBnClickedRadioUpairHigh();
	afx_msg void OnBnClickedRadioUpairLow();
	afx_msg void OnBnClickedRadioGlueairHigh();
	afx_msg void OnBnClickedRadioGlueairLow();
	afx_msg void OnBnClickedRadioVuHigh();
	afx_msg void OnBnClickedRadioVuLow();
	afx_msg void OnBnClickedRadioPushresHigh();
	afx_msg void OnBnClickedRadioPushresLow();
	afx_msg void OnBnClickedUpload();
	afx_msg void OnBnClickedLayglue();
	afx_msg void OnBnClickedRadioGreenHigh();
	afx_msg void OnBnClickedRadioGreenLow();
	afx_msg void OnBnClickedRadioYellowHigh();
	afx_msg void OnBnClickedRadioYellowLow();
	afx_msg void OnBnClickedRadioRedHigh();
	afx_msg void OnBnClickedRadioRedLow();
	afx_msg void OnBnClickedGetsac();
	CComboBox m_cosSel;
	afx_msg void OnBnClickedPutsac();
	afx_msg void OnBnClickedPutrubber();
	afx_msg void OnBnClickedRadioLamlightHigh();
	afx_msg void OnBnClickedRadioLamlightLow();
};
