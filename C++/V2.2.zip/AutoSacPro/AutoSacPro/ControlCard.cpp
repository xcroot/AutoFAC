#include "StdAfx.h"
#include "ControlCard.h"
#include "IniClient.h"

double dStartSpeed[6] ; //��ʼ���
double dMoveSpeed[6] ;   //�����ٶ�
double dAcc[6];         //����ʱ��

DWORD iOut[40] = {
	2,4,1,14,16,
	18,7,8,15,17,
	12,13,10,11,15,
	8,9,10,11,12,
	7,6,4,3,5,
	13,14,15,0,0,
	0,0,0,0,9,
	6,5,19,0,0
};

CControlCard::CControlCard(void)
{
	
}


CControlCard::~CControlCard(void)
{
}

WORD CControlCard::CardInit()
{
	Readini();
	WORD ICardNo =  d2410_board_init();
	if (ICardNo <= 0 || ICardNo >5 )
	{
		MessageBox(NULL,_T("�������û�м�⵽DMC2410��!"),_T("����"),MB_OK|MB_ICONWARNING);
		//return 0;
	}
	for (int iCount = 0; iCount < 6; iCount++)
	{
		d2410_config_EL_MODE(iCount, 1);        //�趨0-5������λΪ�ߵ�ƽ��Ч������ͣ
		d2410_set_HOME_pin_logic(iCount, 1, 1); //�趨0-5����ԭ���źŵ͵�ƽ��Ч��ʹ���˲�����
		d2410_config_home_mode(iCount, 0, 1);   //�趨0-5����ģʽΪ��ԭ���ֹͣ��EZ�źų��ִ���Ϊ1
		d2410_set_pulse_outmode(iCount, 2);     //�趨0-5�����趨�������ģʽ
		d2410_config_softlimit(iCount,0,0,1,0,0);
		d2410_set_profile(iCount, dStartSpeed[iCount], dMoveSpeed[iCount], dAcc[iCount], dAcc[iCount]);   //�����ٶȡ����ٶ�
	}
	d2410_config_EL_MODE(0, 3);        //�趨0-5������λΪ�ߵ�ƽ��Ч������ͣ
	d2410_config_EL_MODE(2, 3);        //�趨0-5������λΪ�ߵ�ƽ��Ч������ͣ
	d2410_config_EL_MODE(1, 3); 
	//������I/O��ʼ��Ϊ0
	for ( int i = 0 ; i <40; i++)
	{
		d2410_write_outbit(Card2,iOut[i],0);
	}
	d2410_write_outbit(Card2,iOut[5],1);
	return ICardNo;
}

int CControlCard::SetProfile( WORD axis,double Min_Vel,double Max_Vel,double Tacc,double Tdec )
{
	return d2410_set_profile(axis,Min_Vel,Max_Vel,Tacc,Tdec);
}

int CControlCard::SartMove( WORD axis,WORD dir )
{
	return d2410_t_vmove(axis,dir);
}


WORD CControlCard::GetAxisStatus(WORD axis)
{
	WORD CheckDone;
	try
	{
		CheckDone = d2410_check_done(axis);
	}
	catch(...)
	{
		CheckDone = 1;
	}
	return CheckDone;
}

long CControlCard::GetAxisPosition( WORD axis)
{
	long lPos;
	try
	{
		lPos = d2410_get_position(axis);
	}
	catch(...)
	{
		lPos = 0;
	}
	return lPos;
}

void CControlCard::SetAxisPosition( WORD axis,long current_position )
{
	try
	{
       d2410_set_position(axis, current_position);
	}
	catch(...)
	{

	}
	
}

double CControlCard::GetAxisSpeed(WORD axis)
{
	double dSeed;
	try
	{
		dSeed = d2410_read_current_speed(axis);
	}
	catch(...)
	{
		dSeed = 0.0;
	}
	return dSeed;
}

void CControlCard::DecelStop( WORD axis,double Tdec )
{
	try
	{
		d2410_decel_stop(axis,Tdec);
	}
	catch(...)
	{

	}
}

void CControlCard::EmgStop()
{
	try
	{
		d2410_emg_stop();
	}
	catch(...)
	{

	}
}

void CControlCard::Stop(int axis)
{
	try
	{
		d2410_imd_stop(axis);
	}
	catch(...)
	{

	}
}

void CControlCard::CardClose()
{
	d2410_board_close();
}

int CControlCard::SetDistance( WORD axis,long Dist,WORD posi_mode )
{
	int nPos = 0;
	try
	{
      nPos = d2410_ex_t_pmove( axis, Dist, posi_mode);
	}
	catch(...)
	{

	}
	return nPos;
}

DWORD CControlCard::SetLimit( WORD axis,WORD ON_OFF, WORD source_sel,WORD SL_action, long N_limit,long P_limit )
{
	return d2410_config_softlimit(axis,ON_OFF,source_sel,SL_action,N_limit,P_limit);
}

void CControlCard::Set_EL_MODE( WORD axis, WORD el_mode )
{
    d2410_config_EL_MODE(axis, el_mode);
}

void CControlCard::Set_Home_pin_Logic( WORD axis, WORD org_logic, WORD filter )
{
	d2410_set_HOME_pin_logic(axis, org_logic, filter);
}

void CControlCard::Set_config_home_mode( WORD axis, WORD mode, WORD EZ_count )
{
		d2410_config_home_mode(axis,mode,EZ_count);
}

void CControlCard::Set_Pulse_OutMode( WORD axis,WORD outmode )
{
	
	try
	{
       d2410_set_pulse_outmode(axis, outmode);
	}
	catch(...)
	{

	}
}

void CControlCard::MoveRaxis( WORD axis, long Dist)
{
	try
	{
		d2410_t_pmove(axis, Dist, 0);
	}
	catch (...)
	{
		
	}

	
}

void CControlCard::Readini()
{
	CString m_strIniName = _T("sacproperty.ini");
	TCHAR szX1Speedst[50] = { 0 };
	TCHAR szX1Speedmax[50] = { 0 };
	TCHAR szX1Accel[50] = { 0 };
	TCHAR szX1Dist[50] = { 0 };

	TCHAR szX2Speedst[50] = { 0 };
	TCHAR szX2Speedmax[50] = { 0 };
	TCHAR szX2Accel[50] = { 0 };
	TCHAR szX2Dist[50] = { 0 };

	TCHAR szX3Speedst[50] = { 0 };
	TCHAR szX3Speedmax[50] = { 0 };
	TCHAR szX3Accel[50] = { 0 };
	TCHAR szX3Dist[50] = { 0 };

	TCHAR szX4Speedst[50] = { 0 };
	TCHAR szX4Speedmax[50] = { 0 };
	TCHAR szX4Accel[50] = { 0 };
	TCHAR szX4Dist[50] = { 0 };

	TCHAR szX5Speedst[50] = { 0 };
	TCHAR szX5Speedmax[50] = { 0 };
	TCHAR szX5Accel[50] = { 0 };
	TCHAR szX5Dist[50] = { 0 };

	TCHAR szX6Speedst[50] = { 0 };
	TCHAR szX6Speedmax[50] = { 0 };
	TCHAR szX6Accel[50] = { 0 };
	TCHAR szX6Dist[50] = { 0 };

	CIniClient::Instance(m_strIniName)->GetValue(_T("X0"),_T("Speedst"),szX1Speedst,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X0"),_T("Speedmax"),szX1Speedmax,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X0"),_T("Accel"),szX1Accel,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X0"),_T("Dist"),szX1Dist,NULL);

	CIniClient::Instance(m_strIniName)->GetValue(_T("X1"),_T("Speedst"),szX2Speedst,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X1"),_T("Speedmax"),szX2Speedmax,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X1"),_T("Accel"),szX2Accel,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X1"),_T("Dist"),szX2Dist,NULL);

	CIniClient::Instance(m_strIniName)->GetValue(_T("X2"),_T("Speedst"),szX3Speedst,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X2"),_T("Speedmax"),szX3Speedmax,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X2"),_T("Accel"),szX3Accel,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X2"),_T("Dist"),szX3Dist,NULL);

	CIniClient::Instance(m_strIniName)->GetValue(_T("X3"),_T("Speedst"),szX4Speedst,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X3"),_T("Speedmax"),szX4Speedmax,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X3"),_T("Accel"),szX4Accel,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X3"),_T("Dist"),szX4Dist,NULL);

	CIniClient::Instance(m_strIniName)->GetValue(_T("X4"),_T("Speedst"),szX5Speedst,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X4"),_T("Speedmax"),szX5Speedmax,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X4"),_T("Accel"),szX5Accel,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X4"),_T("Dist"),szX5Dist,NULL);

	CIniClient::Instance(m_strIniName)->GetValue(_T("X5"),_T("Speedst"),szX6Speedst,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X5"),_T("Speedmax"),szX6Speedmax,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X5"),_T("Accel"),szX6Accel,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X5"),_T("Dist"),szX6Dist,NULL);

	dStartSpeed[0]  = atof(szX1Speedst);
	dMoveSpeed[0]   = atof(szX1Speedmax);
	dAcc[0]         = atof(szX1Accel);
	dStartSpeed[1]  = atof(szX2Speedst);
	dMoveSpeed[1]   = atof(szX2Speedmax);
	dAcc[1]         = atof(szX2Accel);
	dStartSpeed[2]  = atof(szX3Speedst);
	dMoveSpeed[2]   = atof(szX3Speedmax);
	dAcc[2]         = atof(szX3Accel);
	dStartSpeed[3]  = atof(szX4Speedst);
	dMoveSpeed[3]   = atof(szX4Speedmax);
	dAcc[3]         = atof(szX4Accel);
	dStartSpeed[4]  = atof(szX5Speedst);
	dMoveSpeed[4]   = atof(szX5Speedmax);
	dAcc[4]         = atof(szX5Accel);
	dStartSpeed[5]  = atof(szX6Speedst);
	dMoveSpeed[5]   = atof(szX6Speedmax);
	dAcc[5]         = atof(szX6Accel);
}

void CControlCard::ResetAll()
{
	double dAxisPos;
	try
	{
		for ( int i = 0 ; i <20; i++)
		{
		   d2410_write_outbit(Card2,iOut[i],0);
		}
		d2410_write_outbit(Card2,iOut[5],0);
	}
	catch (...)
	{
	}

	Sleep(1000);

	try
	{
        dAxisPos = GetAxisPosition(X5);
		MoveRaxis(X5,-dAxisPos);
		

		dAxisPos = GetAxisPosition(X4);
		MoveRaxis(X4,-dAxisPos);

		dAxisPos = GetAxisPosition(X4);
		MoveRaxis(X4,-dAxisPos);

		dAxisPos = GetAxisPosition(X3);
		MoveRaxis(X3,-dAxisPos);

		dAxisPos = GetAxisPosition(X2);
		MoveRaxis(X2,-dAxisPos);

		dAxisPos = GetAxisPosition(X1);
		MoveRaxis(X1,-dAxisPos);

		dAxisPos = GetAxisPosition(X0);
		MoveRaxis(X0,-dAxisPos);

	}
	catch(...)
	{

	}

}

void CControlCard::WaitRaxisStop( WORD axis )
{
	while(GetAxisStatus(axis) == 0)
	{
		//�ȴ��˶�����
	}
}

void CControlCard::StopRaxis( WORD axis)
{
	try
	{
		d2410_decel_stop(axis,dAcc[axis]);
	}
	catch(...)
	{

	}
}

BOOL CControlCard::CheckLimitP( WORD axis )
{
	WORD iStatus;
	try
	{
		iStatus = d2410_axis_io_status(axis);
		return iStatus & 2048;
	}
	catch (...)
	{
		return FALSE;
	}
	
}

BOOL CControlCard::CheckLimitN( WORD axis )
{
	WORD iStatus;
	try
	{
		iStatus = d2410_axis_io_status(axis);
		return iStatus & 2048;
	}
	catch (...)
	{
		return FALSE;
	}
}

BOOL CControlCard::CheckLimitM( WORD axis )
{
	WORD iStatus;
	try
	{
		iStatus = d2410_axis_io_status(axis);
		return iStatus & 8192;
	}
	catch(...)
	{
		return FALSE;
	}

}

void CControlCard::RaxisInit()
{
	int nCount = 0; //��ֹ����

	SartMove(X0,1);
	WaitRaxisStop(X0); //�˶�����
	while (TRUE)
	{
		if(++nCount>100)
			break;
		if (CheckLimitP(X0) == FALSE) //�˶�����
		{
			SetAxisPosition(X0,0);
			break;
		}
		else
		{
			MoveRaxis(X0,-100);
			WaitRaxisStop(X0);
		}
	}

	SartMove(X1,1);
	WaitRaxisStop(X1); //�˶�����
	nCount = 0;
	while(TRUE)
	{
		if(++nCount>100)
			break;
		if (CheckLimitP(X1) == FALSE)
		{
			//MoveRaxis(X1,-200);
			//WaitRaxisStop(X1);
			SetAxisPosition(X1,0);
			break;
		} 
		else
		{
			MoveRaxis(X1,-100);
			WaitRaxisStop(X1);
		}
	}

	SartMove(X2,1);
	WaitRaxisStop(X2);
	nCount = 0;
	while(TRUE)
	{
		if(++nCount>100)
			break;
		if (CheckLimitP(X2) == FALSE)
		{
			//MoveRaxis(X2,-200);
			//WaitRaxisStop(X2);
			SetAxisPosition(X2,0);
			break;
		} 
		else
		{
			MoveRaxis(X2,-100);
			WaitRaxisStop(X2);
			//SetAxisPosition(X2,0);
		}
	}


	SartMove(X3,1);
	WaitRaxisStop(X3);
	nCount = 0;
	while(TRUE)
	{
		if(++nCount>100)
			break;
		if (CheckLimitP(X3) == FALSE)
		{
			//MoveRaxis(X3,-200);
			//WaitRaxisStop(X3);
			SetAxisPosition(X3,0);
			break;
		} 
		else
		{
			MoveRaxis(X3,-10);
			WaitRaxisStop(X3);
			//SetAxisPosition(X3,0);
		}
	}

	SartMove(X4,1);
	WaitRaxisStop(X4);
	nCount = 0;
	while(TRUE)
	{
		if(++nCount>100)
			break;
		if (CheckLimitP(X4) == FALSE)
		{
			//MoveRaxis(X4, -200);
			//WaitRaxisStop(X4);
			SetAxisPosition(X4, 0);
			break;
		} 
		else
		{
			MoveRaxis(X4 ,-100);
			WaitRaxisStop(X4);
			SetAxisPosition(X4, 0);
		}
	}

	SartMove(X5,0);
	WaitRaxisStop(X5);

	while(TRUE)
	{
		nCount++;
		if(nCount>100)
			break;

		if (CheckLimitP(X5) == FALSE)
		{
			//MoveRaxis(X5, 200);
			//WaitRaxisStop(X5);
			SetAxisPosition(X5, 0);
			break;
		} 
		else
		{
			MoveRaxis(X5 ,100);
			WaitRaxisStop(X5);
			//SetAxisPosition(X5, 0);
		}
	}
}

void CControlCard::HomeMove( WORD axis, WORD home_mode, WORD vel_mode )
{
	try
	{
		d2410_home_move(axis, home_mode ,vel_mode);
	}
	catch (...)
	{
		
	}

	
}

int CControlCard::ReadIO( WORD cardno,WORD bitno )
{
	return d2410_read_inbit(cardno,bitno);
}

void CControlCard::WriteIO( WORD cardno, WORD bitno, WORD on_ff )
{
	d2410_write_outbit(cardno, bitno, on_ff);
}


