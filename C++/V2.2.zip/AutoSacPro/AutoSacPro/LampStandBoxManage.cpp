#include "StdAfx.h"
#include "LampStandBoxManage.h"
static CLampStandBoxManage *pStapBox = NULL;

CLampStandBoxManage::CLampStandBoxManage(void)
{
	pLamOne = new CLampstandManage(PRO_250W);
	pLamTwo = new CLampstandManage(PRO_250W);
	pLamThree = new CLampstandManage(PRO_250W);
	pLamFour  = new CLampstandManage(PRO_250W);
	m_nCurSel = 0;
	for (int i = 0 ; i < 4; i++)
	{
		m_nFinished[i] = 0;
	}
	m_nStep = 50;
}


CLampStandBoxManage::~CLampStandBoxManage(void)
{
	delete  pLamOne;
    delete  pLamTwo;
	delete  pLamThree;
	delete  pLamFour;
}

CLampStandBoxManage * CLampStandBoxManage::instance()
{
	if (pStapBox == NULL)
	{
		pStapBox = new CLampStandBoxManage();
	}

	return pStapBox;
}

int CLampStandBoxManage::GetCosNum()
{
	int nSel = 0;
	switch(m_nCurSel)
	{
	case 0:
		{
			nSel = pLamOne->GetCosNum();
		}
		break;
	case 1:
		{
			nSel = pLamTwo->GetCosNum();
		}
		break;
	case 2:
		{
			nSel = pLamThree->GetCosNum();
		}
		break;
	case  3:
		{
			nSel = pLamFour->GetCosNum();
		}
		break;
	}
	return nSel;
}

int CLampStandBoxManage::GetFinisdNum()
{
	int nSel = 0;
	switch(m_nCurSel)
	{
	case 0:
		{
			nSel = pLamOne->GetFinishNum();
		}
		break;
	case 1:
		{
			nSel = pLamTwo->GetFinishNum();
		}
		break;
	case 2:
		{
			nSel = pLamThree->GetFinishNum();
		}
		break;
	case  3:
		{
			nSel = pLamFour->GetFinishNum();
		}
		break;
	}
	return nSel;
}

void CLampStandBoxManage::SubOne()
{
	switch(m_nCurSel)
	{
	case 0:
		{
			 pLamOne->SubOne();
		}
		break;
	case 1:
		{
			 pLamTwo->SubOne();
		}
		break;
	case 2:
		{
			 pLamThree->SubOne();
		}
		break;
	case  3:
		{
		     pLamFour->SubOne();
		}
		break;
	}
}

void CLampStandBoxManage::AddOne()
{
	switch(m_nCurSel)
	{
	case 0:
		{
			pLamOne->AddOne();
		}
		break;
	case 1:
		{
			pLamTwo->AddOne();
		}
		break;
	case 2:
		{
			pLamThree->AddOne();
		}
		break;
	case  3:
		{
			pLamFour->AddOne();
		}
		break;
	}
}

void CLampStandBoxManage::ReSetCos()
{
	switch(m_nCurSel)
	{
	case 0:
		{
			pLamOne->ReSetCos();
		}
		break;
	case 1:
		{
			pLamTwo->ReSetCos();
		}
		break;
	case 2:
		{
			pLamThree->ReSetCos();
		}
		break;
	case  3:
		{
			pLamFour->ReSetCos();
		}
		break;
	}
}

void CLampStandBoxManage::SetCurPos( int nCur )
{
	switch(m_nCurSel)
	{
	case 0:
		{
			pLamOne->SetCurPos(nCur);
		}
		break;
	case 1:
		{
			pLamTwo->SetCurPos(nCur);
		}
		break;
	case 2:
		{
			pLamThree->SetCurPos(nCur);
		}
		break;
	case  3:
		{
			pLamFour->SetCurPos(nCur);
		}
		break;
	}
}

int CLampStandBoxManage::GetCurSel()
{
	return m_nCurSel;
}

void CLampStandBoxManage::SetCurSel( int nCur )
{
	m_nCurSel = nCur;
}

void CLampStandBoxManage::ReSetLam()
{
	m_nCurSel = 0;
	for (int i = 0 ; i < 4; i++)
	{
		m_nFinished[i] = 0;
	}
}

void CLampStandBoxManage::ReSetAllCos()
{
	pLamOne->SetCurPos(0);
	pLamTwo->SetCurPos(0);
	pLamThree->SetCurPos(0);
	pLamFour->SetCurPos(0);
}