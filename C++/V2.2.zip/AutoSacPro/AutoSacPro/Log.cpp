//   Log.cpp:   implementation   of   the   CLog   class.  
  //  
  //////////////////////////////////////////////////////////////////////  
   
  #include	"StdAfx.h"  
  #include  "Log.h"
  #include  <fstream>  
  #include  <sstream>  
  #include  <stdarg.h>  
  #include  <time.h> 
  #include	<iostream>
  #include "afxmt.h"
  
  #ifdef   _DEBUG  
  #undef   THIS_FILE  
  static   char   THIS_FILE[]=__FILE__;  
  #define   new   DEBUG_NEW  
  #endif
  
 static CLog* pLog=NULL;
 static CCriticalSection wrireLock;
 static std::ofstream logfile;

 CLog::CLog(const char* str) 
 {  
	OpenLogFile(str);
	loginfolevel=0;
	m_bUseLogList = false;
 }
 CLog::~CLog()
 {
	logfile.close();
 } 

 CLog* CLog::Instance()
 {
	if(NULL==pLog) 
	{
		pLog = new CLog(GetPath());
	}
	return pLog;
 }

 void CLog::OpenLogFile(const char* szPath)
 {
	 strFile = szPath;
	 setlocale(LC_ALL,"Chinese-simplified");//�������Ļ���
	 logfile.open(strFile.c_str(),std::ios_base::app);
	 setlocale(LC_ALL,"C");//��ԭ
 }

 CString CLog::GetPath()
 {
	 char FilePath[MAX_PATH];
	 CString path;
	 GetModuleFileName(NULL, FilePath, sizeof(FilePath));
	 int n=CString(FilePath).ReverseFind('\\');
	 path=CString(FilePath).Left(n+1);
	 path+="log.txt";
	 return path;
 }

void CLog::LogErr(const char *lpszFormat, ...)
{
	char strTmp[2048];
	va_list   argList;
	va_start(argList,lpszFormat);  
	_vsnprintf_s(strTmp,sizeof(strTmp),_TRUNCATE,lpszFormat,argList);  
	va_end(argList);
	Write("����",strTmp);
//	ReportError();
}

void CLog::LogInfo(int Infolevel,const char *lpszFormat, ...)
{
	if(loginfolevel<Infolevel) return ;
	char strTmp[2048];
	va_list   argList;
	va_start(argList,lpszFormat);  
	_vsnprintf_s(strTmp,sizeof(strTmp),_TRUNCATE,lpszFormat,argList);  
	va_end(argList);
	Write("��Ϣ",strTmp);	
}

void CLog::LogInfo(const char* Message)
{
	Write("��Ϣ",Message);	
}

void CLog::LogInfon(const char *lpszFormat, ...)
{
	char strTmp[2048];
	va_list   argList;
	va_start(argList,lpszFormat);  
	_vsnprintf_s(strTmp,sizeof(strTmp),_TRUNCATE,lpszFormat,argList);  
	va_end(argList);
	Write("��Ϣ",strTmp);	
}

void CLog::LogWarning(const char *lpszFormat, ...)
{
	char strTmp[2048];
	va_list   argList;
	va_start(argList,lpszFormat);  
	_vsnprintf_s(strTmp,sizeof(strTmp),_TRUNCATE,lpszFormat,argList);  
	va_end(argList);	
	Write("����",strTmp);	
}

bool CLog::SetIogInfoLevel(int level)
{
	loginfolevel=level;
	return true;
}

void CLog::Write(const char *typeflag, const char *msg)
{
	wrireLock.Lock();
	_strdate_s(strDate,9);
	_strtime_s(strTime,9);
	//logfile<<typeflag<<"["<<_strdate_s(strDate)<<" "<<_strtime_s(strTime)<<"]:"<<msg<<"\n";
	//�������־
	if (!logfile.is_open()) OpenLogFile(GetPath());

	CString strLog;
	strLog.Format(_T("%s[%s %s]:%s"), typeflag, strDate, strTime, msg);

	logfile << strLog << "\n";
	//logfile<<typeflag<<"["<<strDate<<" "<<strTime<<"]:"<<msg<<"\n";
	logfile.flush();
	//���������̨
	std::cout << strLog << std::endl;
	//std::cout<<typeflag<<"["<<strDate<<" "<<strTime<<"]:"<<msg<<std::endl;

	
	//����������ڴ�
	if (m_bUseLogList)
		AddList(strLog);

	wrireLock.Unlock();
}

void CLog::ReportError()
{
	LPVOID pMsgBuf;
	FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_SYS_DEFAULT),
		(LPTSTR)&pMsgBuf, 0, NULL);
	Write("ԭ��", (LPCTSTR)pMsgBuf);
	LocalFree(pMsgBuf);
} 