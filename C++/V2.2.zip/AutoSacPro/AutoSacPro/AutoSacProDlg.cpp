
// AutoSacProDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "AutoSacPro.h"
#include "AutoSacProDlg.h"
#include "afxdialogex.h"

#include "SacResourceManage.h"
#include "LampStandBoxManage.h"
#include "MoveToPhotoLoc.h"

int logic=1;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// ����Ӧ�ó��򡰹��ڡ��˵���� CAboutDlg �Ի���

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// �Ի�������
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

// ʵ��
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CAutoSacProDlg �Ի���




CAutoSacProDlg::CAutoSacProDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CAutoSacProDlg::IDD, pParent)
	, m_nSACSum(0)
	, m_nSACUsed(0)
	, m_nSACRemain(0)
	, m_nCurLamp(0)
	, m_nCosSum(0)
	, m_nFinished(0)
	, m_nCosRemain(0)
{
	m_bLogic = TRUE;
	m_bSymmetry = FALSE;
	m_fAccel = 0.1;
	m_fDecel = 0.1;
	m_nPulse = 6400;
	m_nSacc = 100;
	m_nSdec = 100;
	m_nSpeed = 3200;
	m_nStart = 1600;
	m_nActionst = 0;
	m_nAxis = 0;
	m_nSpeedst = 0;
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	PMotionDlg = NULL;
	PSacResourceDlg = NULL;
	PLampLocatio  = NULL;
	PFinishedDlg  = NULL;
	nCurLampSel = 0;
	pThreadOpr = NULL;
	pAutoThread = NULL;
	if (m_EventMaster != NULL)
	{
		ResetEvent(m_EventMaster);
	}
	m_EventMaster = CreateEvent(NULL,TRUE,FALSE,NULL);

	if (m_EventTast != NULL)
	{
		ResetEvent(m_EventTast);
	}
	m_EventTast = CreateEvent(NULL,TRUE,FALSE,NULL);



}

void CAutoSacProDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATICVIDEO, m_VideoShow);
	DDX_Control(pDX, IDC_BTN_START, m_cButtonLive);
	DDX_Control(pDX, IDC_SETING, m_cButtonSettings);


	DDX_Text(pDX, IDC_EDIT_SACSUM, m_nSACSum);
	DDX_Text(pDX, IDC_EDIT_SACUSED, m_nSACUsed);
	DDX_Text(pDX, IDC_EDIT_REMAIN, m_nSACRemain);
	DDX_Text(pDX, IDC_CURLAM, m_nCurLamp);
	DDX_Text(pDX, IDC_COSSUM, m_nCosSum);
	DDX_Text(pDX, IDC_COSUSED, m_nFinished);
	DDX_Text(pDX, IDC_COSREMAIN, m_nCosRemain);
	DDX_Control(pDX, IDC_COM_LAMPSEL, m_com_LamSel);
	DDX_Control(pDX, IDC__MSGSHOW, m_CMsgShow);
}

BEGIN_MESSAGE_MAP(CAutoSacProDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BTN_DEVICE, &CAutoSacProDlg::OnBnClickedBtnDevice)
	ON_BN_CLICKED(IDC_SETING, &CAutoSacProDlg::OnBnClickedSeting)
	ON_BN_CLICKED(IDC_BTN_START, &CAutoSacProDlg::OnBnClickedBtnStart)
	ON_WM_DESTROY()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_PICTURENAP, &CAutoSacProDlg::OnBnClickedPicturenap)
	ON_COMMAND(ID_MENU_MOTIONSIN, &CAutoSacProDlg::OnMenuMotionsin)
	ON_BN_CLICKED(IDC_EMGSTOP, &CAutoSacProDlg::OnBnClickedEmgstop)
	ON_BN_CLICKED(IDC_ALLRESET, &CAutoSacProDlg::OnBnClickedAllreset)
	ON_BN_CLICKED(IDC_START, &CAutoSacProDlg::OnBnClickedStart)
	ON_COMMAND(ID_MENU_SAC, &CAutoSacProDlg::OnMenuSac)
	ON_COMMAND(ID_MENU_LOCATESET, &CAutoSacProDlg::OnMenuLocateset)
	ON_COMMAND(ID_MENU_LAMPSTATUS, &CAutoSacProDlg::OnMenuLampstatus)
	ON_BN_CLICKED(IDC_BTN_COS1, &CAutoSacProDlg::OnBnClickedBtnCos1)
	ON_BN_CLICKED(IDC_BTN_CO2, &CAutoSacProDlg::OnBnClickedBtnCo2)
	ON_BN_CLICKED(IDC_BTN_COS3, &CAutoSacProDlg::OnBnClickedBtnCos3)
	ON_BN_CLICKED(IDC_BTN_COS4, &CAutoSacProDlg::OnBnClickedBtnCos4)
	ON_BN_CLICKED(IDC_BTN_COS5, &CAutoSacProDlg::OnBnClickedBtnCos5)
	ON_BN_CLICKED(IDC_BTN_COS6, &CAutoSacProDlg::OnBnClickedBtnCos6)
	ON_BN_CLICKED(IDC_BTN_COS7, &CAutoSacProDlg::OnBnClickedBtnCos7)
	ON_BN_CLICKED(IDC_BTN_COS8, &CAutoSacProDlg::OnBnClickedBtnCos8)
	ON_BN_CLICKED(IDC_BTN_COS9, &CAutoSacProDlg::OnBnClickedBtnCos9)
	ON_BN_CLICKED(IDC_BTN_COS10, &CAutoSacProDlg::OnBnClickedBtnCos10)
	ON_BN_CLICKED(IDC_BTN_COS11, &CAutoSacProDlg::OnBnClickedBtnCos11)
	ON_BN_CLICKED(IDC_BTN_COS12, &CAutoSacProDlg::OnBnClickedBtnCos12)
	ON_BN_CLICKED(IDC_BTN_COS13, &CAutoSacProDlg::OnBnClickedBtnCos13)
	ON_BN_CLICKED(IDC_BTN_COS14, &CAutoSacProDlg::OnBnClickedBtnCos14)
	ON_BN_CLICKED(IDC_BTN_COS15, &CAutoSacProDlg::OnBnClickedBtnCos15)
	ON_BN_CLICKED(IDC_BTN_COS16, &CAutoSacProDlg::OnBnClickedBtnCos16)
	ON_BN_CLICKED(IDC_BTN_COS17, &CAutoSacProDlg::OnBnClickedBtnCos17)
	ON_BN_CLICKED(IDC_BTN_COS18, &CAutoSacProDlg::OnBnClickedBtnCos18)
	ON_BN_CLICKED(IDC_BTN_COS19, &CAutoSacProDlg::OnBnClickedBtnCos19)
	ON_CBN_SELCHANGE(IDC_COM_LAMPSEL, &CAutoSacProDlg::OnCbnSelchangeComLampsel)
	ON_BN_CLICKED(IDC_CHECK_SINGLE, &CAutoSacProDlg::OnBnClickedCheckSingle)
	ON_BN_CLICKED(IDC_PUSTRES, &CAutoSacProDlg::OnBnClickedPustres)
	ON_MESSAGE(WM_ERRMESSAGE,OnErrMsgShow)
END_MESSAGE_MAP()


// CAutoSacProDlg ��Ϣ��������

BOOL CAutoSacProDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// ��������...���˵������ӵ�ϵͳ�˵��С�

	// IDM_ABOUTBOX ������ϵͳ���Χ�ڡ�
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO: �ڴ����Ӷ���ĳ�ʼ������
    //������ֳ�ʼ��
	m_VideoShow.SetWindowPos(NULL,0,0,640,480,SWP_NOMOVE|SWP_NOZORDER);

	m_cGrabber.addListener(&m_cListener);
	m_cListener.SetParent(this);
	m_cListener.SetViewCWnd(&m_VideoShow);
	m_pSink = FrameHandlerSink::create(DShowLib::eY800,3);
	m_pSink->setSnapMode(FALSE);
	m_cGrabber.setSinkType(m_pSink);

	if(m_cGrabber.loadDeviceStateFromFile("device.xml"))
	{
	   SetWindowText("AutoSacPro" + CString(m_cGrabber.getDev().c_str()));
	   m_cGrabber.startLive(FALSE);
	}
	SkinH_Attach();
	//�˶����Ʋ���
    CControlCard::CardInit();

	SetButtonStatus();
	SetTimer( 1, 100, NULL );

	m_com_LamSel.InsertString(0,_T("����1"));
	m_com_LamSel.InsertString(1,_T("����2"));
	m_com_LamSel.InsertString(2,_T("����3"));
	m_com_LamSel.InsertString(3,_T("����4"));
	m_com_LamSel.SetCurSel(0);

	CSacResourceManage::Instance()->InitSAC();
//ʵ�����д�
	//��ֹ����
	for (int nIndex = IDC_BTN_COS1 ; nIndex <= IDC_BTN_COS19; nIndex++)
	{
		GetDlgItem(nIndex)->EnableWindow(FALSE); //��·ģʽ
	}
	//GetDlgItem(IDC_START)->EnableWindow(FALSE);  //һ��ģʽ


	m_CMsgShow.LoadMatrix(IDB_MATRIX5x7);
	m_CMsgShow.SetSegmentStyle(MatrixSquare, FALSE);
	m_CMsgShow.SetBlink( 500 );
	m_CMsgShow.SetWindowText(_T("OFF"));
	m_CMsgShow.SetColor(RGB(255,255,0));
	m_CMsgShow.SetValueNbDigit(3,0);
	m_CMsgShow.StringMode(TRUE, FALSE);

	d2410_config_EMG_PIN(0, 1, 1);
	d2410_config_EMG_PIN(1, 1, 1);
	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

void CAutoSacProDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CAutoSacProDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR CAutoSacProDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void  CAutoSacProDlg::SetButtonStatus()
{
	bool bDevValid = m_cGrabber.isDevValid();
	bool bIsLive   = m_cGrabber.isLive();

	m_cButtonSettings.EnableWindow(bDevValid);
	m_cButtonLive.EnableWindow(bDevValid);

	if(!bDevValid)
	{
		m_cButtonLive.SetWindowText("�������");
	}
	if(bIsLive)
	{
		m_cButtonLive.SetWindowText("�رռ��");
	}
	else
	{
	   m_cButtonLive.SetWindowText("�������");
	}


}

void CAutoSacProDlg::OnCancel()
{
	m_cGrabber.stopLive();
	CDialogEx::OnCancel();
}


void CAutoSacProDlg::OnBnClickedBtnDevice()
{
	if(m_cGrabber.isDevValid() && m_cGrabber.isLive())
	{
		m_cGrabber.stopLive();
	}
	m_cGrabber.showDevicePage(this->m_hWnd);
	if(m_cGrabber.isDevValid())
	{
		m_cGrabber.saveDeviceStateToFile("device.xml");
	}
	SetWindowText("AutoSacPro " + CString(m_cGrabber.getDev().c_str()));
	SetButtonStatus();
}


void CAutoSacProDlg::OnBnClickedSeting()
{
	if(m_cGrabber.isDevValid())
	{
		m_cGrabber.showVCDPropertyPage(this->m_hWnd);
		m_cGrabber.saveDeviceStateToFile("device.xml");
	}
}


void CAutoSacProDlg::OnBnClickedBtnStart()
{
	try
	{
		if(m_cGrabber.isDevValid())
		{
			if(m_cGrabber.isLive())
			{
				m_cGrabber.stopLive();
			}
			else
			{
				m_cGrabber.startLive(false);
			}
			SetButtonStatus();
		}
	}
	catch(...)
	{
	   MessageBox("����������豸�Ƿ���������!", "��ܰ��ʾ", MB_OK|MB_ICONERROR);
	}
}


void CAutoSacProDlg::OnDestroy()
{
	m_cGrabber.stopLive();
	CControlCard::CardClose();
	KillTimer( 1 );
	CDialogEx::OnDestroy();
}


void CAutoSacProDlg::OnTimer(UINT_PTR nIDEvent)
{
	m_nSACSum    = CSacResourceManage::Instance()->GetAllSacNum();
	m_nSACUsed   = CSacResourceManage::Instance()->GetUsedNum();
	m_nSACRemain = CSacResourceManage::Instance()->GetRemainNum();

	m_nCurLamp  = CLampStandBoxManage::instance()->GetCurSel() + 1;
	m_nCosSum   = CLampStandBoxManage::instance()->GetCosNum();
	m_nFinished = CLampStandBoxManage::instance()->GetFinisdNum();
	m_nCosRemain= m_nCosSum - m_nFinished;

	if(CControlCard::ReadIO(Card2,iOut[9]) && CControlCard::ReadIO(Card2,iOut[17]) && !CControlCard::ReadIO(Card2,iOut[18])) //�����⵽��ʼ��ť���²��ܲ�������
	{
		for (int nIndex = IDC_BTN_COS1 ; nIndex <= IDC_BTN_COS19; nIndex++)
		{
		//	GetDlgItem(nIndex)->EnableWindow(TRUE); //��·ģʽ
		}
		GetDlgItem(IDC_START)->EnableWindow(TRUE);  //һ��ģʽ
	}

	if (CControlCard::ReadIO(Card2, iOut[18]))
	{
		//�����ͣ
		//Emgstop();
	}
	UpdateData(FALSE);
	CDialogEx::OnTimer(nIDEvent);
}


void CAutoSacProDlg::OnBnClickedPicturenap()
{
    SaveImages();
}


void CAutoSacProDlg::OnMenuMotionsin()
{
	if (PMotionDlg == NULL)
	{
		PMotionDlg = new CMotionTestDlg();
		PMotionDlg ->Create(IDD_MOTIONDLG,this);
	}
	PMotionDlg->ShowWindow(SW_SHOW);
}


void CAutoSacProDlg::OnBnClickedEmgstop()
{
	::PostMessage(this->m_hWnd,WM_ERRMESSAGE,RUN_EMG,NULL);
	Emgstop();
}


void CAutoSacProDlg::OnBnClickedAllreset()
{
	AfxBeginThread(ReSetAllThread,this);
}

UINT CAutoSacProDlg::ReSetAllThread( LPVOID lpParam )
{
	CControlCard::ResetAll();
	return 0;
}

void CAutoSacProDlg::OnBnClickedStart()
{
	SetEvent(m_EventMaster);
	::PostMessage(this->m_hWnd, WM_ERRMESSAGE, RUN_NORMAL, NULL);
	pAutoThread = AfxBeginThread(AutoThread, this);

}


void CAutoSacProDlg::OnMenuSac()
{
	if (PSacResourceDlg == NULL)
	{
		PSacResourceDlg = new CSacResourceManageDlg();
		PSacResourceDlg->Create(IDD_DIALOG_SACRESDLG,this);
	}
	PSacResourceDlg->ShowWindow(SW_SHOW);
}


void CAutoSacProDlg::OnMenuLocateset()
{
	if (PLampLocatio == NULL)
	{
		PLampLocatio = new CLampLocationDlg();
		PLampLocatio->Create(IDD_DIALOG_LAMPLOCATEDLG,this);
	}
	PLampLocatio->ShowWindow(SW_SHOW);
}


void CAutoSacProDlg::OnMenuLampstatus()
{
	if (PFinishedDlg == NULL)
	{
		PFinishedDlg = new CLampFinishedStatusDlg();
		PFinishedDlg->Create(IDD_DIALOG_LANPSTATUS,this);
	}
	PFinishedDlg->ShowWindow(SW_SHOW);
}


void CAutoSacProDlg::OnBnClickedBtnCos1()
{
	nSelCos = COS1;
	if( 0 == CSacResourceManage::Instance()->GetRemainNum())
	{
		AfxMessageBox(_T("SAC������ʹ���꣬���������"));
		return;
	}
	pThreadOpr = AfxBeginThread(OPera,this); //��ʼָ������

}


void CAutoSacProDlg::OnBnClickedBtnCo2()
{
	nSelCos = COS2;
	if( 0 == CSacResourceManage::Instance()->GetRemainNum())
	{
		AfxMessageBox(_T("SAC������ʹ���꣬���������"));
		return;
	}
	pThreadOpr = AfxBeginThread(OPera,this); //��ʼָ������
}


void CAutoSacProDlg::OnBnClickedBtnCos3()
{
	nSelCos = COS3;
	if( 0 == CSacResourceManage::Instance()->GetRemainNum())
	{
		AfxMessageBox(_T("SAC������ʹ���꣬���������"));
		return;
	}
	pThreadOpr = AfxBeginThread(OPera,this); //��ʼָ������
}


void CAutoSacProDlg::OnBnClickedBtnCos4()
{
	nSelCos = COS4;
	if( 0 == CSacResourceManage::Instance()->GetRemainNum())
	{
		AfxMessageBox(_T("SAC������ʹ���꣬���������"));
		return;
	}
	pThreadOpr = AfxBeginThread(OPera,this); //��ʼָ������
}


void CAutoSacProDlg::OnBnClickedBtnCos5()
{
	nSelCos = COS5;
	if( 0 == CSacResourceManage::Instance()->GetRemainNum())
	{
		AfxMessageBox(_T("SAC������ʹ���꣬���������"));
		return;
	}
	pThreadOpr = AfxBeginThread(OPera,this); //��ʼָ������
}


void CAutoSacProDlg::OnBnClickedBtnCos6()
{
	nSelCos = COS6;
	if( 0 == CSacResourceManage::Instance()->GetRemainNum())
	{
		AfxMessageBox(_T("SAC������ʹ���꣬���������"));
		return;
	}
	pThreadOpr = AfxBeginThread(OPera,this); //��ʼָ������
}


void CAutoSacProDlg::OnBnClickedBtnCos7()
{
	nSelCos = COS7;
	if( 0 == CSacResourceManage::Instance()->GetRemainNum())
	{
		AfxMessageBox(_T("SAC������ʹ���꣬���������"));
		return;
	}
	pThreadOpr = AfxBeginThread(OPera,this); //��ʼָ������
}


void CAutoSacProDlg::OnBnClickedBtnCos8()
{
	nSelCos = COS8;
	if( 0 == CSacResourceManage::Instance()->GetRemainNum())
	{
		AfxMessageBox(_T("SAC������ʹ���꣬���������"));
		return;
	}
	pThreadOpr = AfxBeginThread(OPera,this); //��ʼָ������
}


void CAutoSacProDlg::OnBnClickedBtnCos9()
{
	nSelCos = COS9;
	if( 0 == CSacResourceManage::Instance()->GetRemainNum())
	{
		AfxMessageBox(_T("SAC������ʹ���꣬���������"));
		return;
	}
	pThreadOpr = AfxBeginThread(OPera,this); //��ʼָ������
}


void CAutoSacProDlg::OnBnClickedBtnCos10()
{
	nSelCos = COS10;
	if( 0 == CSacResourceManage::Instance()->GetRemainNum())
	{
		AfxMessageBox(_T("SAC������ʹ���꣬���������"));
		return;
	}
	pThreadOpr = AfxBeginThread(OPera,this); //��ʼָ������
}


void CAutoSacProDlg::OnBnClickedBtnCos11()
{
	nSelCos = COS11;
	if( 0 == CSacResourceManage::Instance()->GetRemainNum())
	{
		AfxMessageBox(_T("SAC������ʹ���꣬���������"));
		return;
	}
	pThreadOpr = AfxBeginThread(OPera,this); //��ʼָ������
}


void CAutoSacProDlg::OnBnClickedBtnCos12()
{
	nSelCos = COS12;
	if( 0 == CSacResourceManage::Instance()->GetRemainNum())
	{
		AfxMessageBox(_T("SAC������ʹ���꣬���������"));
		return;
	}
	pThreadOpr = AfxBeginThread(OPera,this); //��ʼָ������
}


void CAutoSacProDlg::OnBnClickedBtnCos13()
{
	nSelCos = COS13;
	if( 0 == CSacResourceManage::Instance()->GetRemainNum())
	{
		AfxMessageBox(_T("SAC������ʹ���꣬���������"));
		return;
	}
	pThreadOpr = AfxBeginThread(OPera,this); //��ʼָ������
}


void CAutoSacProDlg::OnBnClickedBtnCos14()
{
	nSelCos = COS14;
	if( 0 == CSacResourceManage::Instance()->GetRemainNum())
	{
		AfxMessageBox(_T("SAC������ʹ���꣬���������"));
		return;
	}
	pThreadOpr = AfxBeginThread(OPera,this); //��ʼָ������
}


void CAutoSacProDlg::OnBnClickedBtnCos15()
{
	nSelCos = COS15;
	if( 0 == CSacResourceManage::Instance()->GetRemainNum())
	{
		AfxMessageBox(_T("SAC������ʹ���꣬���������"));
		return;
	}
	pThreadOpr = AfxBeginThread(OPera,this); //��ʼָ������
}


void CAutoSacProDlg::OnBnClickedBtnCos16()
{
	nSelCos = COS16;
	if( 0 == CSacResourceManage::Instance()->GetRemainNum())
	{
		AfxMessageBox(_T("SAC������ʹ���꣬���������"));
		return;
	}
	pThreadOpr = AfxBeginThread(OPera,this); //��ʼָ������
}


void CAutoSacProDlg::OnBnClickedBtnCos17()
{
	nSelCos = COS17;
	if( 0 == CSacResourceManage::Instance()->GetRemainNum())
	{
		AfxMessageBox(_T("SAC������ʹ���꣬���������"));
		return;
	}
	pThreadOpr = AfxBeginThread(OPera,this); //��ʼָ������
}


void CAutoSacProDlg::OnBnClickedBtnCos18()
{
	nSelCos = COS18;
	if( 0 == CSacResourceManage::Instance()->GetRemainNum())
	{
		AfxMessageBox(_T("SAC������ʹ���꣬���������"));
		return;
	}
	pThreadOpr = AfxBeginThread(OPera,this); //��ʼָ������
}


void CAutoSacProDlg::OnBnClickedBtnCos19()
{
	nSelCos = COS19;
	if( 0 == CSacResourceManage::Instance()->GetRemainNum())
	{
		AfxMessageBox(_T("SAC������ʹ���꣬���������"));
		return;
	}
	pThreadOpr = AfxBeginThread(OPera,this); //��ʼָ������
}

UINT CAutoSacProDlg::OPera( LPVOID lpParam )
{
	CAutoSacProDlg *pSac = (CAutoSacProDlg*)lpParam;

	//�����
	CControlCard::WriteIO(Card2, iOut[0], HIGHT);
	Sleep(200);
	//ȷ���Ƿ�����
	//return 1;
 	int nBit = CControlCard::ReadIO(Card2, iOut[20]);
	if (nBit == 1)
	{
		nBit = 0;
		Sleep(200);
		nBit = CControlCard::ReadIO(Card2, iOut[20]);
		if (nBit == 0)
		{
			CControlCard::WriteIO(Card2, iOut[0], LOW);
			//AfxMessageBox(_T("���������Ƿ�ź�!"));
			::PostMessage(pSac->m_hWnd,WM_ERRMESSAGE,MSG_RES_PUTWELL,NULL);
			return 0;
		}
	}
	else
	{
		CControlCard::WriteIO(Card2, iOut[0],LOW);
		//AfxMessageBox(_T("���������Ƿ�ź�!"));
		::PostMessage(pSac->m_hWnd,WM_ERRMESSAGE,MSG_RES_PUTWELL,NULL);
		return 0;
	}

	//����ȷ��
	int nQulResLeft, nQulResRight;
	nQulResLeft = CControlCard::ReadIO(Card2, iOut[18]);
	nQulResRight = CControlCard::ReadIO(Card2, iOut[19]);
	if (nQulResLeft  == 0 || nQulResRight == 0)
	{
		//��ʾSACû���˶�������
		//�������ʹ��
		CControlCard::WriteIO(Card2, iOut[7], HIGHT);
		CControlCard::WriteIO(Card2, iOut[6], HIGHT);

		while(TRUE)
		{
			if (  HIGHT == CControlCard::ReadIO(Card2, iOut[18]) && HIGHT == CControlCard::ReadIO(Card2, iOut[19]))
			{
				//�رյ��
				CControlCard::WriteIO(Card2, iOut[6], LOW);
				break;
			}
			Sleep(500);
		}
	}

	//�˶�SAC��ȡ��λ��
	int nX,nY;
	CSacResourceManage::Instance()->GetCurPos(nX, nY);
	CMoveToPhotoLoc::MovetoSACLoc(nX, nY);
	//��ͼ����
#if 0
	pSac->SaveImages();

	//��ȡͼƬ���ĵ����ת��
	int SacCentralX,SacCentralY; //���ĵ�
	long DeltaX,DeltaY;           //������ĺ�ͼƬSAC���Ĳ�ֵ
	double SacAngle;            //��ת�� 
	pSac->CVis.GetSacCentralPoint(SacCentralX, SacCentralY, SacAngle);

	DeltaX = pSac->CVis.m_Poto_CentralX - SacCentralX;
	DeltaY = pSac->CVis.m_Poto_CentralY - SacCentralY;

	//������Ҫ������ת��Ϊ����
	long nPuls_X,nPuls_Y,nPuls_Angle;
	nPuls_X = long(DeltaX * 104);
	nPuls_Y = long(DeltaY * 104);

	//����ͷ���ĵ���SAC���ĵ��غ�
	CControlCard::MoveRaxis(X1, nPuls_X);
	CControlCard::WaitRaxisStop(X1);
	CControlCard::MoveRaxis(X2, nPuls_Y);
	CControlCard::WaitRaxisStop(X2);
#endif
#if 0
	//�Ƕ�ת�������壬���ﶨ��1�ȵ���20����
	nPuls_Angle = SacAngle * 20;

	//���Ƶ����תĳ���Ƕ�
	CControlCard::MoveRaxis(X4, nPuls_Angle);
	CControlCard::WaitRaxisStop(X4);
#endif

#if 0
	//����X3���˶�����SAC���ĵĲ�ֵ
	CHAR szGetSac[50] = { 0 };
	CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("GETSAC"), _T("GetSac"), szGetSac, NULL);
	long lCurLoc = CControlCard::GetAxisPosition(X3);
	//�������˶���SAC���ĵ�
	CControlCard::MoveRaxis(X3, atof(szGetSac) - lCurLoc);
	CControlCard::WaitRaxisStop(X3);
#endif
	//ȡ����մ�
	CControlCard::WriteIO(Card2, iOut[2], HIGHT);
	Sleep(500);
	//������ʱ����Ƿ�����SAC
	if ( 0 == CControlCard::ReadIO(Card2, iOut[24]))
	{
		Sleep(500);
		if (0 == CControlCard::ReadIO(Card2, iOut[24]))
		{
			Sleep(500);
			if (0 == CControlCard::ReadIO(Card2, iOut[24]))
			{
				//CControlCard::MoveRaxis(X3, -lCurLoc);
				CControlCard::WriteIO(Card2, iOut[2], LOW);
				//AfxMessageBox(_T("���������Ƿ�������"));
				::PostMessage(pSac->m_hWnd, WM_ERRMESSAGE, MSG_MOUSE_WORKWELL,NULL);
				return 0;
			}
		}
	}

	//����SAC����̧��
	//CControlCard::MoveRaxis(X3, -lCurLoc);
	//CControlCard::WaitRaxisStop(X4);

#if 0
	//��ת��ָ�
	CControlCard::MoveRaxis(X4, -nPuls_Angle);
	CControlCard::WaitRaxisStop(X4);
#endif
	
	//��ȡ��ǰ�������ĵ���
	int nLanpCentralX,nLanpCentralY;
	double nLanpAngle;
	long CentralX0,CentralX1,CentralX2,CentralX3,CentralX4,CentralX5;
	switch(pSac->nCurLampSel)
	{
	case LAM1:
		{
			CMoveToPhotoLoc::MovetoLampLoc(pSac->nCurLampSel,pSac->nSelCos);
#if 0
			pSac->SaveImages();
			pSac->CVis.GetLamPCentralPoint(nLanpCentralX, nLanpCentralY);
			pSac->CVis.GetLamPAngel(nLanpAngle);

			DeltaX = pSac->CVis.m_Poto_CentralX - nLanpCentralX;
			DeltaY = pSac->CVis.m_Poto_CentralY - nLanpCentralY;
			
			nPuls_X = DeltaX * 104;
			nPuls_Y = DeltaY * 104;

			//����ͷ���ĵ������Ŀ��԰���Ķ���
			CControlCard::MoveRaxis(X1,nPuls_X);
			CControlCard::WaitRaxisStop(X1);
			CControlCard::MoveRaxis(X2, nPuls_Y);
			CControlCard::WaitRaxisStop(X2);

			//��¼�غϵ�Բ��λ��
			CentralX0 = CControlCard::GetAxisPosition(X0);
            CentralX1 = CControlCard::GetAxisPosition(X1);
			CentralX2 = CControlCard::GetAxisPosition(X2);
			CentralX3 = CControlCard::GetAxisPosition(X3);
			CentralX4 = CControlCard::GetAxisPosition(X4);
			CentralX5 = CControlCard::GetAxisPosition(X5);
#endif

		}
		break;
	case LAM2:
		{
			CMoveToPhotoLoc::MovetoLampLoc(pSac->nCurLampSel,pSac->nSelCos);
#if 0
			pSac->SaveImages();
			pSac->CVis.GetLamPCentralPoint(nLanpCentralX, nLanpCentralY);
			pSac->CVis.GetLamPAngel(nLanpAngle);

			DeltaX = pSac->CVis.m_Poto_CentralX - nLanpCentralX;
			DeltaY = pSac->CVis.m_Poto_CentralY - nLanpCentralY;

			nPuls_X = DeltaX * 104;
			nPuls_Y = DeltaY * 104;

			//����ͷ���ĵ������Ŀ��԰���Ķ���
			CControlCard::MoveRaxis(X1,nPuls_X);
			CControlCard::WaitRaxisStop(X1);
			CControlCard::MoveRaxis(X2, nPuls_Y);
			CControlCard::WaitRaxisStop(X2);


			//��¼�غϵ�Բ��λ��
			CentralX0 = CControlCard::GetAxisPosition(X0);
			CentralX1 = CControlCard::GetAxisPosition(X1);
			CentralX2 = CControlCard::GetAxisPosition(X2);
			CentralX3 = CControlCard::GetAxisPosition(X3);
			CentralX4 = CControlCard::GetAxisPosition(X4);
			CentralX5 = CControlCard::GetAxisPosition(X5);
#endif
		}
		break;
	case LAM3:
		{
			CMoveToPhotoLoc::MovetoLampLoc(pSac->nCurLampSel,pSac->nSelCos);
#if 0
			pSac->SaveImages();
			pSac->CVis.GetLamPCentralPoint(nLanpCentralX, nLanpCentralY);
			pSac->CVis.GetLamPAngel(nLanpAngle);

			DeltaX = pSac->CVis.m_Poto_CentralX - nLanpCentralX;
			DeltaY = pSac->CVis.m_Poto_CentralY - nLanpCentralY;

			nPuls_X = DeltaX * 104;
			nPuls_Y = DeltaY * 104;

			//����ͷ���ĵ������Ŀ��԰���Ķ���
			CControlCard::MoveRaxis(X1,nPuls_X);
			CControlCard::WaitRaxisStop(X1);
			CControlCard::MoveRaxis(X2, nPuls_Y);
			CControlCard::WaitRaxisStop(X2);


			//��¼�غϵ�Բ��λ��
			CentralX0 = CControlCard::GetAxisPosition(X0);
			CentralX1 = CControlCard::GetAxisPosition(X1);
			CentralX2 = CControlCard::GetAxisPosition(X2);
			CentralX3 = CControlCard::GetAxisPosition(X3);
			CentralX4 = CControlCard::GetAxisPosition(X4);
			CentralX5 = CControlCard::GetAxisPosition(X5);
#endif
		}
		break;
	case LAM4:
		{
			CMoveToPhotoLoc::MovetoLampLoc(pSac->nCurLampSel,pSac->nSelCos);
#if 0
			pSac->SaveImages();
			pSac->CVis.GetLamPCentralPoint(nLanpCentralX, nLanpCentralY);
			pSac->CVis.GetLamPAngel(nLanpAngle);

			DeltaX = pSac->CVis.m_Poto_CentralX - nLanpCentralX;
			DeltaY = pSac->CVis.m_Poto_CentralY - nLanpCentralY;

			nPuls_X = DeltaX * 104;
			nPuls_Y = DeltaY * 104;

			//����ͷ���ĵ������Ŀ��԰���Ķ���
			CControlCard::MoveRaxis(X1,nPuls_X);
			CControlCard::WaitRaxisStop(X1);
			CControlCard::MoveRaxis(X2, nPuls_Y);
			CControlCard::WaitRaxisStop(X2);

			//��¼SAC����λ��
			CentralX0 = CControlCard::GetAxisPosition(X0);
			CentralX1 = CControlCard::GetAxisPosition(X1);
			CentralX2 = CControlCard::GetAxisPosition(X2);
			CentralX3 = CControlCard::GetAxisPosition(X3);
			CentralX4 = CControlCard::GetAxisPosition(X4);
			CentralX5 = CControlCard::GetAxisPosition(X5);
#endif
		}
		break;
	}

	//�㽺
	switch(pSac->nSelCos)
	{
	case COS1:
		{
			//�˶����㽺��ʼ��
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, lWStep);
			CControlCard::MoveRaxis(X1, lHStep);

			//�㽺�����½�
			CControlCard::WriteIO(Card2, iOut[5], HIGHT);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[23]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
			//�㽺����
			CControlCard::WriteIO(Card2, iOut[34], HIGHT);

			//��ʼ�㽺
			CControlCard::MoveRaxis(X0, 6000);

			//�㽺��Ϲرյ㽺
			CControlCard::WriteIO(Card2, iOut[34], LOW);
			
			//̧��㽺����
			CControlCard::WriteIO(Card2, iOut[4], LOW);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[22]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif

		}
		break;
	case COS2:
		{
			//�˶����㽺��ʼ��
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, lWStep);
			CControlCard::MoveRaxis(X1, lHStep);

			//�㽺�����½�
			CControlCard::WriteIO(Card2, iOut[5], HIGHT);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[23]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
			//�㽺����
			CControlCard::WriteIO(Card2, iOut[34], HIGHT);

			//��ʼ�㽺
			CControlCard::MoveRaxis(X0, 6000);

			//�㽺��Ϲرյ㽺
			CControlCard::WriteIO(Card2, iOut[34], LOW);

			//̧��㽺����
			CControlCard::WriteIO(Card2, iOut[4], LOW);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[22]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif

		}
		break;
	case COS3:
		{
			//�˶����㽺��ʼ��
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, lWStep);
			CControlCard::MoveRaxis(X1, lHStep);

			//�㽺�����½�
			CControlCard::WriteIO(Card2, iOut[5], HIGHT);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[23]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
			//�㽺����
			CControlCard::WriteIO(Card2, iOut[34], HIGHT);

			//��ʼ�㽺
			CControlCard::MoveRaxis(X0, 6000);

			//�㽺��Ϲرյ㽺
			CControlCard::WriteIO(Card2, iOut[34], LOW);

			//̧��㽺����
			CControlCard::WriteIO(Card2, iOut[4], LOW);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[22]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
		}
		break;
	case COS4:
		{
			//�˶����㽺��ʼ��
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, lWStep);
			CControlCard::MoveRaxis(X1, lHStep);

			//�㽺�����½�
			CControlCard::WriteIO(Card2, iOut[5], HIGHT);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[23]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
			//�㽺����
			CControlCard::WriteIO(Card2, iOut[34], HIGHT);

			//��ʼ�㽺
			CControlCard::MoveRaxis(X0, 6000);

			//�㽺��Ϲرյ㽺
			CControlCard::WriteIO(Card2, iOut[34], LOW);

			//̧��㽺����
			CControlCard::WriteIO(Card2, iOut[4], LOW);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[22]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif

		}
		break;
	case COS5:
		{
			//�˶����㽺��ʼ��
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, lWStep);
			CControlCard::MoveRaxis(X1, lHStep);

			//�㽺�����½�
			CControlCard::WriteIO(Card2, iOut[5], HIGHT);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[23]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
			//�㽺����
			CControlCard::WriteIO(Card2, iOut[34], HIGHT);

			//��ʼ�㽺
			CControlCard::MoveRaxis(X0, 6000);

			//�㽺��Ϲرյ㽺
			CControlCard::WriteIO(Card2, iOut[34], LOW);

			//̧��㽺����
			CControlCard::WriteIO(Card2, iOut[4], LOW);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[22]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
		}
		break;
	case COS6:
		{
			//�˶����㽺��ʼ��
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, lWStep);
			CControlCard::MoveRaxis(X1, lHStep);

			//�㽺�����½�
			CControlCard::WriteIO(Card2, iOut[5], HIGHT);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[23]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
			//�㽺����
			CControlCard::WriteIO(Card2, iOut[34], HIGHT);

			//��ʼ�㽺
			CControlCard::MoveRaxis(X0, 6000);

			//�㽺��Ϲرյ㽺
			CControlCard::WriteIO(Card2, iOut[34], LOW);

			//̧��㽺����
			CControlCard::WriteIO(Card2, iOut[4], LOW);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[22]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
		}
		break;
	case COS7:
		{
			//�˶����㽺��ʼ��
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, lWStep);
			CControlCard::MoveRaxis(X1, lHStep);

			//�㽺�����½�
			CControlCard::WriteIO(Card2, iOut[5], HIGHT);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[23]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
			//�㽺����
			CControlCard::WriteIO(Card2, iOut[34], HIGHT);

			//��ʼ�㽺
			CControlCard::MoveRaxis(X0, 6000);

			//�㽺��Ϲرյ㽺
			CControlCard::WriteIO(Card2, iOut[34], LOW);

			//̧��㽺����
			CControlCard::WriteIO(Card2, iOut[4], LOW);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[22]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
		}
		break;
	case COS8:
		{
			//�˶����㽺��ʼ��
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, lWStep);
			CControlCard::MoveRaxis(X1, lHStep);

			//�㽺�����½�
			CControlCard::WriteIO(Card2, iOut[5], HIGHT);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[23]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
			//�㽺����
			CControlCard::WriteIO(Card2, iOut[34], HIGHT);

			//��ʼ�㽺
			CControlCard::MoveRaxis(X0, 6000);

			//�㽺��Ϲرյ㽺
			CControlCard::WriteIO(Card2, iOut[34], LOW);

			//̧��㽺����
			CControlCard::WriteIO(Card2, iOut[4], LOW);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[22]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif

		}
		break;
	case COS9:
		{
			//�˶����㽺��ʼ��
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, lWStep);
			CControlCard::MoveRaxis(X1, lHStep);

			//�㽺�����½�
			CControlCard::WriteIO(Card2, iOut[5], HIGHT);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[23]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
			//�㽺����
			CControlCard::WriteIO(Card2, iOut[34], HIGHT);

			//��ʼ�㽺
			CControlCard::MoveRaxis(X0, 6000);

			//�㽺��Ϲرյ㽺
			CControlCard::WriteIO(Card2, iOut[34], LOW);

			//̧��㽺����
			CControlCard::WriteIO(Card2, iOut[4], LOW);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[22]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif

		}
		break;
	case COS10:
		{
			//�˶����㽺��ʼ��
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, lWStep);
			CControlCard::MoveRaxis(X1, lHStep);

			//�㽺�����½�
			CControlCard::WriteIO(Card2, iOut[5], HIGHT);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[23]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
			//�㽺����
			CControlCard::WriteIO(Card2, iOut[34], HIGHT);

			//��ʼ�㽺
			CControlCard::MoveRaxis(X0, 6000);

			//�㽺��Ϲرյ㽺
			CControlCard::WriteIO(Card2, iOut[34], LOW);

			//̧��㽺����
			CControlCard::WriteIO(Card2, iOut[4], LOW);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[22]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
		}
		break;
	case COS11:
		{
			//�˶����㽺��ʼ��
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, lWStep);
			CControlCard::MoveRaxis(X1, lHStep);

			//�㽺�����½�
			CControlCard::WriteIO(Card2, iOut[5], HIGHT);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[23]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
			//�㽺����
			CControlCard::WriteIO(Card2, iOut[34], HIGHT);

			//��ʼ�㽺
			CControlCard::MoveRaxis(X0, 6000);

			//�㽺��Ϲرյ㽺
			CControlCard::WriteIO(Card2, iOut[34], LOW);

			//̧��㽺����
			CControlCard::WriteIO(Card2, iOut[4], LOW);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[22]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
		}
		break;
	case COS12:
		{
			//�˶����㽺��ʼ��
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, lWStep);
			CControlCard::MoveRaxis(X1, lHStep);

			//�㽺�����½�
			CControlCard::WriteIO(Card2, iOut[5], HIGHT);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[23]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
			//�㽺����
			CControlCard::WriteIO(Card2, iOut[34], HIGHT);

			//��ʼ�㽺
			CControlCard::MoveRaxis(X0, 6000);

			//�㽺��Ϲرյ㽺
			CControlCard::WriteIO(Card2, iOut[34], LOW);

			//̧��㽺����
			CControlCard::WriteIO(Card2, iOut[4], LOW);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[22]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif

		}
		break;
	case COS13:
		{
			//�˶����㽺��ʼ��
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, lWStep);
			CControlCard::MoveRaxis(X1, lHStep);

			//�㽺�����½�
			CControlCard::WriteIO(Card2, iOut[5], HIGHT);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[23]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
			//�㽺����
			CControlCard::WriteIO(Card2, iOut[34], HIGHT);

			//��ʼ�㽺
			CControlCard::MoveRaxis(X0, 6000);

			//�㽺��Ϲرյ㽺
			CControlCard::WriteIO(Card2, iOut[34], LOW);

			//̧��㽺����
			CControlCard::WriteIO(Card2, iOut[4], LOW);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[22]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif

		}
		break;
	case COS14:
		{
			//�˶����㽺��ʼ��
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, lWStep);
			CControlCard::MoveRaxis(X1, lHStep);

			//�㽺�����½�
			CControlCard::WriteIO(Card2, iOut[5], HIGHT);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[23]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
			//�㽺����
			CControlCard::WriteIO(Card2, iOut[34], HIGHT);

			//��ʼ�㽺
			CControlCard::MoveRaxis(X0, 6000);

			//�㽺��Ϲرյ㽺
			CControlCard::WriteIO(Card2, iOut[34], LOW);

			//̧��㽺����
			CControlCard::WriteIO(Card2, iOut[4], LOW);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[22]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
		}
		break;
	case COS15:
		{
			//�˶����㽺��ʼ��
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, lWStep);
			CControlCard::MoveRaxis(X1, lHStep);

			//�㽺�����½�
			CControlCard::WriteIO(Card2, iOut[5], HIGHT);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[23]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
			//�㽺����
			CControlCard::WriteIO(Card2, iOut[34], HIGHT);

			//��ʼ�㽺
			CControlCard::MoveRaxis(X0, 6000);

			//�㽺��Ϲرյ㽺
			CControlCard::WriteIO(Card2, iOut[34], LOW);

			//̧��㽺����
			CControlCard::WriteIO(Card2, iOut[4], LOW);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[22]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif

		}
		break;
	case COS16:
		{
			//�˶����㽺��ʼ��
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, lWStep);
			CControlCard::MoveRaxis(X1, lHStep);

			//�㽺�����½�
			CControlCard::WriteIO(Card2, iOut[5], HIGHT);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[23]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
			//�㽺����
			CControlCard::WriteIO(Card2, iOut[34], HIGHT);

			//��ʼ�㽺
			CControlCard::MoveRaxis(X0, 6000);

			//�㽺��Ϲرյ㽺
			CControlCard::WriteIO(Card2, iOut[34], LOW);

			//̧��㽺����
			CControlCard::WriteIO(Card2, iOut[4], LOW);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[22]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
		}
		break;
	case COS17:
		{
			//�˶����㽺��ʼ��
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, lWStep);
			CControlCard::MoveRaxis(X1, lHStep);

			//�㽺�����½�
			CControlCard::WriteIO(Card2, iOut[5], HIGHT);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[23]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
			//�㽺����
			CControlCard::WriteIO(Card2, iOut[34], HIGHT);

			//��ʼ�㽺
			CControlCard::MoveRaxis(X0, 6000);

			//�㽺��Ϲرյ㽺
			CControlCard::WriteIO(Card2, iOut[34], LOW);

			//̧��㽺����
			CControlCard::WriteIO(Card2, iOut[4], LOW);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[22]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif

		}
		break;
	case COS18:
		{
			//�˶����㽺��ʼ��
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, lWStep);
			CControlCard::MoveRaxis(X1, lHStep);

			//�㽺�����½�
			CControlCard::WriteIO(Card2, iOut[5], HIGHT);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[23]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
			//�㽺����
			CControlCard::WriteIO(Card2, iOut[34], HIGHT);

			//��ʼ�㽺
			CControlCard::MoveRaxis(X0, 6000);

			//�㽺��Ϲرյ㽺
			CControlCard::WriteIO(Card2, iOut[34], LOW);

			//̧��㽺����
			CControlCard::WriteIO(Card2, iOut[4], LOW);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[22]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif

		}
		break;
	case COS19:
		{
			//�˶����㽺��ʼ��
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOGlUE"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, lWStep);
			CControlCard::MoveRaxis(X1, lHStep);

			//�㽺�����½�
			CControlCard::WriteIO(Card2, iOut[5], HIGHT);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[23]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
			//�㽺����
			CControlCard::WriteIO(Card2, iOut[34], HIGHT);

			//��ʼ�㽺
			CControlCard::MoveRaxis(X0, 6000);

			//�㽺��Ϲرյ㽺
			CControlCard::WriteIO(Card2, iOut[34], LOW);

			//̧��㽺����
			CControlCard::WriteIO(Card2, iOut[4], LOW);
#if 0
			while(TRUE)
			{
				if( CControlCard::ReadIO(Card2, iOut[22]) == 1 ) //�㽺����ȷ��
				{
					break;
				}
				Sleep(500);
			}
#endif
		}
		break;
	
	}

#if 0
	//����ع鵽�������
	long TempX0 = CControlCard::GetAxisPosition(X0);
	long TempX1 = CControlCard::GetAxisPosition(X1);
	long TempX2 = CControlCard::GetAxisPosition(X2);
	long TempX3 = CControlCard::GetAxisPosition(X3);
	long TempX4 = CControlCard::GetAxisPosition(X4);
	long TempX5 = CControlCard::GetAxisPosition(X5);

	long tempdeltaX0 = CentralX0 - TempX0;
	long tempdeltaX1 = CentralX1 - TempX1;
	long tempdeltaX2 = CentralX2 - TempX2;
	long tempdeltaX3 = CentralX3 - TempX3;
	long tempdeltaX4 = CentralX4 - TempX4;
	long tempdeltaX5 = CentralX5 - TempX5;

	CControlCard::MoveRaxis(X0, tempdeltaX0);
	CControlCard::MoveRaxis(X1, tempdeltaX1);
	CControlCard::MoveRaxis(X2, tempdeltaX2);
	CControlCard::MoveRaxis(X3, tempdeltaX3);
	CControlCard::MoveRaxis(X4, tempdeltaX5);
#endif
	//����SAC
	switch(pSac->nSelCos)
	{
	case COS1:
		{
			//�����˶���COS1���ĵ�
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, -lWStep);
			CControlCard::WaitRaxisStop(X0);
			CControlCard::MoveRaxis(X1, -lHStep);
			CControlCard::WaitRaxisStop(X1);
#if 0
			//��׼�Ƕ�
			//�Ƕ�ת�������壬���ﶨ��1�ȵ���20����
			nPuls_Angle = nLanpAngle * 20;

			//���Ƶ����תĳ���Ƕ�
			CControlCard::MoveRaxis(X3, nPuls_Angle);
			CControlCard::WaitRaxisStop(X3);
#endif
			//��ʼ��SAC
			//����X2����Ҫ�˶��ľ���
			CHAR szHeighCos[50] = { 0 };
			CHAR szDeltaLam[50] = { 0 };

			
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("PUTSACTOCOS"), _T("PutSactoCos"), szHeighCos, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("DELTALAMHEIGH"), _T("DeltaLamHight"), szDeltaLam, NULL);

			long CurPos = CControlCard::GetAxisPosition(X2);


			long lHeigh =  static_cast<long>(atof(szHeighCos)) - CurPos +   static_cast<long>(atof(szDeltaLam))*(pSac->nSelCos - 10001);
			
			CControlCard::MoveRaxis(X2, -lHeigh);
			CControlCard::WaitRaxisStop(X2);
			//��UV��
			CControlCard::WriteIO(Card2, iOut[35], HIGHT);

			//��ʱ
			Sleep(5000);

			//�ر�UV��
			CControlCard::WriteIO(Card2, iOut[35], LOW);

			//�ر����
			CControlCard::WriteIO(Card2, iOut[2], LOW);
			
			//��μ������Ƿ�ر�
			if ( 0 == CControlCard::ReadIO(Card2, iOut[24]))
			{
				Sleep(500);
				if (0 == CControlCard::ReadIO(Card2, iOut[24]))
				{
					Sleep(500);
					if (0 == CControlCard::ReadIO(Card2, iOut[24]))
					{
						//AfxMessageBox(_T("���������Ƿ�������"));
						::PostMessage(pSac->m_hWnd, WM_ERRMESSAGE, MSG_MOUSE_WORKWELL, NULL);
						return 0;
					}
				}
			}
			//̧��������
			CControlCard::MoveRaxis(X2, lHeigh);
		}
		break;
	case COS2:
		{
			//�����˶���COS1���ĵ�
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, -lWStep);
			CControlCard::WaitRaxisStop(X0);
			CControlCard::MoveRaxis(X1, -lHStep);
			CControlCard::WaitRaxisStop(X1);
#if 0
			//��׼�Ƕ�
			//�Ƕ�ת�������壬���ﶨ��1�ȵ���20����
			nPuls_Angle = nLanpAngle * 20;

			//���Ƶ����תĳ���Ƕ�
			CControlCard::MoveRaxis(X3, nPuls_Angle);
			CControlCard::WaitRaxisStop(X3);
#endif
			//��ʼ��SAC
			//����X2����Ҫ�˶��ľ���
			CHAR szHeighCos[50] = { 0 };
			CHAR szDeltaLam[50] = { 0 };


			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("PUTSACTOCOS"), _T("PutSactoCos"), szHeighCos, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("DELTALAMHEIGH"), _T("DeltaLamHight"), szDeltaLam, NULL);

			long CurPos = CControlCard::GetAxisPosition(X2);


			long lHeigh =  static_cast<long>(atof(szHeighCos)) - CurPos +   static_cast<long>(atof(szDeltaLam))*(pSac->nSelCos - 10001);

			CControlCard::MoveRaxis(X2, -lHeigh);
			CControlCard::WaitRaxisStop(X2);
			//��UV��
			CControlCard::WriteIO(Card2, iOut[35], HIGHT);

			//��ʱ
			Sleep(5000);

			//�ر�UV��
			CControlCard::WriteIO(Card2, iOut[35], LOW);

			//�ر����
			CControlCard::WriteIO(Card2, iOut[2], LOW);

			//��μ������Ƿ�ر�
			if ( 0 == CControlCard::ReadIO(Card2, iOut[24]))
			{
				Sleep(500);
				if (0 == CControlCard::ReadIO(Card2, iOut[24]))
				{
					Sleep(500);
					if (0 == CControlCard::ReadIO(Card2, iOut[24]))
					{
						//AfxMessageBox(_T("���������Ƿ�������"));
						::PostMessage(pSac->m_hWnd, WM_ERRMESSAGE, MSG_MOUSE_WORKWELL, NULL);
						return 0;
					}
				}
			}
			//̧��������
			CControlCard::MoveRaxis(X2, lHeigh);
		}
		break;
	case COS3:
		{
			//�����˶���COS1���ĵ�
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, -lWStep);
			CControlCard::WaitRaxisStop(X0);
			CControlCard::MoveRaxis(X1, -lHStep);
			CControlCard::WaitRaxisStop(X1);
#if 0
			//��׼�Ƕ�
			//�Ƕ�ת�������壬���ﶨ��1�ȵ���20����
			nPuls_Angle = nLanpAngle * 20;

			//���Ƶ����תĳ���Ƕ�
			CControlCard::MoveRaxis(X3, nPuls_Angle);
			CControlCard::WaitRaxisStop(X3);
#endif
			//��ʼ��SAC
			//����X2����Ҫ�˶��ľ���
			CHAR szHeighCos[50] = { 0 };
			CHAR szDeltaLam[50] = { 0 };


			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("PUTSACTOCOS"), _T("PutSactoCos"), szHeighCos, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("DELTALAMHEIGH"), _T("DeltaLamHight"), szDeltaLam, NULL);

			long CurPos = CControlCard::GetAxisPosition(X2);


			long lHeigh =  static_cast<long>(atof(szHeighCos)) - CurPos +   static_cast<long>(atof(szDeltaLam))*(pSac->nSelCos - 10001);

			CControlCard::MoveRaxis(X2, -lHeigh);
			CControlCard::WaitRaxisStop(X2);
			//��UV��
			CControlCard::WriteIO(Card2, iOut[35], HIGHT);

			//��ʱ
			Sleep(5000);

			//�ر�UV��
			CControlCard::WriteIO(Card2, iOut[35], LOW);

			//�ر����
			CControlCard::WriteIO(Card2, iOut[2], LOW);

			//��μ������Ƿ�ر�
			if ( 0 == CControlCard::ReadIO(Card2, iOut[24]))
			{
				Sleep(500);
				if (0 == CControlCard::ReadIO(Card2, iOut[24]))
				{
					Sleep(500);
					if (0 == CControlCard::ReadIO(Card2, iOut[24]))
					{
						//AfxMessageBox(_T("���������Ƿ�������"));
						::PostMessage(pSac->m_hWnd, WM_ERRMESSAGE, MSG_MOUSE_WORKWELL, NULL);
						return 0;
					}
				}
			}
			//̧��������
			CControlCard::MoveRaxis(X2, lHeigh);
		}
		break;
	case COS4:
		{
			//�����˶���COS1���ĵ�
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, -lWStep);
			CControlCard::WaitRaxisStop(X0);
			CControlCard::MoveRaxis(X1, -lHStep);
			CControlCard::WaitRaxisStop(X1);
#if 0
			//��׼�Ƕ�
			//�Ƕ�ת�������壬���ﶨ��1�ȵ���20����
			nPuls_Angle = nLanpAngle * 20;

			//���Ƶ����תĳ���Ƕ�
			CControlCard::MoveRaxis(X3, nPuls_Angle);
			CControlCard::WaitRaxisStop(X3);
#endif
			//��ʼ��SAC
			//����X2����Ҫ�˶��ľ���
			CHAR szHeighCos[50] = { 0 };
			CHAR szDeltaLam[50] = { 0 };


			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("PUTSACTOCOS"), _T("PutSactoCos"), szHeighCos, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("DELTALAMHEIGH"), _T("DeltaLamHight"), szDeltaLam, NULL);

			long CurPos = CControlCard::GetAxisPosition(X2);


			long lHeigh =  static_cast<long>(atof(szHeighCos)) - CurPos +   static_cast<long>(atof(szDeltaLam))*(pSac->nSelCos - 10001);

			CControlCard::MoveRaxis(X2, -lHeigh);
			CControlCard::WaitRaxisStop(X2);
			//��UV��
			CControlCard::WriteIO(Card2, iOut[35], HIGHT);

			//��ʱ
			Sleep(5000);

			//�ر�UV��
			CControlCard::WriteIO(Card2, iOut[35], LOW);

			//�ر����
			CControlCard::WriteIO(Card2, iOut[2], LOW);

			//��μ������Ƿ�ر�
			if ( 0 == CControlCard::ReadIO(Card2, iOut[24]))
			{
				Sleep(500);
				if (0 == CControlCard::ReadIO(Card2, iOut[24]))
				{
					Sleep(500);
					if (0 == CControlCard::ReadIO(Card2, iOut[24]))
					{
						//AfxMessageBox(_T("���������Ƿ�������"));
						::PostMessage(pSac->m_hWnd, WM_ERRMESSAGE, MSG_MOUSE_WORKWELL, NULL);
						return 0;
					}
				}
			}
			//̧��������
			CControlCard::MoveRaxis(X2, lHeigh);
		}
		break;
	case COS5:
		{
			//�����˶���COS1���ĵ�
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, -lWStep);
			CControlCard::WaitRaxisStop(X0);
			CControlCard::MoveRaxis(X1, -lHStep);
			CControlCard::WaitRaxisStop(X1);
#if 0
			//��׼�Ƕ�
			//�Ƕ�ת�������壬���ﶨ��1�ȵ���20����
			nPuls_Angle = nLanpAngle * 20;

			//���Ƶ����תĳ���Ƕ�
			CControlCard::MoveRaxis(X3, nPuls_Angle);
			CControlCard::WaitRaxisStop(X3);
#endif
			//��ʼ��SAC
			//����X2����Ҫ�˶��ľ���
			CHAR szHeighCos[50] = { 0 };
			CHAR szDeltaLam[50] = { 0 };


			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("PUTSACTOCOS"), _T("PutSactoCos"), szHeighCos, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("DELTALAMHEIGH"), _T("DeltaLamHight"), szDeltaLam, NULL);

			long CurPos = CControlCard::GetAxisPosition(X2);


			long lHeigh =  static_cast<long>(atof(szHeighCos)) - CurPos +   static_cast<long>(atof(szDeltaLam))*(pSac->nSelCos - 10001);

			CControlCard::MoveRaxis(X2, -lHeigh);
			CControlCard::WaitRaxisStop(X2);
			//��UV��
			CControlCard::WriteIO(Card2, iOut[35], HIGHT);

			//��ʱ
			Sleep(5000);

			//�ر�UV��
			CControlCard::WriteIO(Card2, iOut[35], LOW);

			//�ر����
			CControlCard::WriteIO(Card2, iOut[2], LOW);

			//��μ������Ƿ�ر�
			if ( 0 == CControlCard::ReadIO(Card2, iOut[24]))
			{
				Sleep(500);
				if (0 == CControlCard::ReadIO(Card2, iOut[24]))
				{
					Sleep(500);
					if (0 == CControlCard::ReadIO(Card2, iOut[24]))
					{
						//AfxMessageBox(_T("���������Ƿ�������"));
						::PostMessage(pSac->m_hWnd, WM_ERRMESSAGE, MSG_MOUSE_WORKWELL, NULL);
						return 0;
					}
				}
			}
			//̧��������
			CControlCard::MoveRaxis(X2, lHeigh);
		}
		break;
	case COS6:
		{
			//�����˶���COS1���ĵ�
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, -lWStep);
			CControlCard::WaitRaxisStop(X0);
			CControlCard::MoveRaxis(X1, -lHStep);
			CControlCard::WaitRaxisStop(X1);
#if 0
			//��׼�Ƕ�
			//�Ƕ�ת�������壬���ﶨ��1�ȵ���20����
			nPuls_Angle = nLanpAngle * 20;

			//���Ƶ����תĳ���Ƕ�
			CControlCard::MoveRaxis(X3, nPuls_Angle);
			CControlCard::WaitRaxisStop(X3);
#endif
			//��ʼ��SAC
			//����X2����Ҫ�˶��ľ���
			CHAR szHeighCos[50] = { 0 };
			CHAR szDeltaLam[50] = { 0 };


			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("PUTSACTOCOS"), _T("PutSactoCos"), szHeighCos, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("DELTALAMHEIGH"), _T("DeltaLamHight"), szDeltaLam, NULL);

			long CurPos = CControlCard::GetAxisPosition(X2);


			long lHeigh =  static_cast<long>(atof(szHeighCos)) - CurPos +   static_cast<long>(atof(szDeltaLam))*(pSac->nSelCos - 10001);

			CControlCard::MoveRaxis(X2, -lHeigh);
			CControlCard::WaitRaxisStop(X2);
			//��UV��
			CControlCard::WriteIO(Card2, iOut[35], HIGHT);

			//��ʱ
			Sleep(5000);

			//�ر�UV��
			CControlCard::WriteIO(Card2, iOut[35], LOW);

			//�ر����
			CControlCard::WriteIO(Card2, iOut[2], LOW);

			//��μ������Ƿ�ر�
			if ( 0 == CControlCard::ReadIO(Card2, iOut[24]))
			{
				Sleep(500);
				if (0 == CControlCard::ReadIO(Card2, iOut[24]))
				{
					Sleep(500);
					if (0 == CControlCard::ReadIO(Card2, iOut[24]))
					{
						//AfxMessageBox(_T("���������Ƿ�������"));
						::PostMessage(pSac->m_hWnd, WM_ERRMESSAGE, MSG_MOUSE_WORKWELL, NULL);
						return 0;
					}
				}
			}
			//̧��������
			CControlCard::MoveRaxis(X2, lHeigh);
		}
		break;
	case COS7:
		{
			//�����˶���COS1���ĵ�
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, -lWStep);
			CControlCard::WaitRaxisStop(X0);
			CControlCard::MoveRaxis(X1, -lHStep);
			CControlCard::WaitRaxisStop(X1);
#if 0
			//��׼�Ƕ�
			//�Ƕ�ת�������壬���ﶨ��1�ȵ���20����
			nPuls_Angle = nLanpAngle * 20;

			//���Ƶ����תĳ���Ƕ�
			CControlCard::MoveRaxis(X3, nPuls_Angle);
			CControlCard::WaitRaxisStop(X3);
#endif
			//��ʼ��SAC
			//����X2����Ҫ�˶��ľ���
			CHAR szHeighCos[50] = { 0 };
			CHAR szDeltaLam[50] = { 0 };


			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("PUTSACTOCOS"), _T("PutSactoCos"), szHeighCos, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("DELTALAMHEIGH"), _T("DeltaLamHight"), szDeltaLam, NULL);

			long CurPos = CControlCard::GetAxisPosition(X2);


			long lHeigh =  static_cast<long>(atof(szHeighCos)) - CurPos +   static_cast<long>(atof(szDeltaLam))*(pSac->nSelCos - 10001);

			CControlCard::MoveRaxis(X2, -lHeigh);
			CControlCard::WaitRaxisStop(X2);
			//��UV��
			CControlCard::WriteIO(Card2, iOut[35], HIGHT);

			//��ʱ
			Sleep(5000);

			//�ر�UV��
			CControlCard::WriteIO(Card2, iOut[35], LOW);

			//�ر����
			CControlCard::WriteIO(Card2, iOut[2], LOW);

			//��μ������Ƿ�ر�
			if ( 0 == CControlCard::ReadIO(Card2, iOut[24]))
			{
				Sleep(500);
				if (0 == CControlCard::ReadIO(Card2, iOut[24]))
				{
					Sleep(500);
					if (0 == CControlCard::ReadIO(Card2, iOut[24]))
					{
						//AfxMessageBox(_T("���������Ƿ�������"));
						::PostMessage(pSac->m_hWnd, WM_ERRMESSAGE, MSG_MOUSE_WORKWELL, NULL);
						return 0;
					}
				}
			}
			//̧��������
			CControlCard::MoveRaxis(X2, lHeigh);
		}
		break;
	case COS8:
		{
			//�����˶���COS1���ĵ�
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, -lWStep);
			CControlCard::WaitRaxisStop(X0);
			CControlCard::MoveRaxis(X1, -lHStep);
			CControlCard::WaitRaxisStop(X1);
#if 0
			//��׼�Ƕ�
			//�Ƕ�ת�������壬���ﶨ��1�ȵ���20����
			nPuls_Angle = nLanpAngle * 20;

			//���Ƶ����תĳ���Ƕ�
			CControlCard::MoveRaxis(X3, nPuls_Angle);
			CControlCard::WaitRaxisStop(X3);
#endif
			//��ʼ��SAC
			//����X2����Ҫ�˶��ľ���
			CHAR szHeighCos[50] = { 0 };
			CHAR szDeltaLam[50] = { 0 };


			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("PUTSACTOCOS"), _T("PutSactoCos"), szHeighCos, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("DELTALAMHEIGH"), _T("DeltaLamHight"), szDeltaLam, NULL);

			long CurPos = CControlCard::GetAxisPosition(X2);


			long lHeigh =  static_cast<long>(atof(szHeighCos)) - CurPos +   static_cast<long>(atof(szDeltaLam))*(pSac->nSelCos - 10001);

			CControlCard::MoveRaxis(X2, -lHeigh);
			CControlCard::WaitRaxisStop(X2);
			//��UV��
			CControlCard::WriteIO(Card2, iOut[35], HIGHT);

			//��ʱ
			Sleep(5000);

			//�ر�UV��
			CControlCard::WriteIO(Card2, iOut[35], LOW);

			//�ر����
			CControlCard::WriteIO(Card2, iOut[2], LOW);

			//��μ������Ƿ�ر�
			if ( 0 == CControlCard::ReadIO(Card2, iOut[24]))
			{
				Sleep(500);
				if (0 == CControlCard::ReadIO(Card2, iOut[24]))
				{
					Sleep(500);
					if (0 == CControlCard::ReadIO(Card2, iOut[24]))
					{
						//AfxMessageBox(_T("���������Ƿ�������"));
						::PostMessage(pSac->m_hWnd, WM_ERRMESSAGE, MSG_MOUSE_WORKWELL, NULL);
						return 0;
					}
				}
			}
			//̧��������
			CControlCard::MoveRaxis(X2, lHeigh);
		}
		break;
	case COS9:
		{
			//�����˶���COS1���ĵ�
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, -lWStep);
			CControlCard::WaitRaxisStop(X0);
			CControlCard::MoveRaxis(X1, -lHStep);
			CControlCard::WaitRaxisStop(X1);
#if 0
			//��׼�Ƕ�
			//�Ƕ�ת�������壬���ﶨ��1�ȵ���20����
			nPuls_Angle = nLanpAngle * 20;

			//���Ƶ����תĳ���Ƕ�
			CControlCard::MoveRaxis(X3, nPuls_Angle);
			CControlCard::WaitRaxisStop(X3);
#endif
			//��ʼ��SAC
			//����X2����Ҫ�˶��ľ���
			CHAR szHeighCos[50] = { 0 };
			CHAR szDeltaLam[50] = { 0 };


			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("PUTSACTOCOS"), _T("PutSactoCos"), szHeighCos, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("DELTALAMHEIGH"), _T("DeltaLamHight"), szDeltaLam, NULL);

			long CurPos = CControlCard::GetAxisPosition(X2);


			long lHeigh =  static_cast<long>(atof(szHeighCos)) - CurPos +   static_cast<long>(atof(szDeltaLam))*(pSac->nSelCos - 10001);

			CControlCard::MoveRaxis(X2, -lHeigh);
			CControlCard::WaitRaxisStop(X2);
			//��UV��
			CControlCard::WriteIO(Card2, iOut[35], HIGHT);

			//��ʱ
			Sleep(5000);

			//�ر�UV��
			CControlCard::WriteIO(Card2, iOut[35], LOW);

			//�ر����
			CControlCard::WriteIO(Card2, iOut[2], LOW);

			//��μ������Ƿ�ر�
			if ( 0 == CControlCard::ReadIO(Card2, iOut[24]))
			{
				Sleep(500);
				if (0 == CControlCard::ReadIO(Card2, iOut[24]))
				{
					Sleep(500);
					if (0 == CControlCard::ReadIO(Card2, iOut[24]))
					{
						//AfxMessageBox(_T("���������Ƿ�������"));
						::PostMessage(pSac->m_hWnd, WM_ERRMESSAGE, MSG_MOUSE_WORKWELL, NULL);
						return 0;
					}
				}
			}
			//̧��������
			CControlCard::MoveRaxis(X2, lHeigh);
		}
		break;
	case COS10:
		{
			//�����˶���COS1���ĵ�
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, -lWStep);
			CControlCard::WaitRaxisStop(X0);
			CControlCard::MoveRaxis(X1, -lHStep);
			CControlCard::WaitRaxisStop(X1);
#if 0
			//��׼�Ƕ�
			//�Ƕ�ת�������壬���ﶨ��1�ȵ���20����
			nPuls_Angle = nLanpAngle * 20;

			//���Ƶ����תĳ���Ƕ�
			CControlCard::MoveRaxis(X3, nPuls_Angle);
			CControlCard::WaitRaxisStop(X3);
#endif
			//��ʼ��SAC
			//����X2����Ҫ�˶��ľ���
			CHAR szHeighCos[50] = { 0 };
			CHAR szDeltaLam[50] = { 0 };


			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("PUTSACTOCOS"), _T("PutSactoCos"), szHeighCos, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("DELTALAMHEIGH"), _T("DeltaLamHight"), szDeltaLam, NULL);

			long CurPos = CControlCard::GetAxisPosition(X2);


			long lHeigh =  static_cast<long>(atof(szHeighCos)) - CurPos +   static_cast<long>(atof(szDeltaLam))*(pSac->nSelCos - 10001);

			CControlCard::MoveRaxis(X2, -lHeigh);
			CControlCard::WaitRaxisStop(X2);
			//��UV��
			CControlCard::WriteIO(Card2, iOut[35], HIGHT);

			//��ʱ
			Sleep(5000);

			//�ر�UV��
			CControlCard::WriteIO(Card2, iOut[35], LOW);

			//�ر����
			CControlCard::WriteIO(Card2, iOut[2], LOW);

			//��μ������Ƿ�ر�
			if ( 0 == CControlCard::ReadIO(Card2, iOut[24]))
			{
				Sleep(500);
				if (0 == CControlCard::ReadIO(Card2, iOut[24]))
				{
					Sleep(500);
					if (0 == CControlCard::ReadIO(Card2, iOut[24]))
					{
						//AfxMessageBox(_T("���������Ƿ�������"));
						::PostMessage(pSac->m_hWnd, WM_ERRMESSAGE, MSG_MOUSE_WORKWELL, NULL);
						return 0;
					}
				}
			}
			//̧��������
			CControlCard::MoveRaxis(X2, lHeigh);
		}
		break;
	case COS11:
		{
			//�����˶���COS1���ĵ�
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, -lWStep);
			CControlCard::WaitRaxisStop(X0);
			CControlCard::MoveRaxis(X1, -lHStep);
			CControlCard::WaitRaxisStop(X1);
#if 0
			//��׼�Ƕ�
			//�Ƕ�ת�������壬���ﶨ��1�ȵ���20����
			nPuls_Angle = nLanpAngle * 20;

			//���Ƶ����תĳ���Ƕ�
			CControlCard::MoveRaxis(X3, nPuls_Angle);
			CControlCard::WaitRaxisStop(X3);
#endif
			//��ʼ��SAC
			//����X2����Ҫ�˶��ľ���
			CHAR szHeighCos[50] = { 0 };
			CHAR szDeltaLam[50] = { 0 };


			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("PUTSACTOCOS"), _T("PutSactoCos"), szHeighCos, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("DELTALAMHEIGH"), _T("DeltaLamHight"), szDeltaLam, NULL);

			long CurPos = CControlCard::GetAxisPosition(X2);


			long lHeigh =  static_cast<long>(atof(szHeighCos)) - CurPos +   static_cast<long>(atof(szDeltaLam))*(pSac->nSelCos - 10001);

			CControlCard::MoveRaxis(X2, -lHeigh);
			CControlCard::WaitRaxisStop(X2);
			//��UV��
			CControlCard::WriteIO(Card2, iOut[35], HIGHT);

			//��ʱ
			Sleep(5000);

			//�ر�UV��
			CControlCard::WriteIO(Card2, iOut[35], LOW);

			//�ر����
			CControlCard::WriteIO(Card2, iOut[2], LOW);

			//��μ������Ƿ�ر�
			if ( 0 == CControlCard::ReadIO(Card2, iOut[24]))
			{
				Sleep(500);
				if (0 == CControlCard::ReadIO(Card2, iOut[24]))
				{
					Sleep(500);
					if (0 == CControlCard::ReadIO(Card2, iOut[24]))
					{
						//AfxMessageBox(_T("���������Ƿ�������"));
						::PostMessage(pSac->m_hWnd, WM_ERRMESSAGE, MSG_MOUSE_WORKWELL, NULL);
						return 0;
					}
				}
			}
			//̧��������
			CControlCard::MoveRaxis(X2, lHeigh);
		}
		break;
	case COS12:
		{
			//�����˶���COS1���ĵ�
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, -lWStep);
			CControlCard::WaitRaxisStop(X0);
			CControlCard::MoveRaxis(X1, -lHStep);
			CControlCard::WaitRaxisStop(X1);
#if 0
			//��׼�Ƕ�
			//�Ƕ�ת�������壬���ﶨ��1�ȵ���20����
			nPuls_Angle = nLanpAngle * 20;

			//���Ƶ����תĳ���Ƕ�
			CControlCard::MoveRaxis(X3, nPuls_Angle);
			CControlCard::WaitRaxisStop(X3);
#endif
			//��ʼ��SAC
			//����X2����Ҫ�˶��ľ���
			CHAR szHeighCos[50] = { 0 };
			CHAR szDeltaLam[50] = { 0 };


			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("PUTSACTOCOS"), _T("PutSactoCos"), szHeighCos, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("DELTALAMHEIGH"), _T("DeltaLamHight"), szDeltaLam, NULL);

			long CurPos = CControlCard::GetAxisPosition(X2);


			long lHeigh =  static_cast<long>(atof(szHeighCos)) - CurPos +   static_cast<long>(atof(szDeltaLam))*(pSac->nSelCos - 10001);

			CControlCard::MoveRaxis(X2, -lHeigh);
			CControlCard::WaitRaxisStop(X2);
			//��UV��
			CControlCard::WriteIO(Card2, iOut[35], HIGHT);

			//��ʱ
			Sleep(5000);

			//�ر�UV��
			CControlCard::WriteIO(Card2, iOut[35], LOW);

			//�ر����
			CControlCard::WriteIO(Card2, iOut[2], LOW);

			//��μ������Ƿ�ر�
			if ( 0 == CControlCard::ReadIO(Card2, iOut[24]))
			{
				Sleep(500);
				if (0 == CControlCard::ReadIO(Card2, iOut[24]))
				{
					Sleep(500);
					if (0 == CControlCard::ReadIO(Card2, iOut[24]))
					{
						//AfxMessageBox(_T("���������Ƿ�������"));
						::PostMessage(pSac->m_hWnd, WM_ERRMESSAGE, MSG_MOUSE_WORKWELL, NULL);
						return 0;
					}
				}
			}
			//̧��������
			CControlCard::MoveRaxis(X2, lHeigh);
		}
		break;
	case COS13:
		{
			//�����˶���COS1���ĵ�
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, -lWStep);
			CControlCard::WaitRaxisStop(X0);
			CControlCard::MoveRaxis(X1, -lHStep);
			CControlCard::WaitRaxisStop(X1);
#if 0
			//��׼�Ƕ�
			//�Ƕ�ת�������壬���ﶨ��1�ȵ���20����
			nPuls_Angle = nLanpAngle * 20;

			//���Ƶ����תĳ���Ƕ�
			CControlCard::MoveRaxis(X3, nPuls_Angle);
			CControlCard::WaitRaxisStop(X3);
#endif
			//��ʼ��SAC
			//����X2����Ҫ�˶��ľ���
			CHAR szHeighCos[50] = { 0 };
			CHAR szDeltaLam[50] = { 0 };


			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("PUTSACTOCOS"), _T("PutSactoCos"), szHeighCos, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("DELTALAMHEIGH"), _T("DeltaLamHight"), szDeltaLam, NULL);

			long CurPos = CControlCard::GetAxisPosition(X2);


			long lHeigh =  static_cast<long>(atof(szHeighCos)) - CurPos +   static_cast<long>(atof(szDeltaLam))*(pSac->nSelCos - 10001);

			CControlCard::MoveRaxis(X2, -lHeigh);
			CControlCard::WaitRaxisStop(X2);
			//��UV��
			CControlCard::WriteIO(Card2, iOut[35], HIGHT);

			//��ʱ
			Sleep(5000);

			//�ر�UV��
			CControlCard::WriteIO(Card2, iOut[35], LOW);

			//�ر����
			CControlCard::WriteIO(Card2, iOut[2], LOW);

			//��μ������Ƿ�ر�
			if ( 0 == CControlCard::ReadIO(Card2, iOut[24]))
			{
				Sleep(500);
				if (0 == CControlCard::ReadIO(Card2, iOut[24]))
				{
					Sleep(500);
					if (0 == CControlCard::ReadIO(Card2, iOut[24]))
					{
						//AfxMessageBox(_T("���������Ƿ�������"));
						::PostMessage(pSac->m_hWnd, WM_ERRMESSAGE, MSG_MOUSE_WORKWELL, NULL);
						return 0;
					}
				}
			}
			//̧��������
			CControlCard::MoveRaxis(X2, lHeigh);
		}
		break;
	case COS15:
		{
			//�����˶���COS1���ĵ�
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, -lWStep);
			CControlCard::WaitRaxisStop(X0);
			CControlCard::MoveRaxis(X1, -lHStep);
			CControlCard::WaitRaxisStop(X1);
#if 0
			//��׼�Ƕ�
			//�Ƕ�ת�������壬���ﶨ��1�ȵ���20����
			nPuls_Angle = nLanpAngle * 20;

			//���Ƶ����תĳ���Ƕ�
			CControlCard::MoveRaxis(X3, nPuls_Angle);
			CControlCard::WaitRaxisStop(X3);
#endif
			//��ʼ��SAC
			//����X2����Ҫ�˶��ľ���
			CHAR szHeighCos[50] = { 0 };
			CHAR szDeltaLam[50] = { 0 };


			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("PUTSACTOCOS"), _T("PutSactoCos"), szHeighCos, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("DELTALAMHEIGH"), _T("DeltaLamHight"), szDeltaLam, NULL);

			long CurPos = CControlCard::GetAxisPosition(X2);


			long lHeigh =  static_cast<long>(atof(szHeighCos)) - CurPos +   static_cast<long>(atof(szDeltaLam))*(pSac->nSelCos - 10001);

			CControlCard::MoveRaxis(X2, -lHeigh);
			CControlCard::WaitRaxisStop(X2);
			//��UV��
			CControlCard::WriteIO(Card2, iOut[35], HIGHT);

			//��ʱ
			Sleep(5000);

			//�ر�UV��
			CControlCard::WriteIO(Card2, iOut[35], LOW);

			//�ر����
			CControlCard::WriteIO(Card2, iOut[2], LOW);

			//��μ������Ƿ�ر�
			if ( 0 == CControlCard::ReadIO(Card2, iOut[24]))
			{
				Sleep(500);
				if (0 == CControlCard::ReadIO(Card2, iOut[24]))
				{
					Sleep(500);
					if (0 == CControlCard::ReadIO(Card2, iOut[24]))
					{
						//AfxMessageBox(_T("���������Ƿ�������"));
						::PostMessage(pSac->m_hWnd, WM_ERRMESSAGE, MSG_MOUSE_WORKWELL, NULL);
						return 0;
					}
				}
			}
			//̧��������
			CControlCard::MoveRaxis(X2, lHeigh);
		}
		break;
	case COS16:
		{
			//�����˶���COS1���ĵ�
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, -lWStep);
			CControlCard::WaitRaxisStop(X0);
			CControlCard::MoveRaxis(X1, -lHStep);
			CControlCard::WaitRaxisStop(X1);
#if 0
			//��׼�Ƕ�
			//�Ƕ�ת�������壬���ﶨ��1�ȵ���20����
			nPuls_Angle = nLanpAngle * 20;

			//���Ƶ����תĳ���Ƕ�
			CControlCard::MoveRaxis(X3, nPuls_Angle);
			CControlCard::WaitRaxisStop(X3);
#endif
			//��ʼ��SAC
			//����X2����Ҫ�˶��ľ���
			CHAR szHeighCos[50] = { 0 };
			CHAR szDeltaLam[50] = { 0 };


			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("PUTSACTOCOS"), _T("PutSactoCos"), szHeighCos, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("DELTALAMHEIGH"), _T("DeltaLamHight"), szDeltaLam, NULL);

			long CurPos = CControlCard::GetAxisPosition(X2);


			long lHeigh =  static_cast<long>(atof(szHeighCos)) - CurPos +   static_cast<long>(atof(szDeltaLam))*(pSac->nSelCos - 10001);

			CControlCard::MoveRaxis(X2, -lHeigh);
			CControlCard::WaitRaxisStop(X2);
			//��UV��
			CControlCard::WriteIO(Card2, iOut[35], HIGHT);

			//��ʱ
			Sleep(5000);

			//�ر�UV��
			CControlCard::WriteIO(Card2, iOut[35], LOW);

			//�ر����
			CControlCard::WriteIO(Card2, iOut[2], LOW);

			//��μ������Ƿ�ر�
			if ( 0 == CControlCard::ReadIO(Card2, iOut[24]))
			{
				Sleep(500);
				if (0 == CControlCard::ReadIO(Card2, iOut[24]))
				{
					Sleep(500);
					if (0 == CControlCard::ReadIO(Card2, iOut[24]))
					{
						//AfxMessageBox(_T("���������Ƿ�������"));
						::PostMessage(pSac->m_hWnd, WM_ERRMESSAGE, MSG_MOUSE_WORKWELL, NULL);
						return 0;
					}
				}
			}
			//̧��������
			CControlCard::MoveRaxis(X2, lHeigh);
		}
		break;
	case COS17:
		{
			//�����˶���COS1���ĵ�
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, -lWStep);
			CControlCard::WaitRaxisStop(X0);
			CControlCard::MoveRaxis(X1, -lHStep);
			CControlCard::WaitRaxisStop(X1);
#if 0
			//��׼�Ƕ�
			//�Ƕ�ת�������壬���ﶨ��1�ȵ���20����
			nPuls_Angle = nLanpAngle * 20;

			//���Ƶ����תĳ���Ƕ�
			CControlCard::MoveRaxis(X3, nPuls_Angle);
			CControlCard::WaitRaxisStop(X3);
#endif
			//��ʼ��SAC
			//����X2����Ҫ�˶��ľ���
			CHAR szHeighCos[50] = { 0 };
			CHAR szDeltaLam[50] = { 0 };


			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("PUTSACTOCOS"), _T("PutSactoCos"), szHeighCos, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("DELTALAMHEIGH"), _T("DeltaLamHight"), szDeltaLam, NULL);

			long CurPos = CControlCard::GetAxisPosition(X2);


			long lHeigh =  static_cast<long>(atof(szHeighCos)) - CurPos +   static_cast<long>(atof(szDeltaLam))*(pSac->nSelCos - 10001);

			CControlCard::MoveRaxis(X2, -lHeigh);
			CControlCard::WaitRaxisStop(X2);
			//��UV��
			CControlCard::WriteIO(Card2, iOut[35], HIGHT);

			//��ʱ
			Sleep(5000);

			//�ر�UV��
			CControlCard::WriteIO(Card2, iOut[35], LOW);

			//�ر����
			CControlCard::WriteIO(Card2, iOut[2], LOW);

			//��μ������Ƿ�ر�
			if ( 0 == CControlCard::ReadIO(Card2, iOut[24]))
			{
				Sleep(500);
				if (0 == CControlCard::ReadIO(Card2, iOut[24]))
				{
					Sleep(500);
					if (0 == CControlCard::ReadIO(Card2, iOut[24]))
					{
						//AfxMessageBox(_T("���������Ƿ�������"));
						::PostMessage(pSac->m_hWnd, WM_ERRMESSAGE, MSG_MOUSE_WORKWELL, NULL);
						return 0;
					}
				}
			}
			//̧��������
			CControlCard::MoveRaxis(X2, lHeigh);
		}
		break;
	case COS18:
		{
			//�����˶���COS1���ĵ�
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, -lWStep);
			CControlCard::WaitRaxisStop(X0);
			CControlCard::MoveRaxis(X1, -lHStep);
			CControlCard::WaitRaxisStop(X1);
#if 0
			//��׼�Ƕ�
			//�Ƕ�ת�������壬���ﶨ��1�ȵ���20����
			nPuls_Angle = nLanpAngle * 20;

			//���Ƶ����תĳ���Ƕ�
			CControlCard::MoveRaxis(X3, nPuls_Angle);
			CControlCard::WaitRaxisStop(X3);
#endif
			//��ʼ��SAC
			//����X2����Ҫ�˶��ľ���
			CHAR szHeighCos[50] = { 0 };
			CHAR szDeltaLam[50] = { 0 };


			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("PUTSACTOCOS"), _T("PutSactoCos"), szHeighCos, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("DELTALAMHEIGH"), _T("DeltaLamHight"), szDeltaLam, NULL);

			long CurPos = CControlCard::GetAxisPosition(X2);


			long lHeigh =  static_cast<long>(atof(szHeighCos)) - CurPos +   static_cast<long>(atof(szDeltaLam))*(pSac->nSelCos - 10001);

			CControlCard::MoveRaxis(X2, -lHeigh);
			CControlCard::WaitRaxisStop(X2);
			//��UV��
			CControlCard::WriteIO(Card2, iOut[35], HIGHT);

			//��ʱ
			Sleep(5000);

			//�ر�UV��
			CControlCard::WriteIO(Card2, iOut[35], LOW);

			//�ر����
			CControlCard::WriteIO(Card2, iOut[2], LOW);

			//��μ������Ƿ�ر�
			if ( 0 == CControlCard::ReadIO(Card2, iOut[24]))
			{
				Sleep(500);
				if (0 == CControlCard::ReadIO(Card2, iOut[24]))
				{
					Sleep(500);
					if (0 == CControlCard::ReadIO(Card2, iOut[24]))
					{
						//AfxMessageBox(_T("���������Ƿ�������"));
						::PostMessage(pSac->m_hWnd, WM_ERRMESSAGE, MSG_MOUSE_WORKWELL, NULL);
						return 0;
					}
				}
			}
			//̧��������
			CControlCard::MoveRaxis(X2, lHeigh);
		}
		break;
	case COS19:
		{
			//�����˶���COS1���ĵ�
			CHAR szWStep[50] = { 0 };
			CHAR szHStep[50] = { 0 };
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("WStep"), szWStep, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("LENSTOSUC"), _T("HStep"), szHStep, NULL);
			long lWStep,lHStep;

			lWStep = static_cast<long>(atof(szWStep));
			lHStep = static_cast<long>(atof(szHStep));

			CControlCard::MoveRaxis(X0, -lWStep);
			CControlCard::WaitRaxisStop(X0);
			CControlCard::MoveRaxis(X1, -lHStep);
			CControlCard::WaitRaxisStop(X1);
#if 0
			//��׼�Ƕ�
			//�Ƕ�ת�������壬���ﶨ��1�ȵ���20����
			nPuls_Angle = nLanpAngle * 20;

			//���Ƶ����תĳ���Ƕ�
			CControlCard::MoveRaxis(X3, nPuls_Angle);
			CControlCard::WaitRaxisStop(X3);
#endif
			//��ʼ��SAC
			//����X2����Ҫ�˶��ľ���
			CHAR szHeighCos[50] = { 0 };
			CHAR szDeltaLam[50] = { 0 };


			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("PUTSACTOCOS"), _T("PutSactoCos"), szHeighCos, NULL);
			CIniClient::Instance(_T("scanlocation.ini"))->GetValue(_T("DELTALAMHEIGH"), _T("DeltaLamHight"), szDeltaLam, NULL);

			long CurPos = CControlCard::GetAxisPosition(X2);


			long lHeigh =  static_cast<long>(atof(szHeighCos)) - CurPos +   static_cast<long>(atof(szDeltaLam))*(pSac->nSelCos - 10001);

			CControlCard::MoveRaxis(X2, -lHeigh);
			CControlCard::WaitRaxisStop(X2);
			//��UV��
			CControlCard::WriteIO(Card2, iOut[35], HIGHT);

			//��ʱ
			Sleep(5000);

			//�ر�UV��
			CControlCard::WriteIO(Card2, iOut[35], LOW);

			//�ر����
			CControlCard::WriteIO(Card2, iOut[2], LOW);

			//��μ������Ƿ�ر�
			if ( 0 == CControlCard::ReadIO(Card2, iOut[24]))
			{
				Sleep(500);
				if (0 == CControlCard::ReadIO(Card2, iOut[24]))
				{
					Sleep(500);
					if (0 == CControlCard::ReadIO(Card2, iOut[24]))
					{
						//AfxMessageBox(_T("���������Ƿ�������"));
						::PostMessage(pSac->m_hWnd, WM_ERRMESSAGE, MSG_MOUSE_WORKWELL, NULL);
						return 0;
					}
				}
			}
			//̧��������
			CControlCard::MoveRaxis(X2, lHeigh);
		}
		break;

	}

	//SAC������һ
	CSacResourceManage::Instance()->SubOne();
	//·����һ
	CLampStandBoxManage::instance()->SubOne();
	SetEvent(pSac->m_EventMaster);

	return 0;
}

void CAutoSacProDlg::OnCbnSelchangeComLampsel()
{
	int nSel = m_com_LamSel.GetCurSel();
	switch(nSel)
	{
	case 0:
		{
			CLampStandBoxManage::instance()->SetCurSel(nSel);
			nCurLampSel = LAM1;
		}
		break;
	case 1:
		{
			CLampStandBoxManage::instance()->SetCurSel(nSel);
			nCurLampSel = LAM2;
		}
		break;
	case 2:
		{
			CLampStandBoxManage::instance()->SetCurSel(nSel);
			nCurLampSel = LAM3;
		}
		break;
	case 3:
		{
			CLampStandBoxManage::instance()->SetCurSel(nSel);
			nCurLampSel = LAM4;
		}
		break;
	}
}


void CAutoSacProDlg::OnBnClickedCheckSingle()
{
	//��·ģʽ��ѡ�ſ��Խ��е�·ģʽ�ж�
	int nChecked = ((CButton *)GetDlgItem(IDC_CHECK_SINGLE))->GetCheck();
	if (nChecked)
	{
		for (int nIndex = IDC_BTN_COS1 ; nIndex <= IDC_BTN_COS19; nIndex++)
		{
			GetDlgItem(nIndex)->EnableWindow(TRUE); //��·ģʽ
		}
	} 
	else
	{
		for (int nIndex = IDC_BTN_COS1 ; nIndex <= IDC_BTN_COS19; nIndex++)
		{
			GetDlgItem(nIndex)->EnableWindow(FALSE); //����
		}
	}
}

void CAutoSacProDlg::SaveImages()
{
	m_pSink->snapImages(1);
	m_pSink->getLastAcqMemBuffer()->save("image.bmp");
}

void CAutoSacProDlg::Emgstop()
{
	//��ֹͣ���
	int i = 0;
	while(i < 50)
	{
		for (int nAxis = 0; nAxis < 6; nAxis++)
		{
			CControlCard::StopRaxis(nAxis);
		}
		Sleep(300);
	}
	

	//ǿ�ƽ����߳�

	if (pThreadOpr != NULL)
	{
		DWORD dwExit=0;
		::GetExitCodeThread(pThreadOpr->m_hThread,&dwExit);
		::TerminateThread(pThreadOpr->m_hThread,dwExit);
	}

	if (pAutoThread != NULL)
	{
		DWORD dwExit=0;
		::GetExitCodeThread(pAutoThread->m_hThread,&dwExit);
		::TerminateThread(pAutoThread->m_hThread,dwExit);
	}



}

UINT CAutoSacProDlg::AutoThread( LPVOID lpParam )
{
	CAutoSacProDlg *pAuto = (CAutoSacProDlg*)lpParam;

		//ȷ�ϵ���
		for (int nlam = pAuto->nCurLampSel; nlam <= LAM4; nlam++ )
		{
			for (int nCos = COS1; nCos <= COS19; nCos++)
			{
				
				WaitForSingleObject(pAuto->m_EventMaster, INFINITE);
				switch(nlam)
				{
				case 0:
					{
						CLampStandBoxManage::instance()->SetCurSel(nlam);
						pAuto->nCurLampSel = LAM1;
					}
					break;
				case 1:
					{
						CLampStandBoxManage::instance()->SetCurSel(nlam);
						pAuto->nCurLampSel = LAM2;
					}
					break;
				case 2:
					{
						CLampStandBoxManage::instance()->SetCurSel(nlam);
						pAuto->nCurLampSel = LAM3;
					}
					break;
				case 3:
					{
						CLampStandBoxManage::instance()->SetCurSel(nlam);
						pAuto->nCurLampSel = LAM4;
					}
					break;
				}

				pAuto->nSelCos = nCos;
				ResetEvent(pAuto->m_EventMaster);
				pAuto->pThreadOpr = AfxBeginThread(OPera,pAuto);
			}
		}

    //����·����������
	//�������͵�����λ��
	CMoveToPhotoLoc::MovetoLampLoc(UPLOC,100);
	if (CControlCard::ReadIO(Card2 ,iOut[31]) == 0 && CControlCard::ReadIO(Card2 ,iOut[32]) == 0)
	{
		//AfxMessageBox(_T("δ��⵽����,����"));
		::PostMessage(pAuto->m_hWnd, WM_ERRMESSAGE, MSG_CHECK_PALLET_ARRIVE, NULL);
		return 0;
	}
	
	//����
	CControlCard::WriteIO(Card2,iOut[7],HIGHT);


	return 0;
}


void CAutoSacProDlg::OnBnClickedPustres()
{
	if(!CControlCard::ReadIO(Card2,iOut[16]))
	{
		AfxMessageBox(_T("δ��⵽����!"));
	}

	CControlCard::WriteIO(Card2, iOut[8], HIGHT);

	Sleep(1000);

	CControlCard::WriteIO(Card2, iOut[8], LOW);

}

LRESULT CAutoSacProDlg::OnErrMsgShow( WPARAM wParam,LPARAM lParam )
{
   switch(static_cast<int>(wParam))
   {
   case RUN_NORMAL:
	   {
		   m_CMsgShow.SetWindowText(_T("ON"));
		   m_CMsgShow.SetColor(RGB(0,255,0));
		   m_CMsgShow.SetValueNbDigit(3,0);
		   m_CMsgShow.StringMode(TRUE, FALSE);
		   CControlCard::WriteIO(Card2, iOut[12], HIGHT);
		   CControlCard::WriteIO(Card2, iOut[13], LOW);
		   CControlCard::WriteIO(Card2, iOut[14], LOW);
		   
	   }
	   break;
   case RUN_ERR:
	   {
		   m_CMsgShow.SetWindowText(_T("ERR"));
		   m_CMsgShow.SetColor(RGB(255,0,0));
		   m_CMsgShow.SetValueNbDigit(3,0);
		   m_CMsgShow.StringMode(TRUE, FALSE);
		   CControlCard::WriteIO(Card2, iOut[12], LOW);
		   CControlCard::WriteIO(Card2, iOut[13], LOW);
		   CControlCard::WriteIO(Card2, iOut[14], HIGHT);
	   }
	   break;
   case RUN_EMG:
	   {
		   m_CMsgShow.SetWindowText(_T("ERR"));
		   m_CMsgShow.SetColor(RGB(255,0,0));
		   m_CMsgShow.SetValueNbDigit(3,0);
		   m_CMsgShow.StringMode(TRUE, FALSE);
		   CControlCard::WriteIO(Card2, iOut[12], LOW); //��
		   CControlCard::WriteIO(Card2, iOut[13], LOW); //��
		   CControlCard::WriteIO(Card2, iOut[14], HIGHT); //��
	   }
	   break;
   case MSG_RES_PUTWELL:
	   {
		   m_CMsgShow.SetWindowText(_T("ERR"));
		   m_CMsgShow.SetColor(RGB(255,0,0));
		   m_CMsgShow.SetValueNbDigit(3,0);
		   m_CMsgShow.StringMode(TRUE, FALSE);
		   CControlCard::WriteIO(Card2, iOut[12], LOW);
		   CControlCard::WriteIO(Card2, iOut[13], LOW);
		   CControlCard::WriteIO(Card2, iOut[14], HIGHT);
		   AfxMessageBox("���������Ƿ�ź�");
	   }
	   break;
   case MSG_MOUSE_WORKWELL:
	   {
		   m_CMsgShow.SetWindowText(_T("ERR"));
		   m_CMsgShow.SetColor(RGB(255,0,0));
		   m_CMsgShow.SetValueNbDigit(3,0);
		   m_CMsgShow.StringMode(TRUE, FALSE);
		   CControlCard::WriteIO(Card2, iOut[12], LOW);
		   CControlCard::WriteIO(Card2, iOut[13], LOW);
		   CControlCard::WriteIO(Card2, iOut[14], HIGHT);
		   AfxMessageBox("���������Ƿ���������");
	   }
	   break;
   case MSG_CHECK_PALLET_ARRIVE:
	   {
		   m_CMsgShow.SetWindowText(_T("ERR"));
		   m_CMsgShow.SetColor(RGB(255,0,0));
		   m_CMsgShow.SetValueNbDigit(3,0);
		   m_CMsgShow.StringMode(TRUE, FALSE);
		   CControlCard::WriteIO(Card2, iOut[12], LOW);
		   CControlCard::WriteIO(Card2, iOut[13], LOW);
		   CControlCard::WriteIO(Card2, iOut[14], HIGHT);
		   AfxMessageBox("δ��⵽����,����");
	   }
	   break;
   }
   return (LRESULT)0;
}