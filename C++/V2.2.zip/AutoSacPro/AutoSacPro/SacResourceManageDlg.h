#ifndef _H_SACRESOURCEMANAGEDLG_
#define _H_SACRESOURCEMANAGEDLG_
#include "afxwin.h"
#include "SacResourceManage.h"
#pragma once

class CSacResourceManageDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CSacResourceManageDlg)

public:
	CSacResourceManageDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CSacResourceManageDlg();

// �Ի�������
	enum { IDD = IDD_DIALOG_SACRESDLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	int m_nSacSumNum;
	int m_nUsedNum;
	int m_nRemainNum;
	CString m_strCurPos;
	CComboBox m_com_Rows;
	CComboBox m_com_rows;
	afx_msg void OnBnClickedOk();
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedButtonSub();
	afx_msg void OnBnClickedButtonReset();

public:
	void UpdateSAC();
};

#endif //_H_SACRESOURCEMANAGEDLG_