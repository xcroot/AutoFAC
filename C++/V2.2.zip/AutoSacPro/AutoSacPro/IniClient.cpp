// Ini.cpp: implementation of the CIni class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
//#include "userini.h"
#include "IniClient.h"
#include <shlwapi.h>
#include <stdlib.h>

#define MAX_ALLSECTIONS 2048 //ȫ���Ķ���
#define MAX_SECTION 260 //һ����������
#define MAX_ALLKEYS 6000 //ȫ���ļ���
#define MAX_KEY 260 //һ����������

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//CString CIniClient::m_strFileName;

CIniClient::CIniClient()
{

}

CIniClient::~CIniClient()
{

}

static CIniClient* ini=NULL;

bool CIniClient::SetFileName(char * FileName)
{
	CFile file;
	CFileStatus status;
	
	if(!file.GetStatus((LPCTSTR)FileName,status))
	return false;

	m_strFileName= FileName;
	return true;
}

CString& CIniClient::GetFileName()
{
	return m_strFileName;
}

bool CIniClient::SetValue(CHAR * Section, CHAR * Key, int Value,bool Create)
{
	 CHAR tempValue[11] = {0};
	_itoa_s(Value,tempValue,10);

	 return SetValue(Section,Key,tempValue,Create);
}

bool CIniClient::SetValue( CHAR * Section, CHAR * Key, float Value,bool bCreate/*=true*/ )
{
	CHAR tempValue[11] = {0};
	sprintf(tempValue,"%.3f",Value);
	return SetValue(Section,Key,tempValue,bCreate);
}

bool CIniClient::SetValue( CHAR * Section, CHAR * Key, long Value,bool bCreate/*=true*/ )
{
	CHAR tempValue[11] = {0};
	double temp = (double)Value;
	sprintf(tempValue,"%d",Value);
	return SetValue(Section,Key,tempValue,bCreate);
}

bool CIniClient::SetValue(CHAR * Section, CHAR * Key, CHAR * Value,bool Create)
{
	CHAR  Temp[MAX_PATH] ={0};
	if (!Create)
	{
		 GetPrivateProfileString( Section, Key,_T("!*&*none-value*&!*"), Temp,MAX_PATH,m_strFileName);
		 if( strcmp( Temp,_T("!*&*none-value*&!*"))==0)
		 return true;
	}

	if(WritePrivateProfileString( Section, Key, Value,m_strFileName))
		return true;
	else
		return false;
}




bool CIniClient::GetValue(CHAR * Section, CHAR * Key,CHAR * Value,CHAR * Default)
{
	DWORD dValue=GetPrivateProfileString(Section, Key,Default,Value,MAX_PATH,m_strFileName);
	return  true;
}

int CIniClient::GetSections(CStringArray& arrSection)
{
	/*
	������������
	GetPrivateProfileSectionNames - �� ini �ļ��л�� Section ������
	��� ini �������� Section: [sec1] �� [sec2]���򷵻ص��� 'sec1',0,'sec2',0,0 �����㲻֪�� 
	ini ������Щ section ��ʱ���������� api ����ȡ����
	*/
	int i; 
	int iPos=0; 

	TCHAR chSectionNames[MAX_ALLSECTIONS]={0}; 
	TCHAR chSection[MAX_SECTION]={0};
	GetPrivateProfileSectionNames(chSectionNames,MAX_ALLSECTIONS,m_strFileName);

	arrSection.RemoveAll();
	for(i=0;i<MAX_ALLSECTIONS;i++)
	{
		 chSection[iPos++]=chSectionNames[i];
		 if(chSectionNames[i]==0)
		 { 
		  arrSection.Add(chSection);
		  memset(chSection,0,MAX_SECTION);
		  iPos=0;
		  if (chSectionNames[i]==chSectionNames[i+1])
			  break;
		 }
	}
	return (int)arrSection.GetSize();
}

int CIniClient::GetKeyValues(CStringArray& arrKey,CStringArray& arrValue, char * Section)
{
	/*
	������������
	GetPrivateProfileSection- �� ini �ļ��л��һ��Section��ȫ��������ֵ��
	���ini����һ���Σ������� "��1=ֵ1" "��2=ֵ2"���򷵻ص��� '��1=ֵ1',0,'��2=ֵ2',0,0 �����㲻֪�� 
	���һ�����е����м���ֵ�����������
	*/
	int i; 
	int iPos=0;
	CString strKeyValue;
	TCHAR chKeyNames[MAX_ALLKEYS]={0}; 
	TCHAR chKey[MAX_KEY]={0}; 

	GetPrivateProfileSection(Section,chKeyNames,MAX_ALLKEYS,m_strFileName);

	arrKey.RemoveAll();
	arrValue.RemoveAll();

	for(i=0;i<MAX_ALLKEYS;i++)
	{
		 chKey[iPos++]=chKeyNames[i];
		 if(chKeyNames[i]==0)
		 {
			  strKeyValue=chKey;
			  arrKey.Add(strKeyValue.Left(strKeyValue.Find(_T("="))));
			  arrValue.Add(strKeyValue.Mid(strKeyValue.Find(_T("="))+1));
			  memset(chKey,0,MAX_KEY);
			  iPos=0;
			  if (chKeyNames[i]==chKeyNames[i+1])
				  break;
		 }		 
	}
	return (int)arrKey.GetSize();
}

bool CIniClient::test()
{	
	if(!PathFileExists(m_strFileName)) return false;
	/* TODO:
	const char* dbkey[]={"Host","Port","Name","DBName"};
	const char* serverkey[]={"Port","MaxConnect","MaxJob"};
	const char* dirkey[]={"Share"};
	if(!IsInvaild()) return false;	
	if(!CheckSection("DB",dbkey,4)) return false;
	if(!CheckSection("SERVER",serverkey,3)) return false;
	if(!CheckSection("DIR",dirkey,1)) return false;
	*/
	return true;	
}

bool CIniClient::CheckSection(CString Section, const char *Keys[], int keynumber)
{
	char Value[MAX_PATH],Default[2];	
	strcpy_s(Default,_T("$"));
	for(int i=0;i<keynumber;i++)
	{
		if(!GetPrivateProfileString(Section,Keys[i],Default,Value,MAX_PATH,m_strFileName)) return false;
		if(Value[0]=='$') return false;
	}
	return true;
}

// CIniClient * CIniClient::Instance()
// {
// 	if(ini==NULL) 
// 	{
// 		wchar_t FilePath[MAX_PATH] = {0};
// 		CString path;
// 		char mpath[MAX_PATH] = {0};
// 		GetModuleFileName(NULL, FilePath, sizeof(FilePath));
// 		int n=CString(FilePath).ReverseFind('\\');
// 		path=CString(FilePath).Left(n+1);
// 		path+=GetFileName();//"SysConfig.ini";
// 		WideToMulti(path.GetBuffer(path.GetLength()),mpath);
// 		ini = new CIniClient(mpath);
// 	}
// 	return ini;
// }

CIniClient * CIniClient::Instance(const CString &strFileName)
{
	CHAR FilePath[MAX_PATH] = {0};
	CString path;
	char mpath[MAX_PATH] = {0};
	GetModuleFileName(NULL, FilePath, sizeof(FilePath));
	int n=CString(FilePath).ReverseFind('\\');
	path=CString(FilePath).Left(n+1);
	path+=strFileName;//"SysConfig.ini";
	if(ini==NULL) 
	{
		//WideToMulti(path.GetBuffer(path.GetLength()),mpath);
		ini = new CIniClient(path.GetBuffer(path.GetLength()));
	}
	ini->m_strFileName = path;
	return ini;
}

bool CIniClient::IsInvaild()
{
	DWORD KeyVersion=GetPrivateProfileInt(_T("KeyVerSion"),_T("KeyVersion"),-1,m_strFileName);
	CFile f;	
	if (!f.Open(m_strFileName, CFile::modeNoTruncate|CFile::modeRead|CFile::shareDenyNone))
		return false;
	DWORD keylen=(DWORD)f.GetLength();
	f.Close();
	KeyVersion ^=keylen ;
	CString buf1,buf2;
	buf1.Format(_T("%08X"),KeyVersion);
	GetPrivateProfileString(_T("KeyVerSion"),_T("KeyVersionEx"),NULL,buf2.GetBuffer(9),9,m_strFileName);
	if (buf1!=buf2) return false;
	return true;
}
