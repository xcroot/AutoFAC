// dbmanage.cpp: implementation of the Cdbmanage class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "dbmanage.h"
#include "winsock2.h"
#pragma comment(lib,"ws2_32.lib")

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

CMySQLAPI * Cdbmanage::m_pMySqlApi = NULL;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Cdbmanage::Cdbmanage()
{
}

Cdbmanage::~Cdbmanage()
{
}

//��¼���Ĳ�ѯ���(�䳤����)
CMySQLRecordset * Cdbmanage::select(const char *lpszFormat, ...)
{
	char strTmp[MAX_SQL];
	va_list   argList;
	va_start(argList,lpszFormat);  
	_vsnprintf_s(strTmp,sizeof(strTmp),_TRUNCATE,lpszFormat,argList);  
	va_end(argList);
	CString Sqlselect;
	Sqlselect.Format(_T("%s"),strTmp);
	return select(Sqlselect);
}

//��¼���Ĳ�ѯ���
CMySQLRecordset * Cdbmanage::select(const CString &SQL)
{
	return m_pMySqlApi->SelectRecord(SQL);
}

//ִ��SQL���(�䳤����)
BOOL Cdbmanage::executesql(const char *lpszFormat, ...)
{
	char strTmp[MAX_SQL];
	va_list   argList; 
	va_start(argList,lpszFormat);  
	_vsnprintf_s(strTmp,sizeof(strTmp),_TRUNCATE,lpszFormat,argList);  
	va_end(argList);
	CString SqlString;
	SqlString.Format(_T("%s"),strTmp);
	return executesql(SqlString);
}

//ִ��SQL���
BOOL Cdbmanage::executesql(const CString &SQL)
{
	return (BOOL)m_pMySqlApi->ExecuteSql(SQL);
}

//ִ��SQL���
// BOOL Cdbmanage::GetFiledNames(const CString &SQL)
// {
// 	MYSQL_RES * res;
// 	return (BOOL)m_pMySqlApi->GetFieldName(SQL);
// }


bool Cdbmanage::init()
{
 	char* Section="DB";
// 	char* K1="UserName";
// 	char* K2="PassWord";
// 	char* K3="Port";
// 	char szUserName[MAX_PATH];
// 	char szPassWord[MAX_PATH];
 	char szFilePath[MAX_PATH];
// 	char szPort[20];
 	CString path;
 	GetModuleFileName(NULL, szFilePath, sizeof(szFilePath));
 	int n=CString(szFilePath).ReverseFind('\\');
 	path=CString(szFilePath).Left(n+1);
 	path+="config.ini";
// 
// 	GetPrivateProfileString(Section, K1,"root",szUserName,MAX_PATH,path);
// 	GetPrivateProfileString(Section, K2,"123456",szPassWord,MAX_PATH,path);
// 	GetPrivateProfileString(Section, K3,"3306",szPort,20,path);
	//GetPrivateProfileString(Section, K3,"2015",szPort,20,path);
    //char localdbname[20];
   // GetPrivateProfileString(Section, _T("db"),"2015",localdbname,20,path);
	//char szdbName[MAX_PATH];

	const char szUserName[] = "root";
	const char szPassWord[] = "123456";
	const char host[] = _T("localhost");//localhost  //192.168.10.5
	const char server[] = _T("localhost");//localhost
	//const char db[] = "dbinfo";
	int port = 3306;
	m_pMySqlApi = new CMySQLAPI(server, szUserName, szPassWord, _T("dbinfo"), port);
	  bool  bRet = m_pMySqlApi->ConnectDB();
// 	if (NULL == AfxBeginThread(CheckConnPoolThread, m_pMySqlApi))
// 		AfxMessageBox(_T("���ݿ����ӳ�ˢ���̴߳���ʧ��"));
	return bRet;
}

UINT Cdbmanage::CheckConnPoolThread(LPVOID pParam)
{
	CMySQLAPI* pMySqlApi = (CMySQLAPI*)pParam;
	while (true)
	{
		Sleep(2700 * 1000);
		//Sleep(10 * 1000);
		pMySqlApi->CheckConnPool(_T("SELECT UserName FROM DIRD"));
	}
	return 1;
}

StateNativeOrigin Cdbmanage::GetStateNativeOrigin(CString strStateNativeOrigin)
{
	StateNativeOrigin sno;
	int start = strStateNativeOrigin.Find("State:S")+(int)strlen("State:S");
	int end = strStateNativeOrigin.Find("Native:");
	CString state = strStateNativeOrigin.Mid(start,end-start-1);
	sno.m_nState = atoi(state);
	start = end+(int)strlen("Native:");
	end = strStateNativeOrigin.Find("Origin:");
	CString native = strStateNativeOrigin.Mid(start,end-start-1);
	start = end+(int)strlen("Origin:");
	end = strStateNativeOrigin.GetLength();
	sno.m_nNative = atoi(native);
	CString origin = strStateNativeOrigin.Mid(start,end-start-1);
	sno.m_strOrigin = origin;
	return sno;
}