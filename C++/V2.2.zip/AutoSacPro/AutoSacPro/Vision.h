#ifndef _H_VISION_
#define _H_VISION_
#pragma once
#include<opencv2\opencv.hpp>
#include<opencv2\highgui\highgui.hpp>
#include<opencv2\imgproc\imgproc.hpp>

#include<vector>
#include<iostream>

const double PI = 3.1415926535897;

using namespace cv;
using namespace std;



class CVision
{
public:
	CVision(void);
	~CVision(void);
public:
	string m_strFileName; //ȡ��·��
	int m_Poto_CentralX;
	int m_Poto_CentralY;
public:
	Mat reverse(Mat src); //��ɫ��ת
	MatND getHistogram(Mat &image);
	Mat getHistogramImage(Mat &image);
	int get_pixel(Mat & img, cv::Point pt);
	vector<cv::Point> getPoints(Mat &image, int value);
	void drawLine(Mat & image, double theta, double rho, Scalar color);

	BOOL GetSacCentralPoint(int &x, int &y, double &angle); //��ȡSAC���ĵ㣬��ת��
	BOOL GetLamPCentralPoint(int &x,int &y);//��ȡ�������ĵ�
	BOOL GetLamPAngel(double &angle);
	


public:
	struct con{
		double x,y;                    //����λ��
		int order;                      //��������contours�еĵڼ���

		bool operator<(con &m){
			if(y > m.y) return false;    
			else  if( y == m.y){
				if(x < m.x) return true;
				else return false;
			}                           
			else return true;
		}

	}con[15];
};

#endif //_H_VISION_