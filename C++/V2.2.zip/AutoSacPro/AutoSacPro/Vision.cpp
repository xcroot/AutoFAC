#include "StdAfx.h"
#include "Vision.h"


CVision::CVision(void)
{
	m_strFileName = "G:/jpg/langp.JPG";
}


CVision::~CVision(void)
{
}

cv::Mat CVision::reverse( Mat src )
{
		Mat dst = src<100;
		return dst;
}

cv::MatND CVision::getHistogram( Mat &image )
{
	MatND hitst;
	int channels[] = {0};
	int dims = 1;
	int histSize[] = {256};
	float granges[] = {0,256};
	const float *ranges[] = {granges};
	calcHist(&image, 1, channels,Mat(), hitst, dims, histSize, ranges);
	return hitst;
}

cv::Mat CVision::getHistogramImage( Mat &image )
{
	MatND hist = getHistogram(image);
	Mat showImage(256,256,CV_8U,Scalar(0));
	int i;
	double maxValue = 0;
	minMaxLoc(hist, 0, &maxValue, 0, 0);
	for(i = 0; i< 256; i++)
	{
		float value = hist.at<float>(i);
		int intensity = saturate_cast<int>(256 - 256 * (value/maxValue));
		rectangle(showImage,Point(i,256-1),Point((i+1)-1,intensity),Scalar(255));
	}
	return showImage;
}

int CVision::get_pixel( Mat & img, Point pt )
{
	int width = img.cols;
	int height = img.rows;
	uchar* ptr = (uchar*)img.data + pt.y * width;
	int intensity = ptr[pt.x];
	return intensity;
}

BOOL CVision::GetSacCentralPoint(int &x, int &y, double &angle)
{
	Mat src = imread(m_strFileName,1);
	map<int,int>  ColorZone;


	//ת��Ϊ�Ҷ�
	Mat gray;
	cvtColor(src,gray,CV_BGR2GRAY);
	imshow("gray",gray);

	for (int i = 0; i< src.rows; i++)
	{
		for (int j = 0; j < src.cols; j++)
		{
			int index = i * src.cols + j;
			int data = (int)gray.data[index];

			map<int,int>::iterator iter = ColorZone.find(data);

			if (iter != ColorZone.end())
			{
				iter->second++;
			} 
			else
			{
				ColorZone.insert(pair<int,int>(data,0));
			}


			if (data > 170)
			{
				gray.data[index] = 255;
			} 
			else if(data < 120)
			{
				gray.data[index] = 255;
			}

		}
	}
	imshow("gray3",gray);
	for (map<int,int>::iterator iter = ColorZone.begin(); iter != ColorZone.end();iter++)
	{
		cout<<iter->first<<":"<<iter->second<<endl;
	}

	//������

	Mat element = getStructuringElement(MORPH_RECT,Size(2,2));
	morphologyEx(gray,gray,MORPH_CLOSE,element);
	imshow("OPen",gray);

	medianBlur(gray,gray,5);
	imshow("Im01",gray);
	//��ֵ��
	Mat binaryMat;
	threshold(~gray,binaryMat,11,255,CV_THRESH_BINARY_INV);//11,255
	Mat verticalMat;
	binaryMat.copyTo(verticalMat);
	imshow("BW",binaryMat);

	//������
	element = getStructuringElement(MORPH_RECT,Size(3,3));
	morphologyEx(binaryMat,binaryMat,MORPH_OPEN,element);
	imshow("OP0-1",binaryMat);

	//��ˮ���
	//floodFill(binaryMat, Point(0,0),Scalar(0));
	//bitwise_not(binaryMat,binaryMat);
	//imshow("flood",binaryMat);


	//��������
	vector<vector<Point>> contours;
	vector<vector<Point>> detectorContours;
	findContours(binaryMat, contours,RETR_LIST,CHAIN_APPROX_SIMPLE);
	for(int i = 0; i < contours.size();i++)
	{
		//��ȡ��Ҫ������
		int nLen = arcLength(contours[i],true);
		cout<<"��"<<i<<"�����Ĵ�СΪ��"<<contours[i].size()<<"����Ϊ:"<<nLen<<endl;
		if(contours[i].size() > 200 && contours[i].size() < 1000 && nLen > 900 && nLen <1600 )
			detectorContours.push_back(contours[i]);
	}
	Mat printMat = Mat::zeros(binaryMat.size(),CV_8UC1);
	drawContours(printMat,detectorContours,-1,Scalar::all(255),-1);
	element = getStructuringElement(MORPH_RECT,Size(3,3));
	morphologyEx(printMat,printMat,MORPH_CLOSE,element);

	imshow("Contours",printMat);
	for(int i = 0; i < detectorContours.size();i++)
	{
		RotatedRect rect = minAreaRect(detectorContours[i]);
		Point2f P[4];
		rect.points(P);
		for (int j =0;j<=3;j++)
		{
			line(src,P[j],P[(j+1)%4],Scalar(68,242,238),2);
		}
		//double k = (P[3].y -P[2].y)/(P[3].x - P[2].x);
		double k = (P[2].y -P[3].y)/(P[2].x - P[3].x);
		double E = atan(k)* CV_PI/180;
		int bDirct = 0;
		Point pint;
		pint.x = P[2].x + 5;
		pint.y = P[2].y + 5;
		int pix = get_pixel(printMat,pint);
		if (pix == 0)
		{
			bDirct  = 1;
		}
		double x0,y0,alpha;
		x0 = rect.center.x;
		y0 = rect.center.y;
		x = rect.center.x;
		y = rect.center.y;
		alpha = -rect.angle * CV_PI/180;
		int w= 10;
		line(src,Point2f(x0-w,y0),Point2f(x0+w,y0),Scalar(0),1);
		line(src,Point2f(x0,y0-w),Point2f(x0,y0+w),Scalar(0),1);

		//����ͼ������
		//line(src,Point2f())
		char *str = new char[30] ;
		double x_offset, y_offset, angle;
		x_offset = x0 - src.cols/2;
		y_offset = y0 - src.rows/2;
		angle = -rect.angle * CV_PI/180;

		if (bDirct)
		{
			sprintf(str,"(%0.2f,%0.2f)-%0.2f-up",x0,y0,rect.angle);
		}
		else
		{
			sprintf(str,"(%0.2f,%0.2f)-%0.2f-down",x0,y0,rect.angle);
		}
		putText(src,str,Point(x0-70,y0-40),CV_FONT_HERSHEY_COMPLEX,0.5,Scalar(0),1,1);

		int nLen = arcLength(detectorContours[i],true);
		cout<<"��"<<i<<"��ȡ��������Ĵ�СΪ��"<<detectorContours[i].size()<<"����:"<<nLen<<endl;
	}
	imshow("Result",src);

	waitKey(0);
	return TRUE;
}

BOOL CVision::GetLamPCentralPoint( int &x, int &y )
{
	Mat src = imread(m_strFileName,1);
	//imshow("src",src);
	Mat gray;
	cvtColor(src,gray,CV_BGR2GRAY);

	m_Poto_CentralX = gray.rows / 2;
	m_Poto_CentralY = gray.cols / 2;
	//imshow("gray",gray);
	//��ֵ��
	Mat binaryMat;
	threshold(~gray,binaryMat,140,255,THRESH_OTSU);
	Mat verticalMat;
	binaryMat.copyTo(verticalMat);
	//imshow("BW",binaryMat);
	//�˲�
	Mat Im;
	medianBlur(binaryMat,Im,7);
	//imshow("Im01",Im);

	//������
	Mat element = getStructuringElement(MORPH_RECT,Size(3,3));
	morphologyEx(binaryMat,binaryMat,MORPH_CLOSE,element);
	//imshow("b-1",binaryMat);

	element = getStructuringElement(MORPH_ELLIPSE,Size(5,5));
	morphologyEx(binaryMat,binaryMat,MORPH_CLOSE,element);
	//imshow("b-2",binaryMat);

	//��������
	vector<vector<Point>> contours;
	vector<vector<Point>> detectorContours;
	findContours(binaryMat, contours,RETR_LIST,CHAIN_APPROX_SIMPLE);
	for(int i = 0; i < contours.size();i++)
	{
		//��ȡ��Ҫ������
		int nLen = arcLength(contours[i],true);
		//cout<<"��"<<i<<"�����Ĵ�СΪ��"<<contours[i].size()<<"����"<<nLen<<endl;
		if(contours[i].size() > 50 && contours[i].size() < 5000 && nLen > 5 && nLen < 500)
			detectorContours.push_back(contours[i]);
	}
	Mat printMat = Mat::zeros(src.size(),CV_8UC1);
	drawContours(printMat,detectorContours,-1,Scalar::all(255),-1);
	//imshow("Contours",printMat);
	/*for(int i = 0; i < detectorContours.size();i++)
	{
	cout<<"��"<<i<<"��ȡ��������Ĵ�СΪ��"<<detectorContours[i].size()<<endl;
	}*/

	for(int i = 0; i < detectorContours.size();i++)
	{
		RotatedRect rect = minAreaRect(detectorContours[i]);
		Point2f P[4];
		rect.points(P);
		for (int j =0;j<=3;j++)
		{
			line(src,P[j],P[(j+1)%4],Scalar(68,242,238),2);
		}
		double k = (P[3].y -P[2].y)/(P[3].x - P[2].x);
		double E = atan(k)*180/CV_PI;
		int bDirct = 0;
		Point pint;
		pint.x = P[2].x + 5;
		pint.y = P[2].y + 5;

		double x0,y0,alpha;
		x0 = rect.center.x;
		y0 = rect.center.y;
		if (X0 > 0 && y0 > 0)
		{
			x = x0;
			y = y0;
		}
		alpha = -rect.angle * CV_PI/180;
		int w= 10;
		line(src,Point2f(x0-w,y0),Point2f(x0+w,y0),Scalar(68,242,238),1);
		line(src,Point2f(x0,y0-w),Point2f(x0,y0+w),Scalar(68,242,238),1);

		//����ͼ������
		//line(src,Point2f())
		char *str = new char[30] ;
		double x_offset, y_offset, angle;
		x_offset = x0 - printMat.cols/2;
		y_offset = y0 - printMat.rows/2;
		angle = -rect.angle * CV_PI/180;

		sprintf(str,"(%0.2f,%0.2f)",x0,y0);
		putText(src,str,Point(x0-70,y0-40),CV_FONT_HERSHEY_COMPLEX,0.5,Scalar(120,211,123),1,1);

		//int nLen = arcLength(detectorContours[i],true);
		//cout<<"��"<<i<<"��ȡ��������Ĵ�СΪ��"<<detectorContours[i].size()<<"����:"<<nLen<<endl;
	}
	imshow("Result",src);
	if (x>2 && y>2 && detectorContours.size()>0)
	{
		return true;
	}
	
	return false;

}

vector<Point> CVision::getPoints( Mat &image, int value )
{
	int nl = image.rows;
	int nc = image.cols;
	vector<Point> points;
	for (int j = 0; j <nl; j++)
	{
		uchar * data = image.ptr<uchar>(j);
		for (int i = 0; i < nc; i++)
		{
			if (data[i] == value)
			{
				points.push_back(Point(i,j));
			}
		}
	}

	return points;
}

void CVision::drawLine( Mat & image, double theta, double rho, Scalar color )
{
	if (theta < PI/4 || theta > 3 * PI / 4)
	{
		Point pt1(rho/cos(theta), 0);
		Point pt2((rho - image.rows * sin(theta)) / cos(theta), image.rows);
		line(image,pt1,pt2,color,1);
	} 
	else
	{
		Point pt1(0, rho/sin(theta));
		Point pt2(image.cols,(rho - image.cols * cos(theta))/sin(theta));
		line(image, pt1, pt2, Scalar(255,0,0),1);
	}
}

BOOL CVision::GetLamPAngel( double &angle )
{
	Mat src = imread(m_strFileName);
	Mat ainLine(src.rows,src.cols,CV_8UC1,Scalar(255));
	Mat ainLine2(src.rows,src.cols,CV_8UC3,Scalar(0,0,0));
	//imshow("src",src);
	Mat gra;
	cvtColor(src,gra,CV_BGR2GRAY);

	GaussianBlur(gra,gra,Size(3,3),0);
	//imshow("Gau",gra);
	//��Ե���
	Mat src_gray,dst;
	Canny(gra, src_gray, 50, 200 ,3);
	cvtColor(src_gray ,dst, CV_GRAY2BGR);
	//imshow("Canny" ,dst);

	vector<Vec4i> pline;
	HoughLinesP(src_gray, pline, 1, CV_PI / 180, 10, 0, 10);
	Scalar color = Scalar(0, 0, 255);

	for (size_t i =0; i < pline.size(); i++ )
	{
		Vec4i hline = pline[i];
		cout<<hline[3]<<endl;
		if (hline[1] > 347)
		{
			line(ainLine, Point(hline[0], hline[1]), Point(hline[2], hline[3]), Scalar(0), 1, 1);
		}

		double k = (double)(hline[0] - hline[1])/(hline[2] - hline[3]);
		double E = atan(k)*180/CV_PI;
		//cout<<"k="<<k<<"E="<<E<<endl;
	}
	//imshow("dst" ,ainLine);
	vector<Point> points;
	Vec4f line;
	points = getPoints(ainLine, 0);
	fitLine(points, line, CV_DIST_L2, 0, 0.01, 0.01);
	//cout<<"line[0]="<<line[0]<<endl<<"line[1]="<<line[1]<<endl<<"line[2]="<<line[2]<<endl<<"line[3]="<<line[3]<<endl;


	Point2f Point1[2] = { Point2f(100,200),Point2f(int(line[2]),int(line[3])) };
	//circle(ainLine2, Point1[1], 2, Scalar(0, 0, 255), 5);

	double cos_theta = line[0];
	double sin_theta = line[1];
	double x0 = line[2],y0 = line[3];

	double tho = atan2(sin_theta ,cos_theta) + PI / 2.0;
	double rho = y0 * cos_theta - x0 * sin_theta;
	//cout << "tho = "<<tho / PI * 180 <<endl;
	//cout << "rho = "<<rho <<endl;

	drawLine(ainLine2,tho,rho,Scalar(0,0,255));
	double k = sin_theta / cos_theta;
	double b = y0 - k * x0;
	double x = 0;
	double y = k * x + b;
	angle = atan(k)* 180/CV_PI;
	//cout <<"k=" <<k <<endl;
	//cout <<"b=" <<b <<endl;
	//cout <<"angle = "<<angle<<endl;
	imshow("r",ainLine2);

	return true;

}