#pragma once
#include "stdafx.h"

// CMotionTestDlg �Ի���

class CMotionTestDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CMotionTestDlg)

public:
	CMotionTestDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CMotionTestDlg();

// �Ի�������
	enum { IDD = IDD_MOTIONDLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	long m_nX1Speedst;
	long m_nX1Speedmax;
	float m_fX1Accel;
	long m_nX1Dist;
	long m_nX1Pos;
	int m_nX1Positive;
	long m_nX2Speedst;
	long m_nX2Speedmax;
	float m_fX2Accel;
	long m_nX2Dist;
	long m_nX2Pos;
	int m_nX2Positive;
	long m_nX3Speedst;
	long m_nX3Speedmax;
	float m_fX3Accel;
	long m_nX3Dist;
	long m_nX3Pos;
	int m_nX3Positive;
	long m_nX4Speedst;
	long m_nX4Speedmax;
	float m_fX4Accel;
	long m_nX4Dist;
	long m_nX4Pos;
	int m_nX4Positive;
	long m_nX5Speedst;
	long m_nX5Speedmax;
	float m_fX5Accel;
	long m_nX5Dist;
	long m_nX5Pos;
	int m_nX5Positive;
	long m_nX6Speedst;
	long m_nX6Speedmax;
	float m_fX6Accel;
	long m_nX6Dist;
	long m_nX6Pos;
	int m_nX6Positive;
public:
	afx_msg void OnBnClickedButtonX1start();
	afx_msg void OnBnClickedButtonX1stop();
	afx_msg void OnBnClickedButtonX2start();
	afx_msg void OnBnClickedButtonX2stop();
	afx_msg void OnBnClickedButtonX3start();
	afx_msg void OnBnClickedButtonX3stop();
	afx_msg void OnBnClickedButtonX4start();
	afx_msg void OnBnClickedButtonX4stop();
	afx_msg void OnBnClickedButtonX5start();
	afx_msg void OnBnClickedButtonX5stop();
	afx_msg void OnBnClickedButtonX6start();
	afx_msg void OnBnClickedButtonX6stop();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnBnClickedButtonEmg();
	afx_msg void OnBnClickedButtonX1setzero();
	afx_msg void OnBnClickedButtonX2setzero();
	afx_msg void OnBnClickedButtonX3setzero();
	afx_msg void OnBnClickedButtonX4setzero();
	afx_msg void OnBnClickedButtonX5setzero();
	afx_msg void OnBnClickedButtonX6setzero();
	afx_msg void OnBnClickedButtonX1save();

public:
	CString m_strIniName;
	afx_msg void OnBnClickedButtonX2save();
	afx_msg void OnBnClickedButtonX3save();
	afx_msg void OnBnClickedButtonX4save();
	afx_msg void OnBnClickedButtonX5save();
	afx_msg void OnBnClickedButtonX6save();
	afx_msg void OnBnClickedReset();
public:
	void ReadIni();
	static UINT ReSetThread(LPVOID lpParam);
	
	afx_msg void OnBnClickedRadioX6positive();
	afx_msg void OnBnClickedRadioX4positive();
	afx_msg void OnDestroy();
	afx_msg void OnBnClickedRadioX1positive();
	afx_msg void OnBnClickedRadioX1negative();
	afx_msg void OnBnClickedRadioX2positive();
	afx_msg void OnBnClickedRadioX2negative();
	afx_msg void OnBnClickedRadioX3position();
	afx_msg void OnBnClickedRadioX3negative();
	afx_msg void OnBnClickedRadioX4negative();
	afx_msg void OnBnClickedRadioX5positive();
	afx_msg void OnBnClickedRadioX5negative();
	afx_msg void OnBnClickedRadioX6negative();
	afx_msg void OnBnClickedButton2();
};
