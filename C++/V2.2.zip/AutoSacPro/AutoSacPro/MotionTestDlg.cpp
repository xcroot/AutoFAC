// MotionTestDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "AutoSacPro.h"
#include "MotionTestDlg.h"
#include "afxdialogex.h"
#include "IniClient.h"
#include "ControlCard.h"
#include "LampLocationDlg.h"


// CMotionTestDlg �Ի���

IMPLEMENT_DYNAMIC(CMotionTestDlg, CDialogEx)

CMotionTestDlg::CMotionTestDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CMotionTestDlg::IDD, pParent)
	, m_fX1Accel(0)
	, m_nX1Dist(0)
	, m_nX1Pos(0)
	, m_nX2Speedst(500)
	, m_nX2Speedmax(1000)
	, m_fX2Accel(0)
	, m_nX2Dist(0)
	, m_nX2Pos(0)
	, m_nX2Positive(0)
	, m_nX3Speedst(500)
	, m_nX3Speedmax(1000)
	, m_fX3Accel(0)
	, m_nX3Dist(0)
	, m_nX3Pos(0)
	, m_nX3Positive(0)
	, m_nX4Speedst(500)
	, m_nX4Speedmax(1000)
	, m_fX4Accel(0)
	, m_nX4Dist(0)
	, m_nX4Pos(0)
	, m_nX4Positive(0)
	, m_nX5Speedst(500)
	, m_nX5Speedmax(1000)
	, m_fX5Accel(0)
	, m_nX5Dist(0)
	, m_nX5Pos(0)
	, m_nX5Positive(0)
	, m_nX6Speedst(500)
	, m_nX6Speedmax(1000)
	, m_fX6Accel(0)
	, m_nX6Dist(0)
	, m_nX6Pos(0)
	, m_nX6Positive(0)
{

	m_nX1Speedst = 500;
	m_nX1Speedmax = 1000;
	m_nX1Positive = 0;
	m_strIniName = _T("sacproperty.ini");
}

CMotionTestDlg::~CMotionTestDlg()
{
}

void CMotionTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_X1STARTSPEED, m_nX1Speedst);
	DDX_Text(pDX, IDC_EDIT_X1CURRENTSPEED, m_nX1Speedmax);
	DDX_Text(pDX, IDC_EDIT_X1RUNTIME, m_fX1Accel);
	DDX_Text(pDX, IDC_EDIT_X1POSITION, m_nX1Dist);
	DDX_Text(pDX, IDC_EDIT_X1CURRENTPOSITION, m_nX1Pos);
	DDX_Radio(pDX, IDC_RADIO_X1POSITIVE, m_nX1Positive);
	DDX_Text(pDX, IDC_EDIT_X2STARTSPEED, m_nX2Speedst);
	DDX_Text(pDX, IDC_EDIT_X2CURRENTSPEED, m_nX2Speedmax);
	DDX_Text(pDX, IDC_EDIT_X2RUNTIME, m_fX2Accel);
	DDX_Text(pDX, IDC_EDIT_X2POSITION, m_nX2Dist);
	DDX_Text(pDX, IDC_EDIT_X2CURRENTPOSITION, m_nX2Pos);
	DDX_Radio(pDX, IDC_RADIO_X2POSITIVE, m_nX2Positive);
	DDX_Text(pDX, IDC_EDIT_X3STARTSPEED, m_nX3Speedst);
	DDX_Text(pDX, IDC_EDIT_X3CURRENTSPEED, m_nX3Speedmax);
	DDX_Text(pDX, IDC_EDIT_X3RUNTIME, m_fX3Accel);
	DDX_Text(pDX, IDC_EDIT_X3POSITION, m_nX3Dist);
	DDX_Text(pDX, IDC_EDIT_X3CURRENTPOSITION, m_nX3Pos);
	DDX_Radio(pDX, IDC_RADIO_X3POSITION, m_nX3Positive);
	DDX_Text(pDX, IDC_EDIT_X4STARTSPEED, m_nX4Speedst);
	DDX_Text(pDX, IDC_EDIT_X4CURRENTSPEED, m_nX4Speedmax);
	DDX_Text(pDX, IDC_EDIT_X4RUNTIME, m_fX4Accel);
	DDX_Text(pDX, IDC_X4POSITION, m_nX4Dist);
	DDX_Text(pDX, IDC_EDIT_X4CURRENTPOSITION, m_nX4Pos);
	DDX_Radio(pDX, IDC_RADIO_X4POSITIVE, m_nX4Positive);
	DDX_Text(pDX, IDC_EDIT_X5STARTSPEED, m_nX5Speedst);
	DDX_Text(pDX, IDC_EDIT_X5CURRENTSPEED, m_nX5Speedmax);
	DDX_Text(pDX, IDC_EDIT_X5RUNTIME, m_fX5Accel);
	DDX_Text(pDX, IDC_EDIT_X5POSITION, m_nX5Dist);
	DDX_Text(pDX, IDC_EDIT_X5CURRENTPOSITION, m_nX5Pos);
	DDX_Radio(pDX, IDC_RADIO_X5POSITIVE, m_nX5Positive);
	DDX_Text(pDX, IDC_EDIT_X6STARTSPEED, m_nX6Speedst);
	DDX_Text(pDX, IDC_EDIT_X6CURRENTSPEED, m_nX6Speedmax);
	DDX_Text(pDX, IDC_EDIT_X6RUNTIME, m_fX6Accel);
	DDX_Text(pDX, IDC_EDIT_X6POSITION, m_nX6Dist);
	DDX_Text(pDX, IDC_EDIT_X6CURRENTPOSITION, m_nX6Pos);
	DDX_Radio(pDX, IDC_RADIO_X6POSITIVE, m_nX6Positive);
}


BEGIN_MESSAGE_MAP(CMotionTestDlg, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON_X1START, &CMotionTestDlg::OnBnClickedButtonX1start)
	ON_BN_CLICKED(IDC_BUTTON_X1STOP, &CMotionTestDlg::OnBnClickedButtonX1stop)
	ON_BN_CLICKED(IDC_BUTTON_X2START, &CMotionTestDlg::OnBnClickedButtonX2start)
	ON_BN_CLICKED(IDC_BUTTON_X2STOP, &CMotionTestDlg::OnBnClickedButtonX2stop)
	ON_BN_CLICKED(IDC_BUTTON_X3START, &CMotionTestDlg::OnBnClickedButtonX3start)
	ON_BN_CLICKED(IDC_BUTTON_X3STOP, &CMotionTestDlg::OnBnClickedButtonX3stop)
	ON_BN_CLICKED(IDC_BUTTON_X4START, &CMotionTestDlg::OnBnClickedButtonX4start)
	ON_BN_CLICKED(IDC_BUTTON_X4STOP, &CMotionTestDlg::OnBnClickedButtonX4stop)
	ON_BN_CLICKED(IDC_BUTTON_X5START, &CMotionTestDlg::OnBnClickedButtonX5start)
	ON_BN_CLICKED(IDC_BUTTON_X5STOP, &CMotionTestDlg::OnBnClickedButtonX5stop)
	ON_BN_CLICKED(IDC_BUTTON_X6START, &CMotionTestDlg::OnBnClickedButtonX6start)
	ON_BN_CLICKED(IDC_BUTTON_X6STOP, &CMotionTestDlg::OnBnClickedButtonX6stop)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_EMG, &CMotionTestDlg::OnBnClickedButtonEmg)
	ON_BN_CLICKED(IDC_BUTTON_X1SETZERO, &CMotionTestDlg::OnBnClickedButtonX1setzero)
	ON_BN_CLICKED(IDC_BUTTON_X2SETZERO, &CMotionTestDlg::OnBnClickedButtonX2setzero)
	ON_BN_CLICKED(IDC_BUTTON_X3SETZERO, &CMotionTestDlg::OnBnClickedButtonX3setzero)
	ON_BN_CLICKED(IDC_BUTTON_X4SETZERO, &CMotionTestDlg::OnBnClickedButtonX4setzero)
	ON_BN_CLICKED(IDC_BUTTON_X5SETZERO, &CMotionTestDlg::OnBnClickedButtonX5setzero)
	ON_BN_CLICKED(IDC_BUTTON_X6SETZERO, &CMotionTestDlg::OnBnClickedButtonX6setzero)
	ON_BN_CLICKED(IDC_BUTTON_X1SAVE, &CMotionTestDlg::OnBnClickedButtonX1save)
	ON_BN_CLICKED(IDC_BUTTON_X2SAVE, &CMotionTestDlg::OnBnClickedButtonX2save)
	ON_BN_CLICKED(IDC_BUTTON_X3SAVE, &CMotionTestDlg::OnBnClickedButtonX3save)
	ON_BN_CLICKED(IDC_BUTTON_X4SAVE, &CMotionTestDlg::OnBnClickedButtonX4save)
	ON_BN_CLICKED(IDC_BUTTON_X5SAVE, &CMotionTestDlg::OnBnClickedButtonX5save)
	ON_BN_CLICKED(IDC_BUTTON_X6SAVE, &CMotionTestDlg::OnBnClickedButtonX6save)
	ON_BN_CLICKED(IDC_RESET, &CMotionTestDlg::OnBnClickedReset)
	ON_BN_CLICKED(IDC_RADIO_X6POSITIVE, &CMotionTestDlg::OnBnClickedRadioX6positive)
	ON_BN_CLICKED(IDC_RADIO_X4POSITIVE, &CMotionTestDlg::OnBnClickedRadioX4positive)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_RADIO_X1POSITIVE, &CMotionTestDlg::OnBnClickedRadioX1positive)
	ON_BN_CLICKED(IDC_RADIO_X1NEGATIVE, &CMotionTestDlg::OnBnClickedRadioX1negative)
	ON_BN_CLICKED(IDC_RADIO_X2POSITIVE, &CMotionTestDlg::OnBnClickedRadioX2positive)
	ON_BN_CLICKED(IDC_RADIO_X2NEGATIVE, &CMotionTestDlg::OnBnClickedRadioX2negative)
	ON_BN_CLICKED(IDC_RADIO_X3POSITION, &CMotionTestDlg::OnBnClickedRadioX3position)
	ON_BN_CLICKED(IDC_RADIO_X3NEGATIVE, &CMotionTestDlg::OnBnClickedRadioX3negative)
	ON_BN_CLICKED(IDC_RADIO_X4NEGATIVE, &CMotionTestDlg::OnBnClickedRadioX4negative)
	ON_BN_CLICKED(IDC_RADIO_X5POSITIVE, &CMotionTestDlg::OnBnClickedRadioX5positive)
	ON_BN_CLICKED(IDC_RADIO_X5NEGATIVE, &CMotionTestDlg::OnBnClickedRadioX5negative)
	ON_BN_CLICKED(IDC_RADIO_X6NEGATIVE, &CMotionTestDlg::OnBnClickedRadioX6negative)
	ON_BN_CLICKED(IDC_BUTTON2, &CMotionTestDlg::OnBnClickedButton2)
END_MESSAGE_MAP()


// CMotionTestDlg ��Ϣ��������


BOOL CMotionTestDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	ReadIni();
	SetTimer(102,100,NULL);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}


void CMotionTestDlg::OnBnClickedButtonX1start()
{
	UpdateData(TRUE);
    if (m_nX1Positive == 0)
    {
		CControlCard::MoveRaxis(X0, m_nX1Dist);
    } 
    else
    {
		CControlCard::MoveRaxis(X0, -m_nX1Dist);
    }
	
}


void CMotionTestDlg::OnBnClickedButtonX1stop()
{
	CControlCard::Stop(X0);
}


void CMotionTestDlg::OnBnClickedButtonX2start()
{
	UpdateData(TRUE);
    if (m_nX2Positive == 0)
    {
		CControlCard::MoveRaxis(X1 ,m_nX2Dist);
    } 
    else
    {
		CControlCard::MoveRaxis(X1, -m_nX2Dist);
    }
	
}


void CMotionTestDlg::OnBnClickedButtonX2stop()
{
	CControlCard::Stop(X1);
}


void CMotionTestDlg::OnBnClickedButtonX3start()
{
	UpdateData(TRUE);
	//CControlCard::SetProfile(X2, m_nX3Speedst, m_nX3Speedmax, m_fX3Accel, m_fX3Accel);
	/*CControlCard::SetDistance(X2, m_nX3Dist, 0);
	CControlCard::SartMove(X2, !m_nX3Positive);*/
	if ( m_nX3Positive == 0 )
	{
		CControlCard::MoveRaxis(X2, m_nX3Dist);
	} 
	else
	{
		CControlCard::MoveRaxis(X2, -m_nX3Dist);
	}
	
}


void CMotionTestDlg::OnBnClickedButtonX3stop()
{
	CControlCard::Stop(X2);
}


void CMotionTestDlg::OnBnClickedButtonX4start()
{
	UpdateData(TRUE);
	//CControlCard::SetProfile(X3, m_nX4Speedst, m_nX4Speedmax, m_fX4Accel, m_fX4Accel);
	/*CControlCard::SetDistance(X3, m_nX4Dist, 0);
	CControlCard::SartMove(X3, !m_nX4Positive);*/

	if (m_nX4Positive == 0) 
	{
		CControlCard::MoveRaxis(X3, m_nX4Dist);
	} 
	else
	{
		CControlCard::MoveRaxis(X3, -m_nX4Dist);
	}
	
}


void CMotionTestDlg::OnBnClickedButtonX4stop()
{
	CControlCard::Stop(X3);
}


void CMotionTestDlg::OnBnClickedButtonX5start()
{
	UpdateData(TRUE);
	//CControlCard::SetProfile(X4, m_nX5Speedst, m_nX5Speedmax, m_fX5Accel, m_fX5Accel);
	//CControlCard::SetDistance(X4, m_nX5Dist, 0);
	//CControlCard::SartMove(X4, !m_nX5Positive);
	if ( m_nX5Positive == 0)
	{
		CControlCard::MoveRaxis(X4, m_nX5Dist);
	} 
	else
	{
		CControlCard::MoveRaxis(X4, -m_nX5Dist);
	}
	
}


void CMotionTestDlg::OnBnClickedButtonX5stop()
{
	CControlCard::Stop(X4);
}


void CMotionTestDlg::OnBnClickedButtonX6start()
{
	UpdateData(TRUE);
	//CControlCard::SetProfile(X5, m_nX6Speedst, m_nX6Speedmax, m_fX6Accel, m_fX6Accel);
	//CControlCard::SetDistance(X5, m_nX6Dist, 0);
	//CControlCard::SartMove(X5, !m_nX6Positive);
	if (m_nX6Positive == 0)
	{
		CControlCard::MoveRaxis(X5, m_nX6Dist);
	} 
	else
	{
		CControlCard::MoveRaxis(X5, -m_nX6Dist);
	}
	
	
}


void CMotionTestDlg::OnBnClickedButtonX6stop()
{
	CControlCard::Stop(X5);
}


void CMotionTestDlg::OnTimer(UINT_PTR nIDEvent)
{
	//CString X0CurSpeed,X1CurSpeed,X2CurSpeed,X3CurSpeed,X4CurSpeed,X5CurSpeed;
	//X0CurSpeed.Format()

	CString X0Pos,X1Pos,X2Pos,X3Pos,X4Pos,X5Pos;
	X0Pos.Format("%d",CControlCard::GetAxisPosition(X0));
	X1Pos.Format("%d",CControlCard::GetAxisPosition(X1));
	X2Pos.Format("%d",CControlCard::GetAxisPosition(X2));
	X3Pos.Format("%d",CControlCard::GetAxisPosition(X3));
	X4Pos.Format("%d",CControlCard::GetAxisPosition(X4));
	X5Pos.Format("%d",CControlCard::GetAxisPosition(X5));

	GetDlgItem(IDC_EDIT_X1CURRENTPOSITION)->SetWindowText(X0Pos);
	GetDlgItem(IDC_EDIT_X2CURRENTPOSITION)->SetWindowText(X1Pos);
	GetDlgItem(IDC_EDIT_X3CURRENTPOSITION)->SetWindowText(X2Pos);
	GetDlgItem(IDC_EDIT_X4CURRENTPOSITION)->SetWindowText(X3Pos);
	GetDlgItem(IDC_EDIT_X5CURRENTPOSITION)->SetWindowText(X4Pos);
	GetDlgItem(IDC_EDIT_X6CURRENTPOSITION)->SetWindowText(X5Pos);

	CDialogEx::OnTimer(nIDEvent);
}

void CMotionTestDlg::OnBnClickedButtonEmg()
{
	CControlCard::EmgStop();
}


void CMotionTestDlg::OnBnClickedButtonX1setzero()
{
	CControlCard::SetAxisPosition(X0,0);
}


void CMotionTestDlg::OnBnClickedButtonX2setzero()
{
	CControlCard::SetAxisPosition(X1,0);
}


void CMotionTestDlg::OnBnClickedButtonX3setzero()
{
	CControlCard::SetAxisPosition(X2,0);
}


void CMotionTestDlg::OnBnClickedButtonX4setzero()
{
	CControlCard::SetAxisPosition(X3,0);
}


void CMotionTestDlg::OnBnClickedButtonX5setzero()
{
	CControlCard::SetAxisPosition(X4,0);
}


void CMotionTestDlg::OnBnClickedButtonX6setzero()
{
	CControlCard::SetAxisPosition(X5,0);
}


void CMotionTestDlg::OnBnClickedButtonX1save()
{
	UpdateData(TRUE);
	CIniClient::Instance(m_strIniName)->SetValue(_T("X0"),_T("Speedst"),m_nX1Speedst,true);
	CIniClient::Instance(m_strIniName)->SetValue(_T("X0"),_T("Speedmax"),m_nX1Speedmax,true);
	CIniClient::Instance(m_strIniName)->SetValue(_T("X0"),_T("Accel"),m_fX1Accel,true);
	CIniClient::Instance(m_strIniName)->SetValue(_T("X0"),_T("Dist"),m_nX1Dist,true);
}


void CMotionTestDlg::OnBnClickedButtonX2save()
{
	UpdateData(TRUE);
	CIniClient::Instance(m_strIniName)->SetValue(_T("X1"),_T("Speedst"),m_nX2Speedst,true);
	CIniClient::Instance(m_strIniName)->SetValue(_T("X1"),_T("Speedmax"),m_nX2Speedmax,true);
	CIniClient::Instance(m_strIniName)->SetValue(_T("X1"),_T("Accel"),m_fX2Accel,true);
	CIniClient::Instance(m_strIniName)->SetValue(_T("X1"),_T("Dist"),m_nX2Dist,true);
}


void CMotionTestDlg::OnBnClickedButtonX3save()
{
	UpdateData(TRUE);
	CIniClient::Instance(m_strIniName)->SetValue(_T("X2"),_T("Speedst"),m_nX3Speedst,true);
	CIniClient::Instance(m_strIniName)->SetValue(_T("X2"),_T("Speedmax"),m_nX3Speedmax,true);
	CIniClient::Instance(m_strIniName)->SetValue(_T("X2"),_T("Accel"),m_fX3Accel,true);
	CIniClient::Instance(m_strIniName)->SetValue(_T("X2"),_T("Dist"),m_nX3Dist,true);
}


void CMotionTestDlg::OnBnClickedButtonX4save()
{
	UpdateData(TRUE);
	CIniClient::Instance(m_strIniName)->SetValue(_T("X3"),_T("Speedst"),m_nX4Speedst,true);
	CIniClient::Instance(m_strIniName)->SetValue(_T("X3"),_T("Speedmax"),m_nX4Speedmax,true);
	CIniClient::Instance(m_strIniName)->SetValue(_T("X3"),_T("Accel"),m_fX4Accel,true);
	CIniClient::Instance(m_strIniName)->SetValue(_T("X3"),_T("Dist"),m_nX4Dist,true);
}


void CMotionTestDlg::OnBnClickedButtonX5save()
{
	UpdateData(TRUE);
	CIniClient::Instance(m_strIniName)->SetValue(_T("X4"),_T("Speedst"),m_nX5Speedst,true);
	CIniClient::Instance(m_strIniName)->SetValue(_T("X4"),_T("Speedmax"),m_nX5Speedmax,true);
	CIniClient::Instance(m_strIniName)->SetValue(_T("X4"),_T("Accel"),m_fX5Accel,true);
	CIniClient::Instance(m_strIniName)->SetValue(_T("X4"),_T("Dist"),m_nX5Dist,true);
}


void CMotionTestDlg::OnBnClickedButtonX6save()
{
	UpdateData(TRUE);
	CIniClient::Instance(m_strIniName)->SetValue(_T("X5"),_T("Speedst"),m_nX6Speedst,true);
	CIniClient::Instance(m_strIniName)->SetValue(_T("X5"),_T("Speedmax"),m_nX6Speedmax,true);
	CIniClient::Instance(m_strIniName)->SetValue(_T("X5"),_T("Accel"),m_fX6Accel,true);
	CIniClient::Instance(m_strIniName)->SetValue(_T("X5"),_T("Dist"),m_nX6Dist,true);
}

void CMotionTestDlg::ReadIni()
{
    TCHAR szX1Speedst[50] = { 0 };
	TCHAR szX1Speedmax[50] = { 0 };
	TCHAR szX1Accel[50] = { 0 };
	TCHAR szX1Dist[50] = { 0 };

	TCHAR szX2Speedst[50] = { 0 };
	TCHAR szX2Speedmax[50] = { 0 };
	TCHAR szX2Accel[50] = { 0 };
	TCHAR szX2Dist[50] = { 0 };

	TCHAR szX3Speedst[50] = { 0 };
	TCHAR szX3Speedmax[50] = { 0 };
	TCHAR szX3Accel[50] = { 0 };
	TCHAR szX3Dist[50] = { 0 };

	TCHAR szX4Speedst[50] = { 0 };
	TCHAR szX4Speedmax[50] = { 0 };
	TCHAR szX4Accel[50] = { 0 };
	TCHAR szX4Dist[50] = { 0 };

	TCHAR szX5Speedst[50] = { 0 };
	TCHAR szX5Speedmax[50] = { 0 };
	TCHAR szX5Accel[50] = { 0 };
	TCHAR szX5Dist[50] = { 0 };

	TCHAR szX6Speedst[50] = { 0 };
	TCHAR szX6Speedmax[50] = { 0 };
	TCHAR szX6Accel[50] = { 0 };
	TCHAR szX6Dist[50] = { 0 };

	CIniClient::Instance(m_strIniName)->GetValue(_T("X0"),_T("Speedst"),szX1Speedst,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X0"),_T("Speedmax"),szX1Speedmax,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X0"),_T("Accel"),szX1Accel,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X0"),_T("Dist"),szX1Dist,NULL);

	CIniClient::Instance(m_strIniName)->GetValue(_T("X1"),_T("Speedst"),szX2Speedst,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X1"),_T("Speedmax"),szX2Speedmax,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X1"),_T("Accel"),szX2Accel,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X1"),_T("Dist"),szX2Dist,NULL);

	CIniClient::Instance(m_strIniName)->GetValue(_T("X2"),_T("Speedst"),szX3Speedst,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X2"),_T("Speedmax"),szX3Speedmax,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X2"),_T("Accel"),szX3Accel,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X2"),_T("Dist"),szX3Dist,NULL);

	CIniClient::Instance(m_strIniName)->GetValue(_T("X3"),_T("Speedst"),szX4Speedst,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X3"),_T("Speedmax"),szX4Speedmax,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X3"),_T("Accel"),szX4Accel,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X3"),_T("Dist"),szX4Dist,NULL);

	CIniClient::Instance(m_strIniName)->GetValue(_T("X4"),_T("Speedst"),szX5Speedst,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X4"),_T("Speedmax"),szX5Speedmax,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X4"),_T("Accel"),szX5Accel,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X4"),_T("Dist"),szX5Dist,NULL);

	CIniClient::Instance(m_strIniName)->GetValue(_T("X5"),_T("Speedst"),szX6Speedst,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X5"),_T("Speedmax"),szX6Speedmax,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X5"),_T("Accel"),szX6Accel,NULL);
	CIniClient::Instance(m_strIniName)->GetValue(_T("X5"),_T("Dist"),szX6Dist,NULL);


	m_nX1Speedst  = atof(szX1Speedst);
	m_nX1Speedmax = atof(szX1Speedmax);
	m_fX1Accel    = atof(szX1Accel);
	m_nX1Dist     = atof(szX1Dist);

	m_nX2Speedst  = atof(szX2Speedst);
	m_nX2Speedmax = atof(szX2Speedmax);
	m_fX2Accel    = atof(szX2Accel);
	m_nX2Dist     = atof(szX2Dist);

	m_nX3Speedst  = atof(szX3Speedst);
	m_nX3Speedmax = atof(szX3Speedmax);
	m_fX3Accel    = atof(szX3Accel);
	m_nX3Dist     = atof(szX3Dist);

	m_nX4Speedst  = atof(szX4Speedst);
	m_nX4Speedmax = atof(szX4Speedmax);
	m_fX4Accel    = atof(szX4Accel);
	m_nX4Dist     = atof(szX4Dist);

	m_nX5Speedst  = atof(szX5Speedst);
	m_nX5Speedmax = atof(szX5Speedmax);
	m_fX5Accel    = atof(szX5Accel);
	m_nX5Dist     = atof(szX5Dist);

	m_nX6Speedst  = atof(szX6Speedst);
	m_nX6Speedmax = atof(szX6Speedmax);
	m_fX6Accel    = atof(szX6Accel);
	m_nX6Dist     = atof(szX6Dist);


	UpdateData(FALSE);




}

void CMotionTestDlg::OnBnClickedReset()
{
	AfxBeginThread(ReSetThread,this);
}

UINT CMotionTestDlg::ReSetThread( LPVOID lpParam )
{
	//�������
	CControlCard::ResetAll();
	return 0;
}

void CMotionTestDlg::OnBnClickedRadioX6positive()
{
	m_nX6Positive = 0;
}


void CMotionTestDlg::OnBnClickedRadioX4positive()
{
	m_nX4Positive = 0;
}


void CMotionTestDlg::OnDestroy()
{
	CDialogEx::OnDestroy();
    KillTimer(102);
}


void CMotionTestDlg::OnBnClickedRadioX1positive()
{
	m_nX1Positive = 0;
}


void CMotionTestDlg::OnBnClickedRadioX1negative()
{
	m_nX1Positive = -1;
}


void CMotionTestDlg::OnBnClickedRadioX2positive()
{
	m_nX2Positive = 0;
}


void CMotionTestDlg::OnBnClickedRadioX2negative()
{
	m_nX2Positive = -1;
}


void CMotionTestDlg::OnBnClickedRadioX3position()
{
	m_nX3Positive = 0;
}


void CMotionTestDlg::OnBnClickedRadioX3negative()
{
	m_nX3Positive = -1;
}


void CMotionTestDlg::OnBnClickedRadioX4negative()
{
	m_nX4Positive = -1;
}


void CMotionTestDlg::OnBnClickedRadioX5positive()
{
	m_nX5Positive = 0;
}


void CMotionTestDlg::OnBnClickedRadioX5negative()
{
	m_nX5Positive = -1;
}


void CMotionTestDlg::OnBnClickedRadioX6negative()
{
	m_nX6Positive = -1;
}


void CMotionTestDlg::OnBnClickedButton2()
{
	CLampLocationDlg Axis_home;
	Axis_home.InitMoto();
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
}
