// dbmanage.h: interface for the Cdbmanage class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DBMANAGE_H__BA580AC3_4BBC_4899_AFBD_609ABB5B15DC__INCLUDED_)
#define AFX_DBMANAGE_H__BA580AC3_4BBC_4899_AFBD_609ABB5B15DC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "odbcinst.h"
#include "afxdb.h"
#include "Log.h" 
#include "MySQLAPI.h"
#define MAX_SQL 2048

struct StateNativeOrigin
{
	USHORT m_nState;
	USHORT m_nNative;
	CString m_strOrigin;
};

class Cdbmanage  
{
public:
	static bool init();
	static void uninit(){ if(m_pMySqlApi) delete m_pMySqlApi;}
	static UINT CheckConnPoolThread(LPVOID pParam);
	static BOOL executesql(const char *lpszFormat, ...);//ִ��SQL���
	static BOOL executesql(const CString &SQL);
	//static BOOL GetFiledNames(const CString &SQL);
	static CMySQLRecordset * select(const char *lpszFormat, ...);//ִ��SQL��ѯ���
	static CMySQLRecordset * select(const CString &SQL);
	static int GetRowNum(MYSQL_RES * res){ return (int)m_pMySqlApi->GetRowNum(res);}
	static MYSQL_ROW GetRecord(MYSQL_RES * res){ return m_pMySqlApi->GetRecord(res);}
	static void DeleteRS(MYSQL_RES * res){
		m_pMySqlApi->FreeRecord(res);
		res = NULL;
	}

	virtual ~Cdbmanage();
	Cdbmanage();
private:
	CString m_err;
	static CMySQLAPI * m_pMySqlApi;
	static char * gethostip();
	StateNativeOrigin GetStateNativeOrigin(CString strStateNativeOrigin);
	StateNativeOrigin GetStateNativeOrigin(CDBException* e){return GetStateNativeOrigin(e->m_strStateNativeOrigin);}
};

#endif // !defined(AFX_DBMANAGE_H__BA580AC3_4BBC_4899_AFBD_609ABB5B15DC__INCLUDED_)
