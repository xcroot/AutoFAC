#pragma once


// CLampFinishedStatusDlg �Ի���

class CLampFinishedStatusDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CLampFinishedStatusDlg)

public:
	CLampFinishedStatusDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CLampFinishedStatusDlg();

// �Ի�������
	enum { IDD = IDD_DIALOG_LANPSTATUS };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	int m_nSacCoutNum;
	int m_nFinishedNum;
	int m_nRemainNum;
	int m_nSel;

public:
	void Update();

public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedRadioSel1();
	afx_msg void OnBnClickedRadioSel2();
	afx_msg void OnBnClickedRadioSel3();
	afx_msg void OnBnClickedRadioSel4();
	afx_msg void OnBnClickedButtonSubone();
	afx_msg void OnBnClickedButtonAddone();
	afx_msg void OnBnClickedButtonReset();
	BOOL m_bLampOne;
	BOOL m_bLampTwo;
	BOOL m_bLampThree;
	BOOL m_bLampFour;
	afx_msg void OnBnClickedButtonNextlamp();
};
